//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include <time.h>
#include "Clock.h"

//---------------------------------------------------------------------------

#pragma package(smart_init)

//int numseconds;

Clock::Clock() : numseconds(0)
{
}

Clock::Clock(int h, int m, int s): numseconds(h*3600+m*60+s)
{
}

Clock::Clock(const Clock &other): numseconds(other.numseconds)
{
}

Clock::~Clock()
{
}

void Clock::GetSystemTime()
{
        time_t time0=time(0);
        struct tm *now=localtime (&time0);
        numseconds=CalcNumSec(now->tm_hour, now->tm_min, now->tm_sec);
}

int Clock::Hours() const
{
        return numseconds/3600;
}

int Clock::Minutes() const
{
        return ((numseconds-(numseconds/3600)*3600)/60) ;
}

int Clock::Seconds() const
{
        return numseconds-Hours()*3600-Minutes()*60;
}

void Clock::SetHours()
{

}

void Clock::SetMinutes()
{

}

void Clock::SetSeconds()
{

}

int Clock::CalcNumSec(int h, int m, int s)
{
        return h*3600+m*60+s;
}
