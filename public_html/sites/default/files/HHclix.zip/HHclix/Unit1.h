//---------------------------------------------------------------------------

#ifndef Unit1H
#define Unit1H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ScktComp.hpp>
#include <Menus.hpp>
#include <ComCtrls.hpp>
#include <Dialogs.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------

#define WM_ICONTRAY

class TForm1 : public TForm
{
__published:	// IDE-managed Components
        TClientSocket *ClientSocket1;
        TPopupMenu *PopupMenu1;
        TMenuItem *mnShow;
        TMenuItem *mnClose;
        TMemo *mmScript;
        TButton *btnRScritp;
        TButton *btnSScritp;
        TButton *btnOScritp;
        TCheckBox *cxbRScript;
        TOpenDialog *OpenDialog1;
        TSaveDialog *SaveDialog1;
        TEdit *edtSTime;
        TLabel *Label2;
        TButton *btnHide;
        TButton *btnExit;
        TLabel *lblClock;
        TTimer *Timer1;
        TButton *Button1;
        void __fastcall FormDestroy(TObject *Sender);
        void __fastcall FormCreate(TObject *Sender);
        void __fastcall ClientSocket1Error(TObject *Sender,
          TCustomWinSocket *Socket, TErrorEvent ErrorEvent,
          int &ErrorCode);
        void __fastcall mnShowClick(TObject *Sender);
        void __fastcall mnCloseClick(TObject *Sender);
        void __fastcall btnHideClick(TObject *Sender);
        void __fastcall btnRScritpClick(TObject *Sender);
        void __fastcall btnOScritpClick(TObject *Sender);
        void __fastcall btnSScritpClick(TObject *Sender);
        void __fastcall Timer1Timer(TObject *Sender);
        void __fastcall Button1Click(TObject *Sender);

private:	// User declarations
        TNotifyIconData TrayIcon;

        bool __fastcall TForm1::ExecCmd(AnsiString &cmdLine);
        void __fastcall TForm1::Ler();
        bool __fastcall InitTimeTrigger();

public:		// User declarations
        __fastcall TForm1(TComponent* Owner);

        void __fastcall TForm1::Run(TObject*, bool& done);
        void TForm1::TrayMessage(TMessage Msg);
        BEGIN_MESSAGE_MAP
           MESSAGE_HANDLER(WM_USER+1, TMessage, TrayMessage)
        END_MESSAGE_MAP(TForm)
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
