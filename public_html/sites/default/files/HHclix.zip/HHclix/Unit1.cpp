//---------------------------------------------------------------------------

#include <vcl.h>
#include <IniFiles.hpp>
#include <fstream.h>
#include <vector>
//#include <TIniFile>

#include "Clock.h"
#include "TimeTrigger.h"

#pragma hdrstop

#include "Unit1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;

ofstream logFile;
ostream  *loG;

Clock myClock;

vector<TimeTrigger> timeTriggers;

#define LOG *loG

//LoadString
//SaveStr



//add log date
//add log user/auto exec script
//add verify time string input
//add a config file for the time triggers

//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
        //Application->OnIdle = Run;
        logFile.open("log.txt");
        loG = &logFile;
        
        InitTimeTrigger();
        mmScript->Lines->LoadFromFile("default.script");

        TIniFile *myINI;
        myINI = new TIniFile( ChangeFileExt( Application->ExeName, ".INI" ) );
        edtSTime->Text = myINI->ReadString( "CONFIG", "TIMETRIGGERS", "01:15;07:45" );
        delete myINI;
}
//---------------------------------------------------------------------------
 void __fastcall TForm1::Run(TObject*, bool& done)
{
        done = false;
        //if(ClientSocket1->Active)Ler();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormDestroy(TObject *Sender)
{
        Shell_NotifyIcon(NIM_DELETE, &TrayIcon);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
        TrayIcon.cbSize = sizeof(TrayIcon);
        TrayIcon.hWnd = Handle;
        TrayIcon.uID = 0;
        TrayIcon.uFlags = NIF_MESSAGE + NIF_ICON + NIF_TIP;
        TrayIcon.uCallbackMessage = WM_USER + 1;
        TrayIcon.hIcon = Application->Icon->Handle;
        StrPCopy(TrayIcon.szTip, Application->Title);

        Shell_NotifyIcon(NIM_ADD, &TrayIcon);
}
//---------------------------------------------------------------------------
void TForm1::TrayMessage(TMessage  Msg)
{
 switch( Msg.LParam)
 {
  case WM_LBUTTONDOWN:
  case WM_RBUTTONDOWN:
        POINT P;
        GetCursorPos(&P );
        SetForegroundWindow (Handle);
        PopupMenu1->Popup(P.x,P.y);
        break;
 }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::ClientSocket1Error(TObject *Sender,
      TCustomWinSocket *Socket, TErrorEvent ErrorEvent, int &ErrorCode)
{
        ClientSocket1->Close();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::mnShowClick(TObject *Sender)
{
        FormDestroy(this);
        Form1->Show();

}
//---------------------------------------------------------------------------
void __fastcall TForm1::mnCloseClick(TObject *Sender)
{
        ClientSocket1->Close();
        logFile.close();
        Form1->Close();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::btnHideClick(TObject *Sender)
{
        FormCreate(this);
        Form1->Hide();
}
//---------------------------------------------------------------------------

void __fastcall TForm1::btnRScritpClick(TObject *Sender)
{
        //Run Script
        mmScript->Enabled = false;
        btnRScritp->Enabled = false;
        //cxbRScript
        //CheckScript()
        for(int i=0; i < mmScript->Lines->Count ; i++)
        {
         AnsiString cmdLine="";
         cmdLine = mmScript->Lines->Strings[i];
         ExecCmd(cmdLine);
        }
        //Ler();
        ClientSocket1->Close();

        mmScript->Enabled = true;
        btnRScritp->Enabled = true;
}
//---------------------------------------------------------------------------

bool __fastcall TForm1::ExecCmd(AnsiString &cmdLine)
{
         AnsiString cmd="" , argument="";

         int find_arg = cmdLine.Pos(" ");
         if( find_arg == 0 ) cmd = cmdLine;
         else{
                cmd = cmdLine.SubString(1,find_arg-1);
                argument = cmdLine.SubString(find_arg+1,cmdLine.Length() - find_arg);
         }

         if(cmd == "close"){
                ClientSocket1->Close();
                LOG  << "disconnected..."  << endl;
         }
         else if(cmd == "log"){
                LOG  << argument.c_str() << endl;
         }
         else if(cmd == "open"){
                ClientSocket1->Address = argument;
                ClientSocket1->Open();
                LOG << "connecting.." << endl;
         }
         else if(cmd == "send"){
                ClientSocket1->Socket->SendText(argument);
                ClientSocket1->Socket->SendText(char(13));
         }
         else if(cmd == "wait"){
                Sleep( argument.ToInt() );
                Ler();
         }

         return true;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Ler()
{
                    /*
                AnsiString tmp = "";
                tmp = ClientSocket1->Socket->ReceiveText();

                if (tmp != ""){
                        LOG << tmp.c_str();

                }              */
                AnsiString tmp = "";
               // while(tmp == "")
                {
                        tmp = ClientSocket1->Socket->ReceiveText();
                        LOG << tmp.c_str();
                }

}
//---------------------------------------------------------------------------
void __fastcall TForm1::btnOScritpClick(TObject *Sender)
{
        //open script
        OpenDialog1->InitialDir = Application->ExeName;
        if(OpenDialog1->Execute())
                 mmScript->Lines->LoadFromFile(OpenDialog1->FileName);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::btnSScritpClick(TObject *Sender)
{
        //save script
        SaveDialog1->InitialDir = Application->ExeName;
        if(SaveDialog1->Execute())
                mmScript->Lines->SaveToFile(SaveDialog1->FileName);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Timer1Timer(TObject *Sender)
{
        myClock.GetSystemTime();
        int h = myClock.Hours();
        int m = myClock.Minutes();
        int s = myClock.Seconds();
        lblClock->Caption = "Clock: " + AnsiString(h) \
         + ":" + AnsiString(m) + ":" + AnsiString(s);

        if(cxbRScript->Checked){

               for(int i=0; i<(int)timeTriggers.size(); i+=1)
                        if(timeTriggers[i].Hours()==h && timeTriggers[i].Minutes()==m){
                                if(!timeTriggers[i].IsActivate()){
                                        LOG << endl << "------------------------" << endl
                                        << "exec script at: " << h << ":" << m << ":" << s
                                        << endl << "------------------------" << endl;
                                        Timer1->Enabled = false;
                                        btnRScritpClick(this);
                                        timeTriggers[i].Activate(true);
                                        Timer1->Enabled = true;
                                }
                        }
                        else timeTriggers[i].Activate(false);

        }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button1Click(TObject *Sender)
{
        edtSTime->Text = InputBox("", "hh:mm;hh:mm...", edtSTime->Text);
        InitTimeTrigger();

        TIniFile *myINI;
        myINI = new TIniFile( ChangeFileExt( Application->ExeName, ".INI" ) );
        myINI->WriteString( "CONFIG", "TIMETRIGGERS", edtSTime->Text );
        delete myINI;
}
//---------------------------------------------------------------------------
bool __fastcall TForm1::InitTimeTrigger()
{
        timeTriggers.clear();
        for(int i=0; i < edtSTime->Text.Length() ; i++  ){
                if( edtSTime->Text[i+1] == ':'){
                        TimeTrigger trigger;
                        trigger.Hours(edtSTime->Text.SubString(i-1,2).ToInt());
                        trigger.Minutes(edtSTime->Text.SubString(i+2,2).ToInt());
                        timeTriggers.push_back(trigger);
                }
        }

        return true;
}
//---------------------------------------------------------------------------

