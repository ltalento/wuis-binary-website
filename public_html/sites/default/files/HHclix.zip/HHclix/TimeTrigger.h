//---------------------------------------------------------------------------

#ifndef TimeTriggerH
#define TimeTriggerH
//---------------------------------------------------------------------------

class TimeTrigger
{
private:
        int h;
        int m;
        bool isActivate;
public:
        TimeTrigger();
        ~TimeTrigger();
        int Hours();
        void Hours(int h);
        int Minutes();
        void Minutes(int m);
        bool IsActivate();
        void Activate(bool a);
};

#endif
