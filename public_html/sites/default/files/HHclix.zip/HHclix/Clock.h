//---------------------------------------------------------------------------

#ifndef ClockH
#define ClockH
//---------------------------------------------------------------------------
class Clock
{
private:
        int numseconds;
        static int CalcNumSec(int h, int m, int s);

public:
        Clock();
        Clock(int h, int m, int s);
        Clock(const Clock &other);
        virtual ~Clock();

        virtual void GetSystemTime();

        virtual int Hours() const;
        virtual int Minutes() const;
        virtual int Seconds() const;

        virtual void SetHours();
        virtual void SetMinutes();
        virtual void SetSeconds();

};

#endif



