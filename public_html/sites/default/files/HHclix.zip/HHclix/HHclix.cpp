//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
USERES("HHclix.res");
USEFORM("Unit1.cpp", Form1);
USEUNIT("Clock.cpp");
USEUNIT("TimeTrigger.cpp");
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
        try
        {
                 Application->Initialize();
                 Application->ShowMainForm = false;
                 Application->CreateForm(__classid(TForm1), &Form1);
                 Application->Run();
        }
        catch (Exception &exception)
        {
                 Application->ShowException(&exception);
        }
        return 0;
}
//---------------------------------------------------------------------------
