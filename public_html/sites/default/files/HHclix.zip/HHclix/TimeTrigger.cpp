//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "TimeTrigger.h"

//---------------------------------------------------------------------------

#pragma package(smart_init)

TimeTrigger::TimeTrigger():h(0),m(0),isActivate(false)
{}

TimeTrigger::~TimeTrigger()
{}

int TimeTrigger::Hours()
{
        return h;
}

void TimeTrigger::Hours(int h)
{
        this->h=h;
}

int TimeTrigger::Minutes()
{
        return m;
}

void TimeTrigger::Minutes(int m)
{
        this->m=m;
}

bool TimeTrigger::IsActivate()
{
        return isActivate;
}

void TimeTrigger::Activate(bool a)
{
        isActivate=a;
}
