#include<stdio.h>
#include<conio.h>
#include<string.h>
#include<ctype.h>
#include<stdlib.h>
//#include"Quadro"
struct video
{
 char Titulo[30];
 char Realizador[30];
 char Empresa_de_Realizacao[30];
 int Ano_de_Realizacao;
 int Referencia;
 int NR_copias;
} Filme;
FILE *data,*Ref;
int referencia,x;
char op;
void cof_A();
void of_RW();
void Inserir();
void Mostrar();
void Apagar();
void ref();
void select_pes();
void select_SN(int Y);
void main()
{
 char titulo[30],op2;
 int found,y;
 long file_pos;
 cof_A();
 fclose(data);

 do{
    y=9;
    _setcursortype(_NOCURSOR);
    textbackground(BLACK);
    clrscr();
    do{
      if (op==72) //&& (y!=4))
	 y--;
      if (op==80) // && (y!=9))
	 y++;

      if ((op==72) && (y==3))
	 y=6+3;

      if ((op==80) && (y==10))
	 y=4;

      if(y==4)
      {
       gotoxy(4,4);
       textcolor(BLACK);
       textbackground(15);
       cprintf("1 => Inserir Filme");
      }
      else
      {
       gotoxy(4,4);
       textcolor(WHITE);
       textbackground(BLACK);
       cprintf("1 => Inserir Filme");
      }
      if(y==5)
      {
       gotoxy(4,5);
       textcolor(BLACK);
       textbackground(WHITE);
       cprintf("2 => Consultar Filme");
      }
      else
      {
       gotoxy(4,5);
       textcolor(WHITE);
       textbackground(BLACK);
       cprintf("2 => Consultar Filme");
      }
      if(y==6)
      {
       gotoxy(4,6);
       textcolor(BLACK);
       textbackground(WHITE);
       cprintf("3 => Alterar Filme");
      }
      else
      {
       gotoxy(4,6);
       textcolor(WHITE);
       textbackground(BLACK);
       cprintf("3 => Alterar Filme");
      }
      if(y==7)
      {
       gotoxy(4,7);
       textcolor(BLACK);
       textbackground(WHITE);
       cprintf("4 => Eliminar Filme");
      }
      else
      {
       gotoxy(4,7);
       textcolor(WHITE);
       textbackground(BLACK);
       cprintf("4 => Eliminar Filme");
      }
      if(y==8)
      {
       gotoxy(4,8);
       textcolor(BLACK);
       textbackground(WHITE);
       cprintf("5 => Acerca de...");
      }
      else
      {
       gotoxy(4,8);
       textcolor(WHITE);
       textbackground(BLACK);
       cprintf("5 => Acerca de...");
      }
     if(y==9)
      {
       gotoxy(4,9);
       textcolor(BLACK);
       textbackground(WHITE);
       cprintf("6 => Sair");
      }
      else
      {
       gotoxy(4,9);
       textcolor(WHITE);
       textbackground(BLACK);
       cprintf("6 => Sair");
      }
     op=getch();
    }while(op!=13);

    switch(y-3)
    {
      case 1: found=0;
		of_RW();
		clrscr();
		printf("1 => Inserir Filme:\n");
		x=17;
		do{
		  if ((op==77) && (x==6))
		      x=17;
		  if ((op==75) && (x==17))
		      x=6;
		  if(x==6)
		     {
		      gotoxy(6,3);
		      textcolor(BLACK);
		      textbackground(WHITE);
		      cprintf("Continuar");
		     }
		    else
		     {
		      gotoxy(6,3);
		      textcolor(WHITE);
		      textbackground(BLACK);
		      cprintf("Continuar");
		     }
		     if(x==17)
		     {
		      gotoxy(17,3);
		      textcolor(BLACK);
		      textbackground(WHITE);
		      cprintf("Volver");
		     }
		    else
		     {
		      gotoxy(17,3);
		      textcolor(WHITE);
		      textbackground(BLACK);
		      cprintf("Volver");
		     }
		     op=getch();
		}while(op!=13);
		if(x==17)break;
		_setcursortype(_NORMALCURSOR);
		rewind(data);
		do{
		   file_pos = ftell(data);
		   fread(&Filme,sizeof(Filme),1,data);
		   if(strcmp("###VAZIO###",Filme.Titulo)==0)
		    {
		       found=1;
		       break;
		    }
		}while(!feof(data));
		fclose(data);
		ref();
		rewind(Ref);
		fscanf(Ref,"%i",&referencia);
		fclose(Ref);
		Filme.Referencia=referencia+1;
		if (found==1)
		 {
		  of_RW();
		  fseek(data,file_pos,0);
		  Inserir();
		  _setcursortype(_NOCURSOR);
		  printf("\nDeseja guardar esta registo?");
		  x=17;
		  do{
		    select_SN(14);
		    op=getch();
		  }while(op!=13);
		  if(x==17)break;
		  ref();
		  rewind(Ref);
		  fprintf(Ref,"%i",referencia+1);
		  fclose(Ref);
		  fwrite(&Filme,sizeof(Filme),1,data);
		 }
		if (found==0)
		 {
		  cof_A();
		  Inserir();
		  _setcursortype(_NOCURSOR);
		  printf("\nDeseja guardar este registo?");
		  x=17;
		  do{
		    select_SN(14);
		    op=getch();
		  }while(op!=13);
		  if(x==17)break;
		  ref();
		  rewind(Ref);
		  fprintf(Ref,"%i",referencia+1);
		  fclose(Ref);
		  fwrite(&Filme,sizeof(Filme),1,data);
		 }

		break;
      case 2:   found=0;
		of_RW();
		clrscr();
		printf("2 => Consultar Filme:\n");
		printf("Deseja consultatar por:");
		x=31;
		do{
		 select_pes();
		 op=getch();
		}while(op!=13);
		if(x==31)break;
		_setcursortype(_NORMALCURSOR);
		if(x==6)
		{
		  printf("\n\nIntruduza o Titulo para a pesquisa \n");
		  scanf("%s",titulo);
		  rewind(data);
		  do{
		     fread(&Filme,sizeof(Filme),1,data);
		     if(strcmp(titulo,Filme.Titulo)==0)
		      {
			found=1;
			Mostrar();
			getch();
			break;
		       }
		 }while(!feof(data));
		 if(found==0)
		 {
		  printf("\n\nN�o foi encontrado o  filme com esse Titulo");
		  getch();
		 }
		}
		if(x==17)
		{
		  printf("\n\nIntruduza n� da Refer�ncia para a pesquisa \n");
		  scanf("%i",&referencia);
		  rewind(data);
		  do{
		     fread(&Filme,sizeof(Filme),1,data);
		     if(referencia==Filme.Referencia)
		      {
			found=1;
			Mostrar();
			getch();
			break;
		       }
		 }while(!feof(data));
		 if(found==0)
		  {
		   printf("\n\nN�o foi encontrado o filme com essa refrencia");
		   getch();
		  }
		}
		break;
      case 3: found=0;
		of_RW();
		clrscr();
		printf("3 => Alterar Filme:\n");
		printf("Deseja escolher o filme para altera por:");
		x=31;
		do{
		 select_pes();
		 op=getch();
		}while(op!=13);
		if(x==31)break;
		op2=x;
		_setcursortype(_NORMALCURSOR);
		if(op2==6)
		{
		  printf("\n\nIntruduza o Titulo para a pesquisa \n");
		  scanf("%s",titulo);
		  rewind(data);
		  do{
		     file_pos = ftell(data);
		     fread(&Filme,sizeof(Filme),1,data);
		     if(strcmp(titulo,Filme.Titulo)==0)
		      {
			found=1;
			_setcursortype(_NOCURSOR);
			Mostrar();
			printf("\n\nDeseja alterar este registo?");
			x=17;
			do{
			 select_SN(18);
			 op=getch();
			}while(op!=13);
			if(x==17)
			{
			 op2=0;
			 break;
			}
		      break;
		     }
		 }while(!feof(data));
		 if(found==0)
		 {
		  printf("\n\nN�o foi encontrado o  filme com esse Titulo");
		  getch();
		  break;
		 }
		}
		if(op2==17)
		{
		  printf("\n\nIntruduza n� da Refer�ncia para a pesquisa \n");
		  scanf("%i",&referencia);
		  rewind(data);
		  do{
		     file_pos = ftell(data);
		     fread(&Filme,sizeof(Filme),1,data);
		     if(referencia==Filme.Referencia)
		      {
			found=1;
			_setcursortype(_NOCURSOR);
			Mostrar();
			printf("\n\nDeseja alterar este registo?");
			x=17;
			do{
			 select_SN(18);
			 op=getch();
			}while(op!=13);
			if(x==17)
			{
			 op2=0;
			 break;
			}

			break;
		       }
		 }while(!feof(data));
		 if(found==0)
		 {
		  printf("\n\nN�o foi encontrado o filme com essa refrencia");
		  getch();
		  break;
		 }
		}
	       if ((op2==6) || (op2==17))
		{
		 fclose(data);
		 of_RW();
		 fseek(data,file_pos,0);
		 clrscr();
		 printf("3 => Alterar Filme:\n");
		 Mostrar();
		 _setcursortype(_NORMALCURSOR);
		 Inserir();
		 _setcursortype(_NOCURSOR);
		 printf("\nDeseja guardar este novo registo?");
		 x=17;
		 do{
		   select_SN(19);
		   op=getch();
		 }while(op!=13);
		  if(x==17)break;
		 fwrite(&Filme,sizeof(Filme),1,data);
		}
		break;
      case 4: found=0;
		of_RW();
		clrscr();
		printf("4 => Eliminar Filme:\n");
		printf("Deseja escolher o filme para eliminar por:");
		x=31;
		do{
		 select_pes();
		 op=getch();
		}while(op!=13);
		if(x==31)break;
		_setcursortype(_NORMALCURSOR);

		if(x==6)
		{
		  printf("\nIntruduza o Titulo para a pesquisa \n");
		  gets(titulo);
		  rewind(data);
		  do{
		     file_pos = ftell(data);
		     fread(&Filme,sizeof(Filme),1,data);
		     if(strcmp(titulo,Filme.Titulo)==0)
		      {
			found=1;
			Mostrar();
			break;
		       }
		 }while(!feof(data));
		 if(found==0)
		 {
		  printf("\n\nN�o foi encontrado o  filme com esse Titulo");
		  getch();
		  break;
		 }
		}
		if(x==17)
		{
		  printf("\n\nIntruduza n� da Refer�ncia para a pesquisa \n");
		  scanf("%i",&referencia);
		  rewind(data);
		  do{
		     file_pos = ftell(data);
		     fread(&Filme,sizeof(Filme),1,data);
		     if(referencia==Filme.Referencia)
		      {
			found=1;
			Mostrar();
			break;
		       }
		 }while(!feof(data));
		 if(found==0)
		 {
		  printf("N�o foi encontrado o filme com essa refrencia");
		  getch();
		  break;
		 }
		}
	       if ((x==6) || (x==17))
		{
		 _setcursortype(_NOCURSOR);
		 printf("\n\nDeseja eliminar este registo?");
		 x=17;
		 do{
		   select_SN(18);
		   op=getch();
		 }while(op!=13);
		  if(x==17)break;
		 fclose(data);
		 of_RW();
		 fseek(data,file_pos,0);
		 Apagar();
		 fwrite(&Filme,sizeof(Filme),1,data);
		}
		break;
      case 5:   clrscr();
		printf("\n\tPrograma elaborado em [2000/05/22] e por:\n");
		printf("\n\t\tLu�s Talento n�15 11�E\n");
		printf("\t\tPedro Carreira n�?? 11�E\n");
		printf("\t\tNuno Ildefonso n�?? 11�E\n");
		printf("\t\tJorge March�o n�14 11�E");
		getch();
		break;
      case 6:   exit(0);
		break;
    }
    fclose(data);
}while(y!=9);
}

void cof_A()
{
 if((data=fopen("Dados.dat","a+"))==NULL)
 {
  clrscr();
  //quadro
  printf("ERRO!!! O ficheiro \"Dados.dat\" n�o pode ser aberto ou criado");
  getch();
  exit(1);
}

}
void of_RW()
{
 if((data=fopen("Dados.dat","r+"))==NULL)
	{
	 clrscr();
	 //quadro
	 printf("ERRO!!! O ficheiro \"Dados.dat\" n�o pode ser aberto");
	 getch();
	 exit(1);
	}
}
void Inserir()
{
  printf("\n\n Titulo => ");
  scanf("%s",Filme.Titulo);
  printf(" Realizador => ");
  scanf("%s",Filme.Realizador);
  printf(" Empresa de Realiza��o => ");
  scanf("%s",Filme.Empresa_de_Realizacao);
  printf(" Ano de Realiza��o => ");
  scanf("%i",&Filme.Ano_de_Realizacao);
  printf(" Refer�ncia => %i\n",Filme.Referencia);
  //scanf("%i",&Filme.Referencia);
  printf(" N� de c�pias => ");
  scanf("%i",&Filme.NR_copias);
}
void Mostrar()
{
 printf("\n Titulo => %s",Filme.Titulo);
 printf("\n Realizador => %s",Filme.Realizador);
 printf("\n Empresa de Realiza��o => %s",Filme.Empresa_de_Realizacao);
 printf("\n Ano de Realiza��o => %i",Filme.Ano_de_Realizacao);
 printf("\n Refer�ncia => %i",Filme.Referencia);
 printf("\n N� de c�pias => %i",Filme.NR_copias);
}
void Apagar()
{
  strcpy(Filme.Titulo,"###VAZIO###");
  strcpy(Filme.Realizador,'\0');
  strcpy(Filme.Empresa_de_Realizacao,'\0');
  Filme.Ano_de_Realizacao=0;
  Filme.Referencia=31999;
  Filme.NR_copias=0;
}
void ref()
{
 if((Ref=fopen("Ref.dat","r+"))==NULL)
  if((Ref=fopen("Ref.dat","a+"))!=NULL)
  {
   fprintf(Ref,"0");
   fclose(Ref);
   ref();
  }
  else
  {
   clrscr();
   //quadro
   printf("ERRO!!! O ficheiro \"Ref.dat\" n�o pode ser criado");
   getch();
   exit(1);
  }
}
void select_pes()
{
    if ((op==77) && (x==17))
	x=31;
    if ((op==77) && (x==6))
	x=17;
    if ((op==75) && (x==17))
	x=6;
    if ((op==75)  && (x==31))
	x=17;
    if(x==6)
     {
      gotoxy(6,4);
      textcolor(BLACK);
      textbackground(WHITE);
      cprintf("Titulo");
     }
    else
     {
      gotoxy(6,4);
      textcolor(WHITE);
      textbackground(BLACK);
      cprintf("Titulo");
     }
     if(x==17)
     {
      gotoxy(17,4);
      textcolor(BLACK);
      textbackground(WHITE);
      cprintf("Refer�ncia");
     }
    else
     {
      gotoxy(17,4);
      textcolor(WHITE);
      textbackground(BLACK);
      cprintf("Refer�ncia");
     }
     if(x==31)
     {
      gotoxy(31,4);
      textcolor(BLACK);
      textbackground(WHITE);
      cprintf("Volver");
     }
    else
     {
     gotoxy(31,4);
     textcolor(WHITE);
     textbackground(BLACK);
     cprintf("Volver");
    }
}
void select_SN(int Y)
{
  if ((op==77) && (x==6))
      x=17;
  if ((op==75) && (x==17))
      x=6;
  if(x==6)
     {
      gotoxy(6,Y);
      textcolor(BLACK);
      textbackground(WHITE);
      cprintf("Sim");
     }
    else
     {
      gotoxy(6,Y);
      textcolor(WHITE);
      textbackground(BLACK);
      cprintf("Sim");
     }
     if(x==17)
     {
      gotoxy(17,Y);
      textcolor(BLACK);
      textbackground(WHITE);
      cprintf("N�o");
     }
    else
     {
      gotoxy(17,Y);
      textcolor(WHITE);
      textbackground(BLACK);
      cprintf("N�o");
     }
}