//---------------------------------------------------------------------------

#ifndef GlDeviceH
#define GlDeviceH
//---------------------------------------------------------------------------
#include <gl/gl.h> 
#include <gl/glu.h>

class GlDevice
{
private:
	HDC   gl_HDC;
        HGLRC gl_HRC;
        
public:
        bool Create(void *handle);
        void Init(float w, float h);
        void ShutDwn(void *handle);
        void Show();

        bool LoadTexture(const char *filename, GLuint *texture);
        void UnLoadTexture(GLuint *texture);
};

#endif
 