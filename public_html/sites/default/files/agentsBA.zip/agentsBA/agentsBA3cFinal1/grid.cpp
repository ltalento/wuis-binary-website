//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "grid.h"

#include <vector.h>
#include <math.h>
#include <gl/gl.h>
#include <gl/glu.h>
//---------------------------------------------------------------------------

#pragma package(smart_init)

void Grid::Draw()
{
        glPushMatrix();
        glTranslatef(resolution/2,resolution/2,0);
        //glTranslatef(0,0,0);
        glColor3f(0.5, 0.5, 0.5);


        for(int x=0; x<32;x+=1)
        for(int y=0; y<24;y+=1)
        {
                if(GetNode(x,y)->navigable ) DrawNode(x,y);
        }

        glPopMatrix();


}

Node *Grid::GetNode(int x,int y)
{
        if(x<0 || x>=32 || y<0 || y>=24 )
                return NULL;
        return &nodes[x][y];
}

void Grid::DrawNode(int x,int y)
{
        glPushMatrix();
        int radius = 5;
        glTranslatef(x*resolution,y*resolution,0);
        glBegin(GL_LINE_LOOP);
        for( int a = 0; a<360 ; a+=60)
                glVertex2f(sin(a/57.3) * radius, cos(a/57.3) * radius);
        glEnd();
        glPopMatrix();

        for(int i=-1;i<=1;i++)
        for(int j=-1;j<=1;j++)
                if(!(i==0 && j==0)) DrawEdge(x,y,i,j);

}

void Grid::DrawEdge(int x,int y, int offsetX, int offsetY)
{
        if(GetNode(x+offsetX,y+offsetY)&&
                        GetNode(x+offsetX,y+offsetY)->navigable){
                glBegin(GL_LINES);
                glVertex2f(x*resolution,y*resolution);
                glVertex2f(x*resolution+ offsetX*resolution, y*resolution+ offsetY*resolution);
                glEnd();
        }
}

bool Grid::StepIsValid(Agent *agent, Node *node, int dx, int dy)
{
         //agent->repath=true;
       //  if(node->h + node->g > 30) agent->repath = false;
        if( nodes[node->x+dx][node->y+dy].navigable ){

                if(agent->repath)
                {

                if(node->h + node->g > 15){
                if(agent->IsCollidingAtPoint(node->x*20+dx*10+10,node->y*20+dy*10+10))
                        return false;
                  if(agent->IsCollidingAtPoint(node->x*20+dx*20+10,node->y*20+dy*20+10))
                        return false;
                }
                else{
                    if(agent->IsCollidingAtPoint(agent->x+dx*10,agent->y+dy*10))
                       return false;
                    if(agent->IsCollidingAtPoint(agent->x+dx*20,agent->y+dy*20))
                       return false;
                }
                }
                     
                return true;
        }
        return false;
}

int Dir2Index(int nDir,int &i,int &j)
{
        int dir = nDir;
        if( dir > 7) dir -=8;

        switch(dir){
                case  0: i= 0; j=-1; //N
                         break;
                case  1: i= 1; j=-1; //NE
                         break;
                case  2:i= 1; j= 0; //E
		       	 break;
                case  3:i= 1; j= 1; //SE
                         break;
                case  4:i= 0; j= 1; //S
                         break;
                case  5:i=-1; j= 1; //SW
                         break;
                case  6:i=-1 ;j= 0; //W
                         break;
                case  7:i=-1; j=-1; //NW
                         break;
        }
        return dir;
}

int Angle2Dir(int a)
{
        if(a<0) a+=360;
        //a/=45;
        a=(int)(a/45.0+0.5);
        if(a==8)a=0;   //fazer outra tabela
        int d;
        
        if(a==0) d=2;
        if(a==1) d=3;
        if(a==2) d=4;
        if(a==3) d=5;
        if(a==4) d=6;
        if(a==5) d=7;
        if(a==6) d=0;
        if(a==7) d=1;

        if(a<0&&a>7){
                        return 0;
                        }

        return d;
}

bool TestDir(int i, int f)
{
        /*switch(i){         //max turn 90�
                case  0: if(f==6||f==7||f==0||f==1||f==2)return true;
                         break;
                case  1: if(f==7||f==0||f==1||f==2||f==3)return true;
                         break;
                case  2: if(f==0||f==1||f==2||f==3||f==4)return true;
		       	 break;
                case  3: if(f==1||f==2||f==3||f==4||f==5)return true;
                         break;
                case  4: if(f==2||f==3||f==4||f==5||f==6)return true;
                         break;
                case  5: if(f==3||f==4||f==5||f==6||f==7)return true;
                         break;
                case  6: if(f==4||f==5||f==6||f==7||f==0)return true;
                         break;
                case  7: if(f==5||f==6||f==7||f==0||f==1)return true;
                         break;
        }      */
        switch(i){    //max turn 45�
                case  0: if(f==7||f==0||f==1)return true;
                         break;
                case  1: if(f==0||f==1||f==2)return true;
                         break;
                case  2: if(f==1||f==2||f==3)return true;
		       	 break;
                case  3: if(f==2||f==3||f==4)return true;
                         break;
                case  4: if(f==3||f==4||f==5)return true;
                         break;
                case  5: if(f==4||f==5||f==6)return true;
                         break;
                case  6: if(f==5||f==6||f==7)return true;
                         break;
                case  7: if(f==6||f==7||f==0)return true;
                         break;
        }
        return false;
}

Path *Grid::AStarSearch(Agent *agent,int start_x, int start_y, int dest_x, int dest_y)
{
//        The GetTickCount function retrieves the number of milliseconds that have elapsed since Windows was started.
        //pathtime=GetTickCount();
        for(int x=0; x<32;x++)
        for(int y=0; y<24;y++)
        {
                nodes[x][y].is_in_open_list=false;
                nodes[x][y].is_in_closed_list=false;
                nodes[x][y].dir=0;
        }


        bool is_path_find = false;
        vector<Node*> openList;
        vector<Node*> closedList;

        Node *startNode = &(nodes[start_x][start_y]);
        startNode->h = Heuristic(start_x, start_y, dest_x, dest_y );
        startNode->g = 0;
        startNode->parent = NULL;
        startNode->x = start_x;
        startNode->y = start_y;

        startNode->dir = Angle2Dir(agent->angle);

        if(agent->repath) startNode->dir++;

        startNode->is_in_open_list = true;
        openList.push_back(startNode);

        Node *currNode ;//= startNode;

do{
        //procura a node com menos custo (F=g+h)
        currNode = openList[0];
        for(unsigned int i = 0; i < openList.size(); i++)
                if( (openList[i]->g + openList[i]->h) < (currNode->g + currNode->h)){
                       currNode = openList[i];
                 }

        if (currNode->x == dest_x && currNode->y == dest_y){
                closedList.push_back(currNode);
                is_path_find = true;
                break;
        }

        //remove da open list
        currNode->is_in_open_list = false;
        for(unsigned int i = 0; i < openList.size(); i++)
                if(currNode == openList[i]){
                        openList.erase(openList.begin() + i);
                        break;
                }

        //insere na close list
        currNode->is_in_closed_list = true;
        closedList.push_back(currNode);

        //for(int i=-1; i<=1; ++i)
        //for(int j=-1; j<=1; ++j)     //   for(int d=0; d<8; d++)
                //if(!(i==0 && j==0))

                for(int d=0; d<8; d++)
                {
                int newdir, i, j;
                newdir = Dir2Index(currNode->dir+d,i,j);
                                  /*
                if(!TestDir(currNode->dir,newdir)){ //test max turn
                        Sleep(0);
                        continue;
                }       */
                
                Node *newNode = GetNode(currNode->x+i, currNode->y+j);
                if( newNode && StepIsValid(agent,currNode,i,j) && !newNode->is_in_closed_list){



                        newNode->x = currNode->x+i; newNode->y = currNode->y+j;
                        if(!newNode->is_in_open_list){
                                newNode->parent = currNode;
                                if(abs(i)==1 && abs(j)==1) newNode->g = currNode->g + 14; //cost of going to diagonal
                                else newNode->g = currNode->g + 10;  //cost of going to non-diagonal
                                newNode->h = Heuristic(newNode->x, newNode->y, dest_x, dest_y);
                                newNode->is_in_open_list = true;

                                //newNode->dir = currNode->dir;
                                //newNode->dir = d;//newdir;
                                newNode->dir = newdir;
                                openList.push_back(newNode);
                        }
                        else{
                                if(abs(i)==1 && abs(j)==1) newNode->g = currNode->g + 14; //cost of going to diagonal
                                else newNode->g = currNode->g + 10;  //cost of going to non-diagonal

                                if( newNode->g < newNode->parent->g){
                                        newNode->g = newNode->parent->g;
                                        newNode->parent = currNode->parent;
                                }
                        }//end else

                }
        }//end for

}while( !openList.empty() );

        Path *path = NULL;
        if(is_path_find){
                path = new Path;
                Node *n = closedList[closedList.size()-1];
                while( n->parent != NULL){
                        path->AddPoint(n->x*20+10, n->y*20+10, n->dir);
                        n = n->parent;
                }
                path->Reverse();
        }

        openList.clear();
        closedList.clear();
        agent->repath = false;
        //pathtime=pathtime-GetTickCount();
        return path;
}

int Grid::Heuristic(int ix, int iy, int fx, int fy)
{

     return sqrt( abs(ix-fx)*abs(ix-fx) + abs(iy-fy)*abs(iy-fy) );

/*
Manhattan Method:
H = 10*(abs(currentX-targetX) + abs(currentY-targetY))

Diagonal Shortcut Estimation Method:

xDistance = abs(currentX-targetX)
yDistance = abs(currentY-targetY)
if xDistance > yDistance
     H = 14*yDistance + 10*(xDistance-yDistance)
else
     H = 14*xDistance + 10*(yDistance-xDistance)
end if
*/

/*
int h;
h = 10*(abs(ix-fx) + abs(iy-fy));
return h;*/


}

