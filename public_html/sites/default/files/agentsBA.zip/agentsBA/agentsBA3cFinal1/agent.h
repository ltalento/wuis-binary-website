//---------------------------------------------------------------------------

#ifndef agentH
#define agentH
//---------------------------------------------------------------------------
#include <vector.h>
#include "path.h"

#define MAXRADIUS 20

class  Agent
{

//  private:
public:
        //kontentor com todas as instancias da class
         static vector<Agent*> pool;

         float x, y;
         int radius;
         int angle; //direction

         //behavior
         int currAction; //0=idle 1=moving 2=FollowingPath
         int destX, destY;
         Path *path;
         int currPathPoint;

         bool selected;

         int stuck;
         bool repath;
  public:

        static Agent* Add(float x, float y);

        static void Remove(Agent* agent);

       // void Init();
        void Draw();

        void SetAngleFrom1Point(int Px, int Py);
        void Select();
        void UnSelect();
        bool IsSelected();
        bool ContainPoint(int pX, int pY);
        bool IntersectRectangle(int rx1,int ry1, int rx2, int ry2);

        //orders
        void MoveToPoint(int Px,int Py);
        void FollowPath(Path *path);

        //Actions
        void Moving();
        void FollowingPath();

        //auxs
        bool IsColliding();
        bool IsCollidingAtPoint(int x, int y);

        //
        void Update();

//wait order..
//resume order...

};

#endif
