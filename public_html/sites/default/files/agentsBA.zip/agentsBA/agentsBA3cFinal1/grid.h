//---------------------------------------------------------------------------

#ifndef gridH
#define gridH
//---------------------------------------------------------------------------

#include "path.h"
#include "agent2.h"

struct Node
{
        bool navigable;

        int x;
        int y;
        int dir;
        //int parent;
        Node *parent;
        int h;
        int g;

        bool is_in_open_list;
        bool is_in_closed_list;

        Node()
        {
        navigable=true;
        is_in_open_list=false;
        is_in_closed_list=false;
        }
};

class Grid
{
public:
        int resolution;
        Node nodes[32][24];//640/20=32; 480/20=24


        void Draw();

        Node *GetNode(int x,int y);
        void DrawNode(int x,int y);
        void DrawEdge(int x,int y, int offsetX, int offsetY);

        bool StepIsValid(Agent *agent,Node *node, int dx, int dy);
        Path *AStarSearch(Agent *agent, int start_x, int start_y, int dest_x, int dest_y);
        int Heuristic(int ix, int iy, int fx, int fy);
};

#endif
