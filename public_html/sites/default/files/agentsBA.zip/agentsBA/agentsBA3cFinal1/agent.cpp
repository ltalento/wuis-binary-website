//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include <math.h>
#include <gl/gl.h>
#include <gl/glu.h>

#include "agent.h"
#include "grid.h"
extern Grid grid;//temp

vector<Agent*> Agent::pool;

//---------------------------------------------------------------------------

#pragma package(smart_init)

Agent* Agent::Add(float x, float y)
{
  Agent* newAgent = new Agent;

  newAgent->x=x;
  newAgent->y=y;
  newAgent->radius=10;
  newAgent->angle=180;

  newAgent->currAction=0;
  newAgent->destX=y;
  newAgent->destY=x;

  newAgent->path=NULL;

  newAgent->selected=false;

  newAgent->stuck=0;
    newAgent->repath = false;
  Agent::pool.push_back(newAgent);
  return  newAgent;
}

void Agent::Remove(Agent* agent)
{
        //vector<Agent*>::iterator it;
        for(unsigned int i = 0; i < Agent::pool.size(); i++){
                if(agent == Agent::pool[i]){
                Agent::pool.erase(Agent::pool.begin() + i);
                delete agent;
                break;
                }
        }
}

    /*
void Agent::Init()
{
         x=100; y=100;
         radius=20;
         angle=0;

         currAction=0;
         destX=y;
         destY=x;

         path=NULL;

         selected=false;

         //Agent::pool.push_back(this);
} */

void Agent::Draw()
{
        glPushMatrix();
        glTranslatef(x,y,0);
        glRotatef(angle,0.0f,0.0f,1.0f);
        int x1=0, y1=0;
        if(selected) glColor3f(1, 1, 0);
        else glColor3f(1, 0, 0);

        glBegin(GL_LINE_LOOP);
                for( int i = 0; i<360 ; i+=20)
                        glVertex2f(x1 + sin(i/57.3) * radius, y1 + cos(i/57.3) * radius);
        glEnd();

        glBegin(GL_POLYGON);
               glVertex2f(x1 + cos(0) * radius, y1 - sin(0) * radius);
               glVertex2f(x1 + cos(120/57.3) * radius, y1 + sin(120/57.3) * radius);
               glVertex2f(x1 , y1);
               glVertex2f(x1 + cos(240/57.3) * radius, y1 + sin(240/57.3) * radius);
        glEnd();
        glPopMatrix();
}

void Agent::SetAngleFrom1Point(int Px, int Py)
{
     int Vx, Vy;
     Vx = Px - this->x;
     Vy = Py - this->y;
     //agent.angle = atan(Vy/Vx);
     //if(Vy!=Vx && Vx!=0)
     if(Vx!=0)
     this->angle = atan2(Vy, Vx)*57.3;
}

void Agent::Select()
{
        selected=true;
}

void Agent::UnSelect()
{
        selected=false;
}
bool Agent::IsSelected()
{
        return selected;
}

//Intersection
//intersect
bool Agent::ContainPoint(int pX, int pY)
{
  int dx = abs(pX-x);
  int dy = abs(pY-y);

  if(sqrt(dx*dx+dy*dy)<=radius)  return true;

  return false;
}

bool Agent::IntersectRectangle(int rx1,int ry1, int rx2, int ry2) //tmp
{
        if(rx1>rx2){
                int tmp = rx1;
                rx1=rx2;
                rx2=tmp;
        }
        if(ry1>ry2){
                int tmp = ry1;
                ry1=ry2;
                ry2=tmp;
        }

	if(x >= rx1 && y >= ry1 && x <= rx2 && y <= ry2)
		return true;
	return false;
}

//////////////////
void Agent::MoveToPoint(int Px, int Py)
{
    currAction=1;
    destX=Px;
    destY=Py;
    SetAngleFrom1Point(Px,Py);
}

void Agent::FollowPath(Path *path)
{
   if(path){
        this->path = path;
        currAction=2;
        currPathPoint=0;
        if(currPathPoint < path->GetNrPoints() )
                path->GetPoint(currPathPoint,&destX,&destY);
        SetAngleFrom1Point(destX,destY);
   }

}
///////
void Agent::Moving()
{



        x +=cos(angle/57.3)*1;
        y +=sin(angle/57.3)*1;
        if( x>destX-2 && y>destY-2 && x<destX+2 && y<destY+2) currAction=0;
}

void Agent::FollowingPath()
{

        if(path){
      if(currPathPoint < path->GetNrPoints() )
      {
      SetAngleFrom1Point(destX,destY);
      if(!IsColliding() && stuck==0){
        stuck=0;
        x +=cos(angle/57.3)*1;
        y +=sin(angle/57.3)*1;
        //radius=8;

      }else{


                stuck++;
                if(stuck>=33) //wait 1 secund
                {
                        //finish near of the objective
                        if(currPathPoint>=path->GetNrPoints()-1){
                         stuck =0;
                         currAction = 0;
                         }
                        else{
                                //need to repath
                                //check for collision on the neighbors
                                //radius=7;
                                stuck =0;
                                repath=true;
                                int X;
                                int Y;
                                path->GetPoint( path->GetNrPoints()-1 ,&X,&Y);
                                //

                                Path *newPath=NULL;
                                newPath=grid.AStarSearch(this,this->x/20, this->y/20, (X-10)/20, (Y-10)/20);
                                if(newPath){
                                        delete path;
                                        path =  newPath;
                                }
                                FollowPath(path);
                                Sleep(0);
                        }



                }
        }




        if( x>destX-2 && y>destY-2 && x<destX+2 && y<destY+2){
           if(currPathPoint < path->GetNrPoints() ) {
                currPathPoint++;
                path->GetPoint(currPathPoint,&destX,&destY);
                //SetAngleFrom1Point(destX,destY);

           }else currAction=0;
        }
      }else  currAction=0; //if tiver pontos



                 }//if path
}

bool Agent::IsColliding()
{
        float my_pred_x = x + cos(angle/57.3)*1;
        float my_pred_y = y + sin(angle/57.3)*1;
        float dir_x =  cos(angle/57.3);//my_pred_x - x;
        float dir_y =  sin(angle/57.3);//my_pred_y - y;
        float dir_n = sqrt(dir_x*dir_x + dir_y*dir_y);

        for(unsigned int i = 0; i < Agent::pool.size(); i++){
                if(this!=Agent::pool[i]){
                        Agent *other = Agent::pool[i];
                        float other_pred_x = other->x + cos(other->angle/57.3)*1;
                        float other_pred_y = other->y + sin(other->angle/57.3)*1;
                        float dist_x  = (other_pred_x - my_pred_x);
                        float dist_y  = (other_pred_y - my_pred_y);
                        float dist_n = sqrt(dist_x*dist_x + dist_y*dist_y);
                        float tmp1 = (dir_x*dist_x + dir_y*dist_y);
                        float tmp2 = (dist_n*dir_n);
                        if(tmp1>tmp2) tmp1=tmp2;//certifica que o dominio de acos fika entre -1 e 1
                        float tmp3 =  tmp1/tmp2;
                        if(tmp3>1)tmp3=1;if(tmp3<-1)tmp3=-1;
                        float angle_dir_dist=0;
                        try{
                                angle_dir_dist = acos( tmp3 );
                        }
                        catch (Exception &exception)
                        {
                                Application->ShowException(&exception);
                        }
                              /*
                         if(dist_n<(radius+other->radius)){
                         x += cos(angle/57.3)*(dist_n-(radius+other->radius));
                         y += sin(angle/57.3)*(dist_n-(radius+other->radius));
                         }  */

                        if(dist_n<(radius+other->radius) && abs(angle_dir_dist)<0.1) return true;


                }
        }
        return false;
}

bool Agent::IsCollidingAtPoint(int x, int y)
{
        for(unsigned int i = 0; i < Agent::pool.size(); i++){
                if(this!=Agent::pool[i]){
                        Agent *other = Agent::pool[i];
                        float dist_x  = other->x - x;
                        float dist_y  = other->y - y;
                        float dist_n = sqrt(dist_x*dist_x + dist_y*dist_y);
                        if(dist_n<=(radius+other->radius)) return true;
                }
        }

        return false;
}

////////
void Agent::Update()
{
        switch(currAction)
        {
                case 0:
                        break;
                case 1:
                      Moving();
                        break;
                case 2:
                        FollowingPath();
                        break;
        }
}


