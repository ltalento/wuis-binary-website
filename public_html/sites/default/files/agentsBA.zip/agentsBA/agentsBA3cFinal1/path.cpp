//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include <math.h>
#include <gl/gl.h>
#include <gl/glu.h>

#include "path.h"

//---------------------------------------------------------------------------

#pragma package(smart_init)

Path::Path()
{
        this->Clear();
}

void Path::Clear()
{
        nrPoints=0;
        for(int i=0; i<MAXPOINTS; i++){
                points[i][0]=0; points[i][1]=0; points[i][2]=0;
                }
}

void Path::AddPoint(int pX, int pY, int dir)
{
        if(nrPoints <= MAXPOINTS){
                points[nrPoints  ][0]=pX;
                points[nrPoints  ][1]=pY;
                points[nrPoints++][2]=dir;
        }
}

void Path::GetPoint(int indx, int *pX, int *pY)
{
        if(nrPoints <= MAXPOINTS){
                *pX=this->points[indx][0];
                *pY=this->points[indx][1];
        }
}

int Path::GetNrPoints()
{
        return  nrPoints;
}

void Path::Reverse()
{
        int tmp[MAXPOINTS][3];
      /*  for(int i=1;i<=nrPoints;i++){
             tmp[i-1][0] = points[nrPoints-i][0];
             tmp[i-1][1] = points[nrPoints-i][1];
        }*/
        for(int i=0;i<nrPoints;i++){
             tmp[i][0] = points[nrPoints-i-1][0];
             tmp[i][1] = points[nrPoints-i-1][1];
             tmp[i][2] = points[nrPoints-i-1][2];
        }
        for(int i=0;i<nrPoints;i++){
             points[i][0] = tmp[i][0];
             points[i][1] = tmp[i][1];
             points[i][2] = tmp[i][2];
        }
}

void Path::Draw()
{
      /*
  int radius = 5;

  int oldX;
  int oldY;

  glPushMatrix();
  for(int i=0; i<nrPoints; i++)
  {
    if(i!=0){
       glColor3f(0, 1, 1);
       glBegin(GL_LINES);
              glVertex2f(oldX,oldY);
              glVertex2f(points[i][0],points[i][1]);
       glEnd();
    }

    glPushMatrix();
        glTranslatef(points[i][0],points[i][1],0);
        glColor3f(0, 1, 0);
        glBegin(GL_POLYGON);
                for( int j = 0; j<360 ; j+=60)
                        glVertex2f(sin(j/57.3) * radius, cos(j/57.3) * radius);
        glEnd();
    glPopMatrix();

    oldX=points[i][0];
    oldY=points[i][1];

  }
  glPopMatrix(); */

  //draw dir arrow
  glPushMatrix();
        for(int i=0; i<nrPoints; i++){
                glPushMatrix();
                glTranslatef(points[i][0],points[i][1],0);
                glColor3f(0, 1, 0);
                int angle=0;
                int dir=points[i][2];
                if(dir==0)angle= - 90;
                if(dir==1)angle= - 45;
                if(dir==2)angle=   0;
                if(dir==3)angle= -315;
                if(dir==4)angle= -270;
                if(dir==5)angle= -225;
                if(dir==6)angle= -180;
                if(dir==7)angle= -135;
                glRotatef(angle,0.0f,0.0f,1.0f);

                glBegin(GL_POLYGON);
                      glVertex2f(  8 , 0);
                      glVertex2f( 0 , -8);
                      glVertex2f( 0 , -4);
                      glVertex2f( -8 , -4);
                      glVertex2f( -8 , 4);
                      glVertex2f(  0 , 4);
                      glVertex2f(  0 , 8);
                glEnd();

                glPopMatrix();
        }
  glPopMatrix();
}
