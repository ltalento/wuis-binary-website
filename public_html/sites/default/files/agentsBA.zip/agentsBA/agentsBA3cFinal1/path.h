//---------------------------------------------------------------------------

#ifndef pathH
#define pathH
//---------------------------------------------------------------------------

#define MAXPOINTS 50

class Path
{
private:
        int nrPoints;
        int points[MAXPOINTS][3];

public:
        Path();

        void Clear();
        void AddPoint(int pX, int pY, int dir);

        void GetPoint(int indx,int *pX, int *pY);
        int GetNrPoints();
        void Reverse();

        void Draw();

};


#endif
