//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include <math.h>

#include "frmTest.h"
#include "GlDevice.h"
#include "agent2.h"
#include "path.h"
#include "grid.h"
#include "Map.h"

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
GlDevice gl;

Agent *agentSelected = NULL;

//Path  *path = NULL;
Grid grid;
Map  map;
TextureImage tiles[35];
GLuint fdp=0;
bool simPause=false;

int StartX, StartY;
int EndX, EndY;
bool IsDrawing;

int medx=0;
int medy=0;

bool updating = false;

//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
    gl.Create(Panel1->Handle);
    gl.Init(Panel1->Width ,Panel1->Height );

    //gl.LoadTexture("..\\tiles\\1.bmp",&fdp);

    for(int i=0; i<35;i++)
        {
                AnsiString file = i;
                file = "..\\tiles\\" + file + ".tga";
                 //file =  "..\\tiles\\0.tga";
                //gl.LoadTexture(file.c_str(),&dasstiles[i]);
                gl.LoadTGA (&tiles[i],file.c_str());

        }
    map.Init(32,32,35,tiles);
    map.LoadFromFile("map.txt");



    grid.resolution = 20;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Timer1Timer(TObject *Sender)
{
        updating = true;
        int pathtime=0;
        
        glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
        glLoadIdentity();

        //Rubber Band box or selection box
        if(IsDrawing){
        glPushMatrix();
        glTranslatef(0,0,0);
        glColor3f(0.0, 1.0, 0.0);
        glBegin(GL_LINE_LOOP);
                glVertex2f(StartX, StartY);
                glVertex2f(EndX, StartY);
                glVertex2f(EndX, EndY);
                glVertex2f(StartX, EndY);
                glVertex2f(StartX, StartY);
        glEnd();
        glPopMatrix();}

        pathtime = GetTickCount();

        if(!simPause){
        for(unsigned int i = 0; i < Agent::pool.size(); i++){
                Agent *agent = Agent::pool[i];
                agent->CalculatePredictedPositions();
        }
        for(unsigned int i = 0; i < Agent::pool.size(); i++){
                Agent *agent = Agent::pool[i];
                agent->Update();
        }
        }


               //pathtime=pathtime-GetTickCount();
        for(unsigned int i = 0; i < Agent::pool.size(); i++){
                Agent *agent = Agent::pool[i];

                if(cbxAgents->Checked)
                        agent->Draw();

                if(cbxPath->Checked)
                        if(agent->path)
                                agent->path->Draw();
        }

                //if(path) path->Draw();


    glPushMatrix();
        glTranslatef(medx,medy,0);
        glColor3f(1, 0.5, 0);
        glBegin(GL_POLYGON);
                for( int j = 0; j<360 ; j+=60)
                        glVertex2f(sin(j/57.3) * 10, cos(j/57.3) * 10);
        glEnd();
    glPopMatrix();

        if(cbxGrid->Checked)
                grid.Draw();

        map.Draw();

        gl.Show();

        Label6->Caption = (GetTickCount()-pathtime);
        updating=false;
}
//---------------------------------------------------------------------------



void __fastcall TForm1::Panel1MouseMove(TObject *Sender, TShiftState Shift,
      int X, int Y)
{

   if(IsDrawing){
    EndX = X;
    EndY = Y;
    }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Panel1MouseUp(TObject *Sender, TMouseButton Button,
      TShiftState Shift, int X, int Y)
{
      IsDrawing = false;
      if(btnNodeMode->Down){
               // X+=10; Y+=10;
                if(grid.GetNode(X/20,Y/20)){

                if(grid.GetNode(X/20,Y/20)->navigable)
                        grid.GetNode(X/20,Y/20)->navigable=false;
                else
                        grid.GetNode(X/20,Y/20)->navigable=true;

                }
      }

      if(btnAgentMode->Down /*&& agentSelected */&& Button == mbRight && !updating){
                Timer1->Enabled = false;
                //move selected untis
                int minx=3200,miny=3200,maxx=0,maxy=0;

                for(unsigned int i = 0; i < Agent::pool.size(); i++){
                Agent *agent = Agent::pool[i];
                        if(agent->IsSelected()){
                                if(minx>(agent->x))minx=(agent->x);
                                if(miny>(agent->y))miny=(agent->y);

                                if(maxx<(agent->x))maxx=(agent->x);
                                if(maxy<(agent->y))maxy=(agent->y);
                        }
                }
                 medx = (maxx-minx)/2 + minx ;
                 medy = (maxy-miny)/2 + miny  ;
                 int destx = X/20;
                 int desty = Y/20;
                for(unsigned int i = 0; i < Agent::pool.size(); i++){
                Agent *agent = Agent::pool[i];
                        if(agent->IsSelected()){
                                //int destx = (agent->x-medx)/20+ X/20;
                                //int desty = (agent->y-medy)/20+ Y/20;
                                //DestPosition(i,X/20, Y/20, &destx, &desty);

                                agent->MoveToNode(destx, desty);
                                destx++;
                                if(((i+1)%3)==0){desty++; destx = X/20;}



                        }
                }
                 Timer1->Enabled = true;
      }

      if(btnAddAgent->Down){

                Agent::Add((float)(X/20)*20+10,(float)(Y/20)*20+10);
      }

      if(btnAgentMode->Down && Button == mbLeft){

             for(unsigned int i = 0; i < Agent::pool.size(); i++){
                Agent *agent = Agent::pool[i];
                if(agent->IntersectRectangle(StartX,StartY,EndX,EndY)||
                agent->ContainPoint(X,Y))
                {
                        agent->Select();

                        agentSelected=agent;
                        //fill the agent box
                        char tmp[100]="";
                        sprintf(tmp,"Agent: %p",agent);
                        gbxAgentProp->Caption = tmp;
                        edtAgentX->Text = agent->x;
                        edtAgentY->Text = agent->y;
                        edtAgentR->Text = agent->radius;
                        edtAgentA->Text = agent->angle;
                        sprintf(tmp,"%p",agent->path);
                        edtAgentP->Text=tmp;
                        //break;
                }
                else  agent->UnSelect();
             }
      }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::btnGoClick(TObject *Sender)
{
        simPause =  !simPause;
        if(!simPause) btnGo->Caption="||";
        else btnGo->Caption="|>";
}
//---------------------------------------------------------------------------

void __fastcall TForm1::btnAgenBxApplyClick(TObject *Sender)
{
//
        if(agentSelected){
                agentSelected->x = edtAgentX->Text.ToDouble();
                agentSelected->y = edtAgentY->Text.ToDouble();
                agentSelected->radius = edtAgentR->Text.ToInt();
                agentSelected->angle = edtAgentA->Text.ToInt();
        }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::FormDestroy(TObject *Sender)
{
//quit
      for(unsigned int i = 0; i < Agent::pool.size(); i++){
                Agent *agent = Agent::pool[i];
                if(agent->path) delete agent->path;
                delete agent;
     }
     Agent::pool.clear();
     //if(path) delete path;

         for(int i=0; i<35;i++)
        {
                gl.UnLoadTexture(&(tiles[i].texID) );
        }

}
//---------------------------------------------------------------------------

void __fastcall TForm1::btnAgenBxRemoveClick(TObject *Sender)
{
        if(agentSelected->path) delete agentSelected->path;
        Agent::Remove(agentSelected);
        agentSelected=NULL;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Panel1MouseDown(TObject *Sender,
      TMouseButton Button, TShiftState Shift, int X, int Y)
{
    StartX = X;
    StartY = Y;

    EndX   = X;
    EndY   = Y;
    
    IsDrawing=true;
}
//---------------------------------------------------------------------------



void __fastcall TForm1::btnSaveNavMeshClick(TObject *Sender)
{
        grid.SaveToFile("NavMesh.txt");
}
//---------------------------------------------------------------------------

void __fastcall TForm1::btnLoadNavMeshClick(TObject *Sender)
{
        grid.LoadFromFile("NavMesh.txt");
}
//---------------------------------------------------------------------------

void DestPosition(int i, int X, int Y, int &destx, int &desty)
{

//      for (int j=i;

}
