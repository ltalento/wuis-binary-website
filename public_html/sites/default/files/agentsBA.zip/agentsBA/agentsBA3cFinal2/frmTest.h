//---------------------------------------------------------------------------

#ifndef frmTestH
#define frmTestH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <Buttons.hpp>
#include <ActnList.hpp>
#include <Menus.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
        TTimer *Timer1;
        TPanel *Panel1;
        TButton *btnGo;
        TSpeedButton *btnAgentMode;
        TGroupBox *gbxAgentProp;
        TLabel *Label1;
        TEdit *edtAgentX;
        TButton *btnAgenBxApply;
        TLabel *Label2;
        TEdit *edtAgentY;
        TLabel *Label3;
        TEdit *edtAgentR;
        TLabel *Label4;
        TEdit *edtAgentA;
        TLabel *Label5;
        TSpeedButton *btnAddAgent;
        TButton *btnAgenBxRemove;
        TSpeedButton *btnNodeMode;
        TLabel *Label6;
        TMainMenu *MainMenu1;
        TEdit *edtAgentP;
        TGroupBox *GroupBox1;
        TCheckBox *cbxPrepos;
        TCheckBox *cbxPath;
        TCheckBox *cbxAgents;
        TCheckBox *cbxGrid;
        TButton *btnSaveNavMesh;
        TButton *btnLoadNavMesh;
        void __fastcall Timer1Timer(TObject *Sender);
        void __fastcall Panel1MouseMove(TObject *Sender, TShiftState Shift,
          int X, int Y);
        void __fastcall Panel1MouseUp(TObject *Sender, TMouseButton Button,
          TShiftState Shift, int X, int Y);
        void __fastcall btnGoClick(TObject *Sender);
        void __fastcall btnAgenBxApplyClick(TObject *Sender);
        void __fastcall FormDestroy(TObject *Sender);
        void __fastcall btnAgenBxRemoveClick(TObject *Sender);
        void __fastcall Panel1MouseDown(TObject *Sender,
          TMouseButton Button, TShiftState Shift, int X, int Y);
        void __fastcall btnSaveNavMeshClick(TObject *Sender);
        void __fastcall btnLoadNavMeshClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
