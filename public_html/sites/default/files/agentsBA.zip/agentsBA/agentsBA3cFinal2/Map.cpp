//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include <gl/gl.h>
#include <gl/glu.h>
#include <fstream.h>
#include "Map.h"

//---------------------------------------------------------------------------
#pragma package(smart_init)



int fuck=0;
extern GLuint fdp;

//TextureImage xxx;

Map::Map()
{

tileGrid=NULL;

nr_tiles=0;
tiles=NULL;

width=0;
height=0;

}

Map::~Map()
{
     if(tileGrid){
        for(int i=0;i<width;i++)
                delete tileGrid[i];
        delete[]  tileGrid;
     }

     
}
///////
void Map::Init(int width, int height, int nr_tiles, TextureImage *tiles)
{
   
        this->width=width;
        this->height=height;
        
        this->nr_tiles = nr_tiles;
        
        this->tiles = tiles;
        

        //
        tileGrid = new int*[width];
        for(int i=0;i<width;i++)
                tileGrid[i]= new int[height];
        //
        for(int x=0;x<width;x++)
                for(int y=0;y<height;y++)
                  tileGrid[x][y]=-1;

       
}
//
void Map::Draw()
{
        glEnable(GL_TEXTURE_2D);
        glPushMatrix();
        //glTranslatef(resolution/2,resolution/2,0);
        glTranslatef(0,0,0);
        glColor3f(1.0, 1.0, 1.0);


        for(int x=0; x<32;x+=1)
        for(int y=0; y<24;y+=1)
        {

        glPushMatrix();

        glTranslatef(x*48,y*48,0);
        //glTranslatef(48,48,0);
        glBindTexture(GL_TEXTURE_2D, tiles[tileGrid[x][y]].texID );
//         glBindTexture(GL_TEXTURE_2D,  tiles[0].texID );
         glBegin(GL_QUADS);
	        glNormal3f(0, 0, 1);
                glTexCoord2f(1, 1);  glVertex2f(48,0);  //
                glTexCoord2f(0, 1);  glVertex2f(0,0);
                glTexCoord2f(0, 0);  glVertex2f(0,48);  //-
                glTexCoord2f(1, 0);  glVertex2f(48,48);


        glEnd();
        glPopMatrix();
        }

        glPopMatrix();
          glDisable(GL_TEXTURE_2D);
}
//
//void Map::DrawDebugTilesGrid(TCanvas *Canvas)
//{

//}
//
//

//
void Map::LoadFromFile(char *filename)
{

      if(tileGrid){
        for(int i=0;i<width;i++)
                delete tileGrid[i];
        delete[]  tileGrid;
     }

   ifstream file;
   istream  *pFile;
   file.open(filename);
   pFile = &file;
   (*pFile) >> width;
   char x;
   (*pFile) >> x;
   (*pFile) >> height;

   tileGrid = new int*[width];
   for(int i=0;i<width;i++)
        tileGrid[i]= new int[height];

   for(int y=0; y<height; y++)
        for(int x=0; x<width; x++)
         (*pFile)  >> tileGrid[x][y];


   file.close();
}/*
void Map::SaveToFile(char *filename)
{
   ofstream file;
   ostream  *pFile;
   file.open(filename);
   pFile = &file;
   (*pFile)  << width << "x" << height << endl;
   for(int y=0; y<height; y++){
        for(int x=0; x<width; x++){
         (*pFile)  << tileGrid[x][y] << " ";
        }
       (*pFile) << endl;
   }
   file.close();
}*/
//
/*void Map::AddTile(int grid_x, int grid_y, int tile_index)
{
       tileGrid[grid_x][grid_y] = tile_index % nr_tiles;
}
void Map::RemoveTile(int grid_x, int grid_y)
{
        tileGrid[grid_x][grid_y] = -1;
}
*/