//---------------------------------------------------------------------------

#ifndef MapH
#define MapH
//---------------------------------------------------------------------------

#define MAXOBJS 20
 #include "GlDevice.h"
class Map
{
private:
int **tileGrid;
int nr_tiles;

TextureImage *tiles;

int width;
int height;




public:
        Map();
        ~Map();

        void Init(int width, int height, int nr_tiles, TextureImage *tiles);


        void Draw();
        //void DrawDebugTilesGrid(TCanvas *Canvas);

        void LoadFromFile(char *filename);
        //void SaveToFile(char *filename);

        //void AddTile(int grid_x, int grid_y, int tile_index);
        //void RemoveTile(int grid_x, int grid_y);

};

#endif
