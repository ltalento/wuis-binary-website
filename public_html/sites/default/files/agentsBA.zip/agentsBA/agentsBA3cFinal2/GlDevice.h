//---------------------------------------------------------------------------

#ifndef GlDeviceH
#define GlDeviceH
//---------------------------------------------------------------------------
#include <gl/gl.h> 
#include <gl/glu.h>

typedef struct// Create A Structure
{
GLubyte *imageData;// Image Data (Up To 32 Bits)
GLuint bpp;// Image Color Depth In Bits Per Pixel
GLuint width;// Image Width
GLuint height;// Image Height
GLuint texID;// Texture ID Used To Select A Texture
} TextureImage;// Structure Name


class GlDevice
{
private:
	HDC   gl_HDC;
        HGLRC gl_HRC;
        
public:
        bool Create(void *handle);
        void Init(float w, float h);
        void ShutDwn(void *handle);
        void Show();

        bool LoadTexture(const char *filename, GLuint *texture);
        void UnLoadTexture(GLuint *texture);
        bool LoadTGA(TextureImage *texture, char *filename);
};

#endif
 