//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include <math.h>
#include <gl/gl.h>
#include <gl/glu.h>
#include <gl/glaux.h>
 #include <assert.h>

#include "agent2.h"
#include "grid.h"

//---------------------------------------------------------------------------
#pragma comment(lib, "GLAUX.LIB")

#pragma package(smart_init)

#define PATH_POINT_TOLERANCE 1

extern Grid grid;//temp

vector<Agent*> Agent::pool;

void Soldier();
void Tank();
void Veicle();

Agent* Agent::Add(float x, float y)
{
  Agent* newAgent = new Agent;

  newAgent->x=x;
  newAgent->y=y;
  newAgent->radius=6;
  newAgent->angle=180;

  newAgent->currAction=0;
  newAgent->destinationNodeX=0;
  newAgent->destinationNodeY=0;

  newAgent->path=NULL;

  newAgent->selected=false;

  newAgent->stuck=0;
  newAgent->repath = false;
  newAgent->delayTime=16;

  newAgent->reserveNode1=NULL;
  newAgent->reserveNode2=NULL;

  randomize();
  newAgent->model= 0;//rand() % 3;

  Agent::pool.push_back(newAgent);
  return  newAgent;
}

void Agent::Remove(Agent* agent)
{
        //vector<Agent*>::iterator it;
        for(unsigned int i = 0; i < Agent::pool.size(); i++){
                if(agent == Agent::pool[i]){
                Agent::pool.erase(Agent::pool.begin() + i);
                delete agent;
                break;
                }
        }
}

void Agent::Draw()
{



        glPushMatrix();
        glTranslatef(x,y,20);
        glRotatef(45,1.0f,0.0f,0.0f);
        glRotatef(angle,0.0f,0.0f,1.0f);
       // int x1=0, y1=0;
        if(selected) glColor3f(1, 1, 0);
        else glColor3f(1, 0, 0);


        switch(model)
        {
        case 0: Soldier();
                break;
        case 1: Tank();
                break;
        case 2: Veicle();
                break;
        }

                /*
        glBegin(GL_LINE_LOOP);
                for( int i = 0; i<360 ; i+=20)
                        glVertex2f(x1 + sin(i/57.3) * radius, y1 + cos(i/57.3) * radius);
        glEnd();

        glBegin(GL_POLYGON);
               glVertex2f(x1 + cos(0) * radius, y1 - sin(0) * radius);
               glVertex2f(x1 + cos(120/57.3) * radius, y1 + sin(120/57.3) * radius);
               glVertex2f(x1 , y1);
               glVertex2f(x1 + cos(240/57.3) * radius, y1 + sin(240/57.3) * radius);
        glEnd();    */



        glPopMatrix();

        //draw predictewd positions
        for (int j=0; j<MAXPREPOS; j+=5){
                glPushMatrix();
                glTranslatef(predictdPos[j][0],predictdPos[j][1],0);

                glColor3f(1, 1, 1);

                glBegin(GL_LINE_LOOP);
                        for( int i = 0; i<360 ; i+=20)
                                glVertex2f( sin(i/57.3) * radius,  cos(i/57.3) * radius);
                glEnd();
                glPopMatrix();
        }    
}

void Agent::SetAngleFrom1Point(int Px, int Py)
{
     int Vx, Vy;
     Vx = Px - this->x;
     Vy = Py - this->y;
     if(Vx==0){
        if(Vy>=0)this->angle=90;  //atan(+inf)
        else     this->angle=-90; //atan(-inf)
     }else
        this->angle = atan2(Vy, Vx)*57.3;
}

void Agent::Select()
{
        selected=true;
}

void Agent::UnSelect()
{
        selected=false;
}
bool Agent::IsSelected()
{
        return selected;
}

//Intersection
//intersect
bool Agent::ContainPoint(int pX, int pY)
{
  int dx = abs(pX-x);
  int dy = abs(pY-y);

  if(sqrt(dx*dx+dy*dy)<=radius)  return true;

  return false;
}

bool Agent::IntersectRectangle(int rx1,int ry1, int rx2, int ry2) //tmp
{
        if(rx1>rx2){
                int tmp = rx1;
                rx1=rx2;
                rx2=tmp;
        }
        if(ry1>ry2){
                int tmp = ry1;
                ry1=ry2;
                ry2=tmp;
        }

	if(x >= rx1 && y >= ry1 && x <= rx2 && y <= ry2)
		return true;
	return false;
}

//////////////////
void Agent::MoveToNode(int nx, int ny)
{
   if(!(nx==int(x)/20 && ny==int(y)/20) && nx<32 && nx>=0 && ny<24 && ny>=0
                                                && grid.nodes[nx][ny].navigable)//
   {



    if(path){ delete path; path=NULL;}

    path = grid.AStarSearch(this,this->x/20, this->y/20, nx, ny);

    if(path && path->GetNrPoints()!=0){
        //if( path->GetNrPoints()==0 )
               //assert(path->GetNrPoints()==0);
               // Sleep(100);

        currAction = 1;
        destinationNodeX = nx;
        destinationNodeY = ny;

        currPathPointIndx=0;
        path->GetPoint(currPathPointIndx, &currPathPointX, &currPathPointY);
        //SetAngleFrom1Point(currPathPointX,currPathPointY);
    }else if(path){ delete path; path=NULL; }


    }
}

///////
void Agent::Moving()
{
        if(reserveNode1)reserveNode1->navigable=true;
        if(reserveNode2)reserveNode2->navigable=true;

        assert(path->GetNrPoints()!=0);
        assert(path!=NULL);

        if(!IsReachedCurrentPathPoint()){
                SetAngleFrom1Point(currPathPointX,currPathPointY);
                if(!IsColliding()/*&& stuck==0*/){
                        x +=cos(angle/57.3)*1;
                        y +=sin(angle/57.3)*1;
                        stuck=0;
                }
                else{
                        stuck++;
                        if(stuck >= delayTime){
                                if(IsNearDestination()){
                                        stuck=0;
                                        currAction = 0;
                                        delete path;
                                        path=NULL;
                                }
                                else{
                                        //need to repath
                                        stuck =0;
                                        repath=true;
                                        Path *newPath=NULL;

                                        reserveNode1->navigable=false;
                                        reserveNode2->navigable=false;

                                        newPath=grid.AStarSearch(this,this->x/20, this->y/20,
                                                        destinationNodeX, destinationNodeY);

                                        reserveNode1->navigable=true;
                                        reserveNode2->navigable=true;

                                        if(newPath){
                                                delete path;
                                                path =  newPath;
                                                currPathPointIndx=0;
                                                path->GetPoint(currPathPointIndx, &currPathPointX, &currPathPointY);
                                                //int rx, ry;
                                                //path->GetPoint(0,&rx,&ry);
                                                //reserveNode1=&grid.nodes[rx/20][ry/20];
                                                //reserveNode2=&grid.nodes[int(x/20)][int(y/20)];
                                        }

                                }
                        }
                }

        }
        else if(!IsReachedDestination()){
                path->GetPoint(++currPathPointIndx, &currPathPointX, &currPathPointY);
        }
        else{
                delete path;
                path=NULL;
          currAction = 0; //done
        }
}


bool Agent::IsReachedCurrentPathPoint()
{
        if( abs(currPathPointX-x)<PATH_POINT_TOLERANCE &&
                abs(currPathPointY-y)<PATH_POINT_TOLERANCE) return true;
        return false;

}

bool Agent::IsReachedDestination()
{
        assert(path!=NULL);
        assert(path->GetNrPoints()!=0);
        if(currPathPointIndx+1 == path->GetNrPoints() /*&& IsReachedCurrentPathPoint()*/)
                return true;
        return false;
}

bool Agent::IsNearDestination()
{
        assert(path!=NULL);
        assert(path->GetNrPoints()!=0);
        if(currPathPointIndx+2 >= path->GetNrPoints()) return false;
        return false;
}

void Agent::CalculatePredictedPositions()
{
    //float predictdPos[20][3];//x,y,dir
    //int nrPredictedPos=20;
    int pathPoint=currPathPointIndx;
    int pathPointX=currPathPointX, pathPointY=currPathPointY;
    float predX=x, predY=y;
    int Vx, Vy;
    float predAngle;
    predictdPos[0][0]=predX;
    predictdPos[0][1]=predY;
    for(int i=1;i<MAXPREPOS;i++){
        if(path && path->GetNrPoints()!=0 && currAction==1){
                if( !(abs(pathPointX-predX)<PATH_POINT_TOLERANCE &&
                        abs(pathPointY-predY)<PATH_POINT_TOLERANCE))//!IsReachedCurrentPathPoint
                {
                        //SetAngleFrom1Point(pathPointX, pathPointY);
                        Vx = pathPointX - predX;
                        Vy = pathPointY - predY;
                        if(Vx==0){
                                if(Vy>=0)predAngle=90;  //atan(+inf)
                                else     predAngle=-90; //atan(-inf)
                        }else
                                predAngle = atan2(Vy, Vx)*57.3;

                        predictdPos[i][0]=predX + cos(predAngle/57.3)*1;
                        predictdPos[i][1]=predY + sin(predAngle/57.3)*1;
                        predX = predictdPos[i][0];
                        predY = predictdPos[i][1];
                }
                         //dass
                else if( !(pathPoint==path->GetNrPoints()-1) )//!IsReachedDestination
                {
                        path->GetPoint(++pathPoint, &pathPointX, &pathPointY);
                        predictdPos[i][0]=predX;
                        predictdPos[i][1]=predY;
                }
                else{
                     predictdPos[i][0]=predX;
                     predictdPos[i][1]=predY;
                }
        }
        else{
           predictdPos[i][0]=predX;
           predictdPos[i][1]=predY;
        }
    }//end for

}

bool Agent::IsColliding()
{
         bool collide=false;
        for(unsigned int i = 0; i < Agent::pool.size(); i++){
                if(this!=Agent::pool[i]){
                        Agent *other = Agent::pool[i];

                for(int j=0; j<MAXPREPOS; j++){
                        float dist_x  = (other->predictdPos[j][0] - predictdPos[j][0]);
                        float dist_y  = (other->predictdPos[j][1] - predictdPos[j][1]);
                        float dist_n = sqrt(dist_x*dist_x + dist_y*dist_y);

                        if(dist_n<(radius+other->radius)){
                                if(j==0) ResolveCollision(other);
                              // if(other->currAction!=2){
                                reserveNode1=&grid.nodes[int(predictdPos[j][0]/20)][int(predictdPos[j][1]/20)];
                               // reserveNode1->navigable=false;
                                reserveNode2=&grid.nodes[int(other->predictdPos[j][0]/20)][int(other->predictdPos[j][1]/20)];
                               // reserveNode2->navigable=false;
                               //other->stuck=1;
                               //CalculatePredictedPositions();
                               if(other->currAction==1){
                               other->currAction = 2;
                               other->delayTime = j+16;
                                                        }
                                return true;
                              //collide=true;
                        }
                }

                          //handle collision right
                          //if agent is not moving predict predx and predy rigth..
                          //
                          //the agents on moving keep blocking the next cell..
						  //the agents on idle keep blocking the curr cell..
                          //
                          //[x]implement the predicted position until next 2 node ahead
                          //->use the predict position on A*


                          //
                          //[x]test the directional path finding, for debug draw arrows in the path..
                          //
                          //
                          //test the groups Destination with fomartions Destination V, line, columm??
                          //
                          //
                          //test smooding path..
                          //
                          //hieraquic pathfind
                          //
                          //quequing/resuming pathfinding


                          //turn all the nodes that collide with t
                }
        }
        return collide;
}

bool Agent::IsCollidingAtPoint(int x, int y)
{
        for(unsigned int i = 0; i < Agent::pool.size(); i++){
                if(this!=Agent::pool[i]){
                        Agent *other = Agent::pool[i];
                        float dist_x  = other->x - x;
                        float dist_y  = other->y - y;
                        float dist_n = sqrt(dist_x*dist_x + dist_y*dist_y);
                        if(dist_n<=(radius+other->radius)) return true;
                }
        }

        return false;
}

void Agent::ResolveCollision(Agent *other)
{
        float dist_x  = (other->x - x);
        float dist_y  = (other->y - y);
        //float dist_n = sqrt(dist_x*dist_x + dist_y*dist_y);

        x-=(dist_x)*0.1;
        y-=(dist_y)*0.1;
        other->x+=(dist_x)*0.1;
        other->y+=(dist_y)*0.1;
}

////////
void Agent::Update()
{
        //CalculatePredictedPositions();
        switch(currAction)
        {
                case 0:
                        break;
                case 1:
                      Moving();
                        break;
                case 2:
                        delayTime--;
                        if(delayTime==0){delayTime=16;
                        currAction=1;}
                        break;
        }
}

void Soldier()
{
     //   glPushMatrix();

        glTranslatef(0,0,0);
        glColor3f(0, 0.301, 0);
        auxSolidCone(5,10);
        glTranslatef(0,0,10);
        auxSolidSphere(5);
        glTranslatef(5,5,-5);
        glColor3f(0, 0, 0);
        auxSolidBox(10,2,2);//

     //   glPopMatrix();
}

void Tank()
{
        glColor3f(0, 0.301, 0);
        auxSolidBox(20,10,5);//body
        glTranslatef(0,7.5,-2.5);
        glColor3f(0, 0, 0);
        auxSolidBox(20,5,5);//
        glTranslatef(0,-15,0);
        glColor3f(0, 0, 0);
        auxSolidBox(20,5,5);//

        glTranslatef(0,7.5,5);
        //glScalef(2,1,1);
        glColor3f(0.5, 0.5, 0);
        auxSolidSphere(5);

        glTranslatef(5,0,2.5);
        glColor3f(0, 0, 0);
        auxSolidBox(10,2.5,2.5);
}

void Veicle()
{


        glColor3f(0, 0.1505, 0);


        glScalef(0.5,0.5,0.5);
        auxSolidBox(40,30,10);//

        glTranslatef(-15,-15,-10);
        glColor3f(0, 0, 0);
        auxSolidSphere(5);
        glTranslatef(30,0,0);
        glColor3f(0, 0, 0);
        auxSolidSphere(5);

        glTranslatef(0,30,0);
        glColor3f(0, 0, 0);
        auxSolidSphere(5);

        glTranslatef(-30,0,0);
        glColor3f(0, 0, 0);
        auxSolidSphere(5);

        glTranslatef(20,-15,20);
        glColor3f(0, 0, 0);
        auxSolidBox(20,5,5);//


}
