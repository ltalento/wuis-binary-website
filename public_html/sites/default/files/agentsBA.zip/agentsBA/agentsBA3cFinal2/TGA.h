#ifndef TGA_H
#define TGA_H

#include <windows.h>
#include <gl\gl.h>
#include <gl\glu.h>

typedef struct// Create A Structure
{
GLubyte *imageData;// Image Data (Up To 32 Bits)
GLuint bpp;// Image Color Depth In Bits Per Pixel
GLuint width;// Image Width
GLuint height;// Image Height
GLuint texID;// Texture ID Used To Select A Texture
} TextureImage;// Structure Name

bool LoadTGA(TextureImage *texture, char *filename);
void UnLoadTexture(TextureImage *texture);
/*
class TextureImage // Class Name
{

private:

	GLubyte *imageData;// Image Data (Up To 32 Bits)
	GLuint bpp;// Image Color Depth In Bits Per Pixel
	GLuint width;// Image Width
	GLuint height;// Image Height

public:

	GLuint texID;// Texture ID Used To Select A Texture

	bool LoadTGA(TextureImage *texture, char *filename);

};
*/
#endif