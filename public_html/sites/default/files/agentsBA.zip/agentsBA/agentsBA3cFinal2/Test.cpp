//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
USERES("Test.res");
USEFORM("frmTest.cpp", Form1);
USEUNIT("GlDevice.cpp");
USEUNIT("path.cpp");
USEUNIT("grid.cpp");
USEUNIT("agent2.cpp");
USEUNIT("Map.cpp");
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
        try
        {
                 Application->Initialize();
                 Application->CreateForm(__classid(TForm1), &Form1);
                 Application->Run();
        }
        catch (Exception &exception)
        {
                 Application->ShowException(&exception);
        }
        return 0;
}
//---------------------------------------------------------------------------
