//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include <stdio.h>

#include "GlDevice.h"

//---------------------------------------------------------------------------

#pragma package(smart_init)

bool GlDevice::Create(void *handle)
{
        gl_HDC = GetDC(handle);

        PIXELFORMATDESCRIPTOR pfd, *ppfd;
        int pixelformat;
        ppfd = &pfd;
        ppfd->nSize = sizeof(PIXELFORMATDESCRIPTOR);
        ppfd->nVersion = 1;
        ppfd->dwFlags = PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL |
                        PFD_DOUBLEBUFFER;
        ppfd->dwLayerMask = PFD_MAIN_PLANE;
        ppfd->iPixelType = PFD_TYPE_RGBA;
        ppfd->cColorBits = 16;
        ppfd->cDepthBits = 8;
        ppfd->cAccumBits = 0;
        ppfd->cStencilBits = 0;

        if ( (pixelformat = ChoosePixelFormat(gl_HDC, ppfd)) == 0 )
            return false;//MessageBox(NULL, "ChoosePixelFormat failed", "Error", MB_OK);

        if (SetPixelFormat(gl_HDC, pixelformat, ppfd) == FALSE)
            return false;//MessageBox(NULL, "SetPixelFormat failed", "Error", MB_OK);

        gl_HRC = wglCreateContext(gl_HDC);
        if(gl_HRC==NULL)
                return false;
        if(wglMakeCurrent(gl_HDC, gl_HRC)== false)
                return false;
                
        return true;
}

void GlDevice::Init(float w, float h)
{
        glViewport( 0, 0, w, h);
        glMatrixMode( GL_PROJECTION );
        glLoadIdentity();
        //gluPerspective( 45.0, w/h, 1.0, 25.0 );
       // glOrtho(-HALFGLSCENE_W,HALFGLSCENE_W,-HALFGLSCENE_H,HALFGLSCENE_H,-1,2);
        glOrtho(0 ,w , h, 0,-50,50);
        glMatrixMode( GL_MODELVIEW );

        glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
        glClearDepth( 1.0 );
        glEnable(GL_DEPTH_TEST);
        glEnable(GL_LIGHT0);
        glEnable(GL_LIGHTING);
        glEnable(GL_COLOR_MATERIAL);

        //glEnable(GL_TEXTURE_2D);
}

void GlDevice::ShutDwn(void *handle)
{
        if (gl_HRC) wglDeleteContext(gl_HRC);
        if (gl_HDC) ReleaseDC(handle, gl_HDC);
        wglMakeCurrent(NULL, NULL);
}

void GlDevice::Show()
{
        SwapBuffers(gl_HDC);
}

bool GlDevice::LoadTexture(const char *filename, GLuint *texture)
{
        Graphics::TBitmap* bitmap;
        bitmap = new Graphics::TBitmap;

        bitmap->LoadFromFile(filename);

        if(bitmap->Empty){
               delete bitmap;
               return false;
        }

        int w  = bitmap->Width;
        int h  = bitmap->Height;
        GLubyte *bits;
        bits = new GLubyte[w*h*4];

        //int m1[Z][Y][X];
        //int m2[X*Y*Z];
        //m1[z][y][x]=m2[z*(Y*X)+y*X+x];

        for(int i = 0; i < w; i++)
        {
            for(int j = 0; j < h; j++)
            {
                bits[i*(h*4)+j*4+0]= (GLbyte)GetRValue(bitmap->Canvas->Pixels[i][j]);
                bits[i*(h*4)+j*4+1]= (GLbyte)GetGValue(bitmap->Canvas->Pixels[i][j]);
                bits[i*(h*4)+j*4+2]= (GLbyte)GetBValue(bitmap->Canvas->Pixels[i][j]);
                bits[i*(h*4)+j*4+3]= (GLbyte)255;

            }
        }
        
        glPixelStorei(GL_UNPACK_ALIGNMENT, 4);
        glGenTextures(1, texture);
        glBindTexture(GL_TEXTURE_2D, *texture);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, bits);
        delete bits;
        bitmap->FreeImage();
        delete bitmap;

        return true;
}

void GlDevice::UnLoadTexture(GLuint *texture)   //not tested
{
        glDeleteTextures(1,texture);
}

bool GlDevice::LoadTGA(TextureImage *texture, char *filename)// Loads A TGA File Into Memory
{
	GLubyte TGAheader[12]={0,0,2,0,0,0,0,0,0,0,0,0};// Uncompressed TGA Header
	GLubyte TGAcompare[12];// Used To Compare TGA Header
	GLubyte header[6];// First 6 Useful Bytes From The Header
	GLuint bytesPerPixel;// Holds Number Of Bytes Per Pixel Used In The TGA File
	GLuint imageSize;// Used To Store The Image Size When Setting Aside Ram
	GLuint temp;// Temporary Variable
	GLuint type=GL_RGBA;// Set The Default GL Mode To RBGA (32 BPP)
	FILE *file = fopen(filename, "rb");// Open The TGA File
	if( file==NULL ||fread(TGAcompare,1,sizeof(TGAcompare),file)!=sizeof(TGAcompare) || memcmp(TGAheader,TGAcompare,sizeof(TGAheader))!=0 || fread(header,1,sizeof(header),file)!=sizeof(header)) // If So Read Next 6 Header Bytes
		{
			if (file == NULL) //Did The File Even Exist? *Added Jim Strong*
				return false; //Return False
			else
				{fclose(file);return false;}
		}
	texture->width = header[1] * 256 + header[0];// Determine The TGA Width (highbyte*256+lowbyte)
	texture->height = header[3] * 256 + header[2];// Determine The TGA Height (highbyte*256+lowbyte)
	if( texture->width <=0 ||texture->height <=0 || (header[4]!=24 && header[4]!=32)) // Is The TGA 24 or 32 Bit?
		{fclose(file);return false;}
	
	texture->bpp = header[4];// Grab The TGA's Bits Per Pixel (24 or 32)
	bytesPerPixel = texture->bpp/8;// Divide By 8 To Get The Bytes Per Pixel
	imageSize = texture->width*texture->height*bytesPerPixel;// Calculate The Memory Required For The TGA Data
	texture->imageData=(GLubyte *)malloc(imageSize); //Reserve Memory To Hold The TGA Data
	if( texture->imageData==NULL ||fread(texture->imageData, 1, imageSize, file)!=imageSize) //	
		{
			if(texture->imageData!=NULL) // Was Image Data Loaded
					free(texture->imageData); // If So, Release The Image Data
			fclose(file); // Close The File
			return false; // Return False
		}
	for(GLuint i=0; i<int(imageSize); i+=bytesPerPixel)// Loop Through The Image Data
		{
			// Swaps The 1st And 3rd Bytes ('R'ed and 'B'lue)
			temp=texture->imageData[i]; // Temporarily Store The Value At Image Data 'i'
			texture->imageData[i] = texture->imageData[i + 2]; // Set The 1st Byte To The Value Of The 3rd Byte
			texture->imageData[i + 2] = temp; //Set The 3rd Byte To The Value In 'temp' (1st Byte Value)
		}
	fclose (file);	
	
	// Build A Texture From The Data
	glGenTextures(1, &texture[0].texID);// Generate OpenGL texture IDs
	glBindTexture(GL_TEXTURE_2D, texture[0].texID);// Bind Our Texture
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);// Linear Filtered
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);// Linear Filtered
	if (texture[0].bpp==24)// Was The TGA 24 Bits
		type=GL_RGB;
	glTexImage2D(GL_TEXTURE_2D, 0, type, texture[0].width, texture[0].height, 0,type, GL_UNSIGNED_BYTE, texture[0].imageData);

         free(texture->imageData);

	return true;// Texture Building Went Ok, Return True
}
