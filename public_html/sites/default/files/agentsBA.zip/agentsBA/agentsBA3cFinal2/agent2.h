//---------------------------------------------------------------------------

#ifndef agent2H
#define agent2H
//---------------------------------------------------------------------------
#include <vector.h>
#include "path.h"

#define MAXRADIUS 20
#define MAXPREPOS 50

struct Node;

class  Agent
{

//  private:
public:
        //kontentor com todas as instancias da class
         static vector<Agent*> pool;

         float x, y;
         int radius;
         int angle; //direction

         //behavior
         int currAction; //0=idle 1=moving 2=block

         int destinationNodeX, destinationNodeY;
         int currPathPointIndx;
         int currPathPointX, currPathPointY;

         Path *path;

         bool selected;

         int stuck;
         bool repath;
         int delayTime;

         Node *reserveNode1;
         Node *reserveNode2;

         float predictdPos[MAXPREPOS][3];

         int model;
  public:

        static Agent* Add(float x, float y);

        static void Remove(Agent* agent);

       // void Init();
        void Draw();

        void SetAngleFrom1Point(int Px, int Py);
        void Select();
        void UnSelect();
        bool IsSelected();
        bool ContainPoint(int pX, int pY);
        bool IntersectRectangle(int rx1,int ry1, int rx2, int ry2);

        //orders
        void MoveToNode(int nx,int ny);

        //Actions
        void Moving();

        //auxs
        bool IsReachedCurrentPathPoint();
        bool IsReachedDestination();
        bool IsNearDestination();

        void CalculatePredictedPositions();

        void ReserveNode();
        void UnReserveNode();

        bool IsColliding();
        bool IsCollidingAtPoint(int x, int y);
        void ResolveCollision(Agent *other);

        //
        void Update();

//wait order..
//resume order...

};

#endif
