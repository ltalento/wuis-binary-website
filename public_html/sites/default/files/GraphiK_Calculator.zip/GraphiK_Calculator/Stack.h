//---------------------------------------------------------------------------

#ifndef StackH
#define StackH
//---------------------------------------------------------------------------
#include "ExceptionError.h"
template <class ElemType>
class Stack
{
   protected:
        ElemType *data;
        int top;
        int allocated;

   public:
       Stack(int dim=10);
       Stack(const Stack<ElemType>& other);
       virtual  ~Stack();

       virtual void Push(const ElemType& e);
       virtual  ElemType Pop();
       virtual  ElemType Peek();
       virtual bool IsEmpty()const;
       virtual Stack<ElemType>& operator=(const Stack<ElemType>& other);




   private:
       virtual void Expand();
       virtual bool IsFull()const;
};

template <class ElemType>
Stack<ElemType>::Stack(int dim)
{
        data = new ElemType[dim];
        if( data == NULL)
           throw ExceptionError(" Not enought memory");
        allocated=dim;
        top=0;
}

// Construtor C�pia
template <class ElemType>
Stack<ElemType>::Stack(const Stack<ElemType>& other)
{
      data = new ElemType [other.position];
        if( data == NULL)
           throw ExceptionError(" Not enought memory");

       allocated = other.position;
       top = other.top;
       for(int i=0; i< other.top; i++)
            data[i] = other.data[i];
}
//---------------------------------------------------------------------------
template <class ElemType>
Stack<ElemType>::~Stack()
{
        delete []data;
}
//---------------------------------------------------------------------------
template <class ElemType>
bool Stack<ElemType>::IsFull() const
{
   return top==allocated;
}
//---------------------------------------------------------------------------
template <class ElemType>
bool Stack<ElemType>::IsEmpty() const
{
   return top==0;
}

//---------------------------------------------------------------------------
template <class ElemType>
void Stack<ElemType>::Push(const ElemType& e)
{
   if( IsFull())
       Expand();
   data[top++]=e;
}
//---------------------------------------------------------------------------
template <class ElemType>
ElemType Stack<ElemType>::Pop()
{
  if(IsEmpty())
    throw ExceptionError("Stack is Empty");
  return data[--top];
}

template <class ElemType>
ElemType Stack<ElemType>::Peek()
{
  if(IsEmpty())
    throw ExceptionError("Stack is Empty");
   return data[top-1];
}

//---------------------------------------------------------------------------
//---------   Dynamic   Memory          -------------------------------------
//---------------------------------------------------------------------------
template <class ElemType>
void Stack<ElemType>::Expand()
{
        //Alocar novo array din�mico
        ElemType *dataTmp = new ElemType [allocated * 2 ];
        //Se n�o houver mem�ria suficiente provocar uma excep��o
        if( dataTmp == NULL)
           throw  ExceptionError(" Not enought memery");

        //Copiar os elementos do array antigo
        for(int i=0; i< allocated; i++)
                dataTmp[i]=data[i];
        //actualizar o n�mero de elementos alocados
        allocated *=2;
        // libertar a mem�ria do array antigo
        delete [] data;
        // actualizar o ponteiro de dados
        data= dataTmp;
}
//---------------------------------------------------------------------------
template <class ElemType>
Stack<ElemType>& Stack<ElemType>::operator=(const Stack<ElemType>& other)
{
   if( this != &other)
   {
       delete []data;
       data = new ElemType [other.top];
       top = other.top;
       allocated = other.top;
       for(int i=0; i< other.top; i++)
           data[i] = other.data[i] ;
   }
   return *this;
}
#endif
