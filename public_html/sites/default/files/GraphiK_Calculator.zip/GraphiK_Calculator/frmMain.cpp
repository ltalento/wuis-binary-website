//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "frmMain.h"
#include "frmGraph3D.h"
#include "frmGraph2D.h"
#include "Expression.h"

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TfrmCalc *frmCalc;

AnsiString equ = "";
Expression *m_Exp = NULL;

double var_x = 0, var_y = 0, var_z = 0;

//---------------------------------------------------------------------------
__fastcall TfrmCalc::TfrmCalc(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TfrmCalc::btnFxClick(TObject *Sender)
{
  btnResultClick(this);
  equ = "f(x) = " + edbInFixExp->Text;
  frmGraphic2D = new TfrmGraphic2D( this );
  frmGraphic2D->ShowModal();
}
//---------------------------------------------------------------------------
void __fastcall TfrmCalc::btnFxyClick(TObject *Sender)
{
  btnResultClick(this);
  equ = "f(x,y) = " + edbInFixExp->Text;
  frmGraphic3D = new TfrmGraphic3D(this);
  frmGraphic3D->ShowModal();
}
//---------------------------------------------------------------------------
void __fastcall TfrmCalc::btn0Click(TObject *Sender)
{
        edbInFixExp->Text = edbInFixExp->Text + '0';
}
//---------------------------------------------------------------------------
void __fastcall TfrmCalc::btn1Click(TObject *Sender)
{
        edbInFixExp->Text = edbInFixExp->Text + '1';
}
//---------------------------------------------------------------------------
void __fastcall TfrmCalc::btn2Click(TObject *Sender)
{
         edbInFixExp->Text = edbInFixExp->Text + '2';
}
//---------------------------------------------------------------------------
void __fastcall TfrmCalc::btn3Click(TObject *Sender)
{
         edbInFixExp->Text = edbInFixExp->Text + '3';
}
//---------------------------------------------------------------------------
void __fastcall TfrmCalc::btn4Click(TObject *Sender)
{
         edbInFixExp->Text = edbInFixExp->Text + '4';
}
//---------------------------------------------------------------------------
void __fastcall TfrmCalc::btn5Click(TObject *Sender)
{
         edbInFixExp->Text = edbInFixExp->Text + '5';
}
//---------------------------------------------------------------------------
void __fastcall TfrmCalc::btn6Click(TObject *Sender)
{
         edbInFixExp->Text = edbInFixExp->Text + '6';
}
//---------------------------------------------------------------------------
void __fastcall TfrmCalc::btn7Click(TObject *Sender)
{
         edbInFixExp->Text = edbInFixExp->Text + '7';
}
//---------------------------------------------------------------------------

void __fastcall TfrmCalc::btn8Click(TObject *Sender)
{
         edbInFixExp->Text = edbInFixExp->Text + '8';
}
//---------------------------------------------------------------------------
void __fastcall TfrmCalc::btn9Click(TObject *Sender)
{
        edbInFixExp->Text = edbInFixExp->Text + '9';
}
//---------------------------------------------------------------------------
void __fastcall TfrmCalc::btnSignalClick(TObject *Sender)
{
        edbInFixExp->Text = edbInFixExp->Text + '-';
}
//---------------------------------------------------------------------------
void __fastcall TfrmCalc::btnPointClick(TObject *Sender)
{
        edbInFixExp->Text = edbInFixExp->Text + ',';
}
//---------------------------------------------------------------------------
void __fastcall TfrmCalc::btnSumClick(TObject *Sender)
{
        edbInFixExp->Text = edbInFixExp->Text + " + ";
}
//---------------------------------------------------------------------------
void __fastcall TfrmCalc::btnSubClick(TObject *Sender)
{
        edbInFixExp->Text = edbInFixExp->Text + " - ";
}
//---------------------------------------------------------------------------
void __fastcall TfrmCalc::btnMulClick(TObject *Sender)
{
        edbInFixExp->Text = edbInFixExp->Text + " * ";
}
//---------------------------------------------------------------------------
void __fastcall TfrmCalc::btnDivClick(TObject *Sender)
{
        edbInFixExp->Text = edbInFixExp->Text + " / ";
}
//---------------------------------------------------------------------------
void __fastcall TfrmCalc::btnPowClick(TObject *Sender)
{
        edbInFixExp->Text = edbInFixExp->Text + " ^ ";
}
//---------------------------------------------------------------------------

void __fastcall TfrmCalc::btnSqrtClick(TObject *Sender)
{
        edbInFixExp->Text = edbInFixExp->Text + "Sqrt ( ";
}
//---------------------------------------------------------------------------

void __fastcall TfrmCalc::btnSinClick(TObject *Sender)
{
        edbInFixExp->Text = edbInFixExp->Text + "Sin ( ";
}
//---------------------------------------------------------------------------
void __fastcall TfrmCalc::btnCosClick(TObject *Sender)
{
        edbInFixExp->Text = edbInFixExp->Text + "Cos ( ";
}
//---------------------------------------------------------------------------
void __fastcall TfrmCalc::btnLParentClick(TObject *Sender)
{
        edbInFixExp->Text = edbInFixExp->Text + " ( ";
}
//---------------------------------------------------------------------------
void __fastcall TfrmCalc::btnRParentClick(TObject *Sender)
{
        edbInFixExp->Text = edbInFixExp->Text + " ) ";
}
//---------------------------------------------------------------------------

void __fastcall TfrmCalc::btnXClick(TObject *Sender)
{
        edbInFixExp->Text = edbInFixExp->Text + 'x';
}
//---------------------------------------------------------------------------

void __fastcall TfrmCalc::btnYClick(TObject *Sender)
{
        edbInFixExp->Text = edbInFixExp->Text + 'y';
}
//---------------------------------------------------------------------------

void __fastcall TfrmCalc::btnZClick(TObject *Sender)
{
        edbInFixExp->Text = edbInFixExp->Text + 'z';
}
//---------------------------------------------------------------------------
void __fastcall TfrmCalc::btnBackClick(TObject *Sender)
{
        AnsiString tmp = edbInFixExp->Text;
        if ( tmp.Length() != 0 )
        {
                if( tmp[ tmp.Length() ] != ' ' )
                        tmp = tmp.Delete( tmp.Length() , 1);

                else  // if( tmp[ tmp.Length() ] == ' ' )
                {
                        if( tmp.Length()>3){
                                char ch = tmp[ tmp.Length() - 3 ];
                                if (ch == 'n' || ch == 's')
                                        tmp = tmp.Delete( tmp.Length()-5, 6);
                                else if( ch == 't')
                                        tmp = tmp.Delete( tmp.Length()-6 , 7);
                                else
                                        tmp = tmp.Delete( tmp.Length()-2 , 3);
                        }
                        else if (tmp.Length()>2 )
                                        tmp = tmp.Delete( tmp.Length()-2 , 3);
                }
        }

        edbInFixExp->Text = tmp;
}
//---------------------------------------------------------------------------
void __fastcall TfrmCalc::btnClearClick(TObject *Sender)
{
    edbInFixExp->Text = "";
    edbPosFixExp->Text = "";
    edbValueExp->Text = "";

    if(m_Exp){
        delete m_Exp;
        m_Exp = NULL;
    }

}
//---------------------------------------------------------------------------
void __fastcall TfrmCalc::btnResultClick(TObject *Sender)
{
if(m_Exp){
        delete m_Exp;
        m_Exp = NULL;
    }


    AnsiString tmpx = edbX->Text , tmpy=edbX->Text , tmpz=edbX->Text,
               tmpExp = edbInFixExp->Text;

    for(int i=1; i< tmpx.Length()+1 ; i++)
        if(tmpx[i]==','){ tmpx =  tmpx.Delete(i,1) ; tmpx =  tmpx.Insert('.',i) ; }

    for(int i=1; i< tmpy.Length()+1 ; i++)
        if(tmpy[i]==','){ tmpy =  tmpy.Delete(i,1) ; tmpy =  tmpy.Insert('.',i) ; }

    for(int i=1; i< tmpz.Length()+1 ; i++)
        if(tmpz[i]==','){ tmpz =  tmpz.Delete(i,1) ; tmpz =  tmpz.Insert('.',i) ; }

    for(int i=1; i< tmpExp.Length()+1 ; i++)
        if(tmpExp[i]==','){ tmpExp =  tmpExp.Delete(i,1) ; tmpExp =  tmpExp.Insert('.',i) ; }

    var_x = atof(tmpx.c_str());
    var_y = atof(tmpy.c_str());
    var_z = atof(tmpz.c_str());

    try{
         m_Exp = new Expression(tmpExp);
        m_Exp->ToPosFix();
        edbPosFixExp->Text = m_Exp->GetExp();
        edbValueExp->Text = m_Exp->Value();
    }catch(Exception &exception){
        edbPosFixExp->Text= "erro na express�o!!";
    }


    for(int i=1 ; i<edbPosFixExp->Text.Length()+1; i++)
       if(edbPosFixExp->Text[i]=='.'){
        edbPosFixExp->Text =  edbPosFixExp->Text.Delete(i,1) ;
        edbPosFixExp->Text =  edbPosFixExp->Text.Insert(',',i) ;
       }

    for(int i=1 ; i<edbValueExp->Text.Length()+1; i++)
       if(edbValueExp->Text[i]=='.'){
        edbValueExp->Text =  edbValueExp->Text.Delete(i,1) ;
        edbValueExp->Text =  edbValueExp->Text.Insert(',',i) ;
       }
        

}
//---------------------------------------------------------------------------

