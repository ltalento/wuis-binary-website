//---------------------------------------------------------------------------

#ifndef ExpressionH
#define ExpressionH
//---------------------------------------------------------------------------
#include <vcl.h>

class Expression
{
private:
    AnsiString expr; //1+2*3
    bool formatRSC;
    int Prior(char c) const;
    void FormatExpr();
    double op(double x1, char ch, double x2) const;
    bool IsNumber(char *ch) const;
    double GetNumber(char *ch, int *index);
    void ConvertRSC();
    void DecodeRSC();
public:

    Expression(AnsiString str) ;
    Expression(const Expression& other);
    virtual ~Expression();

    virtual AnsiString GetExp() const;

    virtual bool Check()const;

    virtual void ToPosFix(); //expr = 123*+

    virtual double Value(bool graph=false ) const; //expr = 123*+ = 7

};





#endif
