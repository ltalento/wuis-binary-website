//---------------------------------------------------------------------------

#pragma hdrstop

#include "Expression.h"
 
#include <math.h>
#include <vector>

//---------------------------------------------------------------------------
#pragma package(smart_init)

#include "Stack.h"
extern double var_x, var_y, var_z;

Expression::Expression(AnsiString str) : expr(str), formatRSC(false)
{
}

Expression::Expression(const Expression& other)
{
    formatRSC = other.formatRSC;
    expr = other.expr;
}

Expression::~Expression()
{
}

AnsiString Expression::GetExp() const
{
    if(formatRSC) DecodeRSC();
    return expr;
}

bool Expression::Check() const
{
    int par=0;

    for(int i=1; i<=expr.Length()  ; i++)
    {
        if( expr[i]=='(' )
            par++;
        else if(expr[i]==')')
            if(par!=0)  par--;
            else return false;
    }

    if(par==0) return true;

    return false;
}

void Expression::FormatExpr()
{
    for(int i=1; i<=expr.Length()-1 ; i++){
        if( expr[i] == ' ' && expr[i+1]  == ' '){
            expr = expr.Delete(i,1);
        }
    }
}

int Expression::Prior(char c) const
{
    switch(c)
    {
        case '+': return 1;
        case '-': return 2;
        case '*': return 3;
        case '/': return 3;
        case '^': return 4;
        case 'S': return 5;
        case 'C': return 5;
        case 'R': return 5;
        default: return 0;

    };

}

void Expression::ConvertRSC()
{
    for(int i=1; i<=expr.Length()-2 ; i++)
        if( expr[i] == 'C' || expr[i]  == 'S')
            if (expr[i] == 'C')
                expr = expr.Delete(i+1,2);
            else if (expr[i+1]=='i')
                expr = expr.Delete(i+1,2);
            else{
                expr = expr.Delete(i+1,3);
                expr[i] = 'R';
            }
    formatRSC = true;
}

void Expression::DecodeRSC()
{
    for(int i=1; i<=expr.Length() ; i++)
        if( expr[i]=='C' || expr[i]=='S' || expr[i]=='R')
            if (expr[i]=='C'){
                expr = expr.Delete(i,1);
                expr = expr.Insert("Cos",i);
            }
            else if (expr[i]=='S'){
                expr = expr.Delete(i,1);
                expr = expr.Insert("Sin",i);
            }
            else{
                expr = expr.Delete(i,1);
                expr = expr.Insert("Sqrt",i);
            }
    formatRSC = false;
}

bool Expression::IsNumber(char *ch) const
{
    switch(*ch)
    {
        case '0':
        case '1':
        case '2':
        case '3':
        case '4':
        case '5':
        case '6':
        case '7':
        case '8':
        case '9':
        case ',': // OS pt
        case '.': // OS eng
        case 'x':
        case 'y':
        case 'z':
                return true;
                break;
        case '-':
                if(ch[1])
                    if(ch[1] >='0' && ch[1]<='9')
                        return true;
                break;
    }
    return false;
}



void Expression::ToPosFix()
{
    if(!this->Check()) return;

    FormatExpr();

    if(!formatRSC) ConvertRSC();

    Stack<char> op;
    AnsiString tmp="";
    for(int i=0; i < expr.Length(); i++)
    {
            char *ch = expr.c_str()+i;
            if(*ch ==' ')
                 tmp = tmp + *ch;

            else if(IsNumber(ch)) // se for nr
                tmp = tmp + *ch;

            else if(*ch!='(' && *ch!=')') //se operador
                    if(op.IsEmpty())
                        op.Push(*ch);
                    else{
                        if( Prior(*ch) < Prior(op.Peek()) ){
                          tmp = tmp + ' ' + op.Pop() + ' ';
                        }
                        op.Push(*ch);
                   }

            else if(*ch=='(')
                        op.Push(*ch);
            else if(*ch==')'){
                        while(!op.IsEmpty() && op.Peek()!='('){
                            tmp = tmp + ' ' + op.Pop() + ' ';
                         }
                        op.Pop();
            }
    }

    while(!op.IsEmpty()){
        tmp = tmp + ' ' + op.Pop() + ' ';
    }

    expr = tmp;

    FormatExpr();
}

double Expression::op(double x1, char ch, double x2) const
{
    double res=0;
    switch(ch)
    {
        case '+': res=x1+x2;
                break;
        case '-': res=x1-x2;
                break;
        case '*': res=x1*x2;
                break;
        case '/': res=x1/x2;
                break;
        case '^': res=pow(x1,x2);
                break;
        default:
                res=0;
    }
    return res;
}

double Expression::GetNumber(char *ch, int *index)
{
        switch(*ch)
        {
                case 'x': return var_x;
                  break;
                case 'y': return var_y;
                  break;
                case 'z': return var_z;
                  break;
                default:
                        AnsiString tmp="";
                         while(*ch!=' ' && (*index)<expr.Length() ){
                                tmp = tmp + *ch;
                                (*index)++;
                                ch = expr.c_str()+(*index);
                         }

                        return atof(tmp.c_str());
                break;
        }
        return 0;
}

double Expression::Value(bool graph)const
{
    if(!formatRSC) ConvertRSC();
    
    Stack<double> p;
    for(int i=0; i < expr.Length(); i++){
        char *ch = expr.c_str()+i;

        if(*ch == ' ')
            continue;
        else if(IsNumber(ch)){
            p.Push(GetNumber(ch,&i));
        }
        else{
             double x1, x2;
             if(*ch=='R'){
                x1 = p.Pop();
                if(graph) p.Push( x1>=0 ? sqrt(x1) : 0 );
                else p.Push( sqrt(x1) );
             }
             else if(*ch=='C'){
                x1 = p.Pop();
                p.Push(cos(x1));
             }
             else if(*ch=='S'){
                x1 = p.Pop();
                p.Push(sin(x1));
             }
             else{
                double x1 = p.Pop();
                double x2 = p.Pop();
                p.Push(op(x2,*ch,x1));
             }
        }
    }
    return p.Pop();
}

