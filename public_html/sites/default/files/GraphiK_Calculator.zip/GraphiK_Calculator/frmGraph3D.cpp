//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include <math.h>

#include "frmGraph3D.h"

#include "Expression.h"


//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TfrmGraphic3D *frmGraphic3D;


extern AnsiString equ;
extern Expression *m_Exp;
extern double var_x, var_y, var_z;

//---------------------------------------------------------------------------
__fastcall TfrmGraphic3D::TfrmGraphic3D(TComponent* Owner)
        : TForm(Owner)
{
        Application->OnIdle = Draw;   // Define idle function
        MBLeft=false;
        MBRight=false;
        MBMiddle=false;
        rot_y=0; rot_x=0; zoom = 5;
        t_x=0; t_y = 0;
        res= 1.0f;
        edtRes->Text = res;
        this->Caption = equ;
}
//---------------------------------------------------------------------------

float func(float x, float y)
{
       //return cos(x) + sin(y) ;
       if(m_Exp){
       var_x=x;
       var_y=y;
       return  m_Exp->Value(true);
       }
        return 0;

 //       return 5 * (pow(x,2)/5 + pow(y,2)/5);
}

void __fastcall TfrmGraphic3D::CalcVertexNormal(float x, float y, float vertexNormal[3])
{

        vertexNormal[0]=0; vertexNormal[1]=0; vertexNormal[2]=0;

        for(int i=0; i<4; i++)
        {
                switch(i)
                {
                case 1: x +=res;
                        break;
                case 2: y +=res;
                        break;
                case 3: x -=res;
                        break;
                }

                        float p1[3], p2[3], p3[3], p4[3], v1[3], v2[3], v3[3];
                        p1[0]=x;     p1[1]=func(x,y);         p1[2]=y;
                        p2[0]=x+res; p2[1]=func(x+res,y);     p2[2]=y;
                        p3[0]=x+res; p3[1]=func(x+res,y+res); p3[2]=y+res;
                        p4[0]=x;     p4[1]=func(x,y+res);     p4[2]=y+res;

                        //v1= p2 - p1
                        v1[0]=p2[0]-p1[0]; v1[1]=p2[1]-p1[1]; v1[2]=p2[2]-p1[2];
                        //v2= p4 - p1
                        v2[0]=p4[0]-p1[0]; v2[1]=p4[1]-p1[1]; v2[2]=p4[2]-p1[2];
                        //v3= v1 ^ v2
                        v3[0] = v1[1]*v2[2] - v2[1]*v1[2];
                        v3[1] = v1[0]*v2[2] - v2[0]*v1[2];
                        v3[2] = v1[1]*v2[0] - v2[1]*v1[0];

                        //normalize v3
                        float norm = sqrt( v3[0]*v3[0] + v3[1]*v3[1] + v3[2]*v3[2]);

                        if(rbtSolid2->Checked) norm = -norm;
                        v3[0]/=-norm;
                        v3[1]/=norm;
                        v3[2]/=norm;

                        vertexNormal[0]+=v3[0];
                        vertexNormal[1]+=v3[1];
                        vertexNormal[2]+=v3[2];
        }

        vertexNormal[0]/=4; vertexNormal[1]/=4; vertexNormal[2]/=4;

}


void __fastcall TfrmGraphic3D::DrawWithVertexNormals()
{
        float lim = zoom ;
        glEnable(GL_LIGHTING);
        glColor3f(0.5f,0.5f,0.5f);
        for(float x=-lim; x<lim; x+=res)
                for(float y=-lim; y<lim; y+=res)
                {
                        float p1[3], p2[3], p3[3], p4[3];
                        p1[0]=x;     p1[1]=func(x,y);         p1[2]=y;
                        p2[0]=x+res; p2[1]=func(x+res,y);     p2[2]=y;
                        p3[0]=x+res; p3[1]=func(x+res,y+res); p3[2]=y+res;
                        p4[0]=x;     p4[1]=func(x,y+res);     p4[2]=y+res;

                        float n1[3], n2[3], n3[3], n4[3];

                        CalcVertexNormal( x     , y     , n1 );
                        CalcVertexNormal( x+res , y     , n2 );
                        CalcVertexNormal( x+res , y+res , n3 );
                        CalcVertexNormal( x     , y+res , n4 );

                        glBegin( GL_QUADS  );
                                glNormal3fv(n1);
                                glVertex3fv(p1);

                                glNormal3fv(n2);
                                glVertex3fv(p2);

                                glNormal3fv(n3);
                                glVertex3fv(p3);

                                glNormal3fv(n4);
                                glVertex3fv(p4);
                       glEnd();

                }
}

void __fastcall TfrmGraphic3D::DrawWithQuadNormals()
{
        glEnable(GL_LIGHTING);
        glColor3f(0.5f,0.5f,0.5f);
        float lim = zoom ;
        for(float x=-lim; x<lim; x+=res)
                for(float y=-lim; y<lim; y+=res)
                {
                        float p1[3], p2[3], p3[3], p4[3], v1[3], v2[3], v3[3];
                        p1[0]=x;     p1[1]=func(x,y);         p1[2]=y;
                        p2[0]=x+res; p2[1]=func(x+res,y);     p2[2]=y;
                        p3[0]=x+res; p3[1]=func(x+res,y+res); p3[2]=y+res;
                        p4[0]=x;     p4[1]=func(x,y+res);     p4[2]=y+res;

                        //v1= p2 - p1
                        v1[0]=p2[0]-p1[0]; v1[1]=p2[1]-p1[1]; v1[2]=p2[2]-p1[2];
                        //v2= p4 - p1
                        v2[0]=p4[0]-p1[0]; v2[1]=p4[1]-p1[1]; v2[2]=p4[2]-p1[2];
                        //v3= v1 ^ v2
                        v3[0] = v1[1]*v2[2] - v2[1]*v1[2];
                        v3[1] = v1[0]*v2[2] - v2[0]*v1[2];
                        v3[2] = v1[1]*v2[0] - v2[1]*v1[0];

                        //normalize v3
                        float norm = sqrt( v3[0]*v3[0] + v3[1]*v3[1] + v3[2]*v3[2]);

                        if(rbtSolid2->Checked) norm = -norm;
                        v3[0]/=-norm;
                        v3[1]/=norm;
                        v3[2]/=norm;

                         //glPushMatrix();
                        //glTranslatef(p1[0],p1[1],p1[2]);
                       // glBegin(GL_LINES);
                             //   glColor3f(0.0f,1.0f,0.0f);
                            //    glVertex3f(0.0f,0.0f,0.0f);
                          //      glVertex3fv(v3);
                        //glEnd();
                        //glPopMatrix();

                         glEnable(GL_LIGHTING);

                         glBegin( GL_QUADS  );
                                glNormal3fv(v3);

                                glVertex3fv(p1);
                                glVertex3fv(p2);
                                glVertex3fv(p3);
                                glVertex3fv(p4);

                         glEnd();
        }
}

void __fastcall TfrmGraphic3D::DrawWireFrame()
{
        glDisable(GL_LIGHTING);
        glColor3f(0.0f,0.0f,0.0f);
        float lim = zoom ;
        for(float x=-lim; x<lim; x+=res)
                for(float y=-lim; y<lim; y+=res)
                {
                        float p1[3], p2[3], p3[3], p4[3], v1[3], v2[3], v3[3];
                        p1[0]=x;     p1[1]=func(x,y);         p1[2]=y;
                        p2[0]=x+res; p2[1]=func(x+res,y);     p2[2]=y;
                        p3[0]=x+res; p3[1]=func(x+res,y+res); p3[2]=y+res;
                        p4[0]=x;     p4[1]=func(x,y+res);     p4[2]=y+res;

                        glBegin(  GL_LINE_LOOP );
                                glVertex3fv(p1);
                                glVertex3fv(p2);
                                glVertex3fv(p3);
                                glVertex3fv(p4);
                        glEnd();
                }
}

void __fastcall TfrmGraphic3D::Draw(TObject*, bool& done)
{
        done = false;               // request more idle time from the system
        glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
        glLoadIdentity();

        gluLookAt(t_x, t_y, zoom,  t_x, t_y, 0,  0,1,0);

        glRotatef(rot_x, 1.0f, 0.0f, 0.0f);
        glRotatef(rot_y, 0.0f, 1.0f, 0.0f);
        if(cbxAxis->Checked){
        glBegin(GL_LINES);
                glColor3f(1.0f,0.0f,0.0f);
                glVertex3f(0.0f,0.0f,0.0f);
                glVertex3f(1.0f,0.0f,0.0f);

                glColor3f(0.0f,1.0f,0.0f);
                glVertex3f(0.0f,0.0f,0.0f);
                glVertex3f(0.0f,1.0f,0.0f);

                glColor3f(0.0f,0.0f,1.0f);
                glVertex3f(0.0f,0.0f,0.0f);
                glVertex3f(0.0f,0.0f,1.0f);
        glEnd();
        }


        if(rbtSolid1->Checked || rbtSolid2->Checked){
                if(cbxVertexN->Checked) DrawWithVertexNormals();
                else DrawWithQuadNormals();
        }
        else    DrawWireFrame();

        SwapBuffers(gl_HDC);
}
//---------------------------------------------------------------------------
void __fastcall TfrmGraphic3D::FormCreate(TObject *Sender)
{
        if(!glCreate())
        {
         MessageBox(NULL, "Can't Create A GL Device Context", "Error", MB_OK);
         Close();
        }

        glInit(Graph->Width, Graph->Height);


}
//---------------------------------------------------------------------------
void __fastcall TfrmGraphic3D::FormDestroy(TObject *Sender)
{
        glShutDwn();
}
//---------------------------------------------------------------------------
bool TfrmGraphic3D::glCreate()
{
        gl_HDC = GetDC(Graph->Handle);

        PIXELFORMATDESCRIPTOR pfd, *ppfd;
        int pixelformat;
        ppfd = &pfd;
        ppfd->nSize = sizeof(PIXELFORMATDESCRIPTOR);
        ppfd->nVersion = 1;
        ppfd->dwFlags = PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL |
                        PFD_DOUBLEBUFFER;
        ppfd->dwLayerMask = PFD_MAIN_PLANE;
        ppfd->iPixelType = PFD_TYPE_COLORINDEX;
        ppfd->cColorBits = 16;
        ppfd->cDepthBits = 8;
        ppfd->cAccumBits = 0;
        ppfd->cStencilBits = 0;

        if ( (pixelformat = ChoosePixelFormat(gl_HDC, ppfd)) == 0 )
            return false;//MessageBox(NULL, "ChoosePixelFormat failed", "Error", MB_OK);

        if (SetPixelFormat(gl_HDC, pixelformat, ppfd) == FALSE)
            return false;//MessageBox(NULL, "SetPixelFormat failed", "Error", MB_OK);

        gl_HRC = wglCreateContext(gl_HDC);
        if(gl_HRC==NULL)
                return false;
        if(wglMakeCurrent(gl_HDC, gl_HRC)== false)
                return false;

        return true;
}
//---------------------------------------------------------------------------
void TfrmGraphic3D::glInit(float w, float h)
{
        glViewport( 0, 0, w, h);
        glMatrixMode( GL_PROJECTION );
        glLoadIdentity();
        gluPerspective( 45.0, w/h, 1.0, 256.0 );
        //glOrtho(-HALFGLSCENE_W,HALFGLSCENE_W,-HALFGLSCENE_H,HALFGLSCENE_H,-1,2);
        //glOrtho(-9,3,-3.67,3.67,-1,2);
        glMatrixMode( GL_MODELVIEW );

        glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
        glClearDepth( 1.0 );

       // glShadeModel(GL_SMOOTH);

        //glEnable(GL_POLYGON_SMOOTH);

        glEnable(GL_DEPTH_TEST);

        glEnable(GL_LIGHT0);

        //glEnable(GL_LIGHTING);
        glEnable(GL_COLOR_MATERIAL);

        //glEnable(GL_TEXTURE_2D);
}
//---------------------------------------------------------------------------
void TfrmGraphic3D::glShutDwn()
{
        if (gl_HRC) wglDeleteContext(gl_HRC);
        if (gl_HDC) ReleaseDC(Graph->Handle, gl_HDC);
        wglMakeCurrent(NULL, NULL);
}
//---------------------------------------------------------------------------
void __fastcall TfrmGraphic3D::GraphMouseMove(TObject *Sender,
      TShiftState Shift, int X, int Y)
{

        if(MBMiddle || (MBLeft && MBRight)){
                zoom += (Y - Yold);
                if(zoom>128) zoom = 128;
                if(zoom<=1) zoom = 1.1;

        }
        else if( MBLeft ){
                rot_y += (X - Xold);
                rot_x += (Y - Yold);
        }
        else if( MBRight ){
                t_x += (X - Xold)/10.0f;
                t_y -= (Y - Yold)/10.0f;
        }
           Xold = X;
           Yold = Y;
}
//---------------------------------------------------------------------------

void __fastcall TfrmGraphic3D::GraphMouseDown(TObject *Sender,
      TMouseButton Button, TShiftState Shift, int X, int Y)
{
        Xold = X;
        Yold = Y;
      switch(Button)
        {
               case mbLeft: MBLeft = true;
                                break;
               case mbRight: MBRight = true;
                                break;
               case mbMiddle: MBMiddle = true;
                                break;
        }
}
//---------------------------------------------------------------------------

void __fastcall TfrmGraphic3D::GraphMouseUp(TObject *Sender,
      TMouseButton Button, TShiftState Shift, int X, int Y)
{
      switch(Button)
        {
                case mbLeft: MBLeft = false;
                                break;
                case mbRight: MBRight = false;
                                break;
                case mbMiddle: MBMiddle = false;
                                break;
         }
}
//---------------------------------------------------------------------------

void __fastcall TfrmGraphic3D::btnDefaultClick(TObject *Sender)
{
       rot_y=0; rot_x=0; zoom = 5;
       t_x=0 ; t_y = 0;
       res=1.0f;
}
//---------------------------------------------------------------------------

void __fastcall TfrmGraphic3D::FormClose(TObject *Sender,
      TCloseAction &Action)
{
        Application->OnIdle = NULL;
        Action = caFree;
}
//---------------------------------------------------------------------------
void __fastcall TfrmGraphic3D::btnResPlusClick(TObject *Sender)
{
        res-=0.1f;
        if(res<0.009) res=0.009;
        edtRes->Text = res;
}
//---------------------------------------------------------------------------
void __fastcall TfrmGraphic3D::btnResMinusClick(TObject *Sender)
{
        res+=0.1f;
        edtRes->Text = res;
}
//---------------------------------------------------------------------------


