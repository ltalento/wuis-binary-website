//---------------------------------------------------------------------------

#ifndef frmMainH
#define frmMainH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
//---------------------------------------------------------------------------
class TfrmCalc : public TForm
{
__published:	// IDE-managed Components
        TButton *btn1;
        TButton *btn2;
        TButton *btn3;
        TButton *btn4;
        TButton *btn5;
        TButton *btn6;
        TButton *btn7;
        TButton *btn8;
        TButton *btn9;
        TButton *btnSignal;
        TButton *btnPoint;
        TEdit *edbInFixExp;
        TButton *btn0;
        TButton *btnSum;
        TButton *btnMul;
        TButton *btnSub;
        TButton *btnSin;
        TButton *btnDiv;
        TButton *btnSqrt;
        TButton *btnCos;
        TButton *btnRParent;
        TButton *btnLParent;
        TButton *btnPow;
        TButton *btnResult;
        TEdit *edbPosFixExp;
        TEdit *edbValueExp;
        TLabel *Label1;
        TLabel *Label2;
        TLabel *Label3;
        TButton *btnClear;
        TButton *btnBack;
        TButton *btnX;
        TButton *btnY;
        TButton *btnZ;
        TButton *btnFx;
        TButton *btnFxy;
        TEdit *edbX;
        TEdit *edbY;
        TEdit *edbZ;
        void __fastcall btnFxClick(TObject *Sender);
        void __fastcall btnFxyClick(TObject *Sender);
        void __fastcall btn0Click(TObject *Sender);
        void __fastcall btn1Click(TObject *Sender);
        void __fastcall btn2Click(TObject *Sender);
        void __fastcall btn3Click(TObject *Sender);
        void __fastcall btn4Click(TObject *Sender);
        void __fastcall btn5Click(TObject *Sender);
        void __fastcall btn6Click(TObject *Sender);
        void __fastcall btn7Click(TObject *Sender);
        void __fastcall btn8Click(TObject *Sender);
        void __fastcall btn9Click(TObject *Sender);
        void __fastcall btnSumClick(TObject *Sender);
        void __fastcall btnSubClick(TObject *Sender);
        void __fastcall btnMulClick(TObject *Sender);
        void __fastcall btnDivClick(TObject *Sender);
        void __fastcall btnPointClick(TObject *Sender);
        void __fastcall btnSignalClick(TObject *Sender);
        void __fastcall btnPowClick(TObject *Sender);
        void __fastcall btnSqrtClick(TObject *Sender);
        void __fastcall btnSinClick(TObject *Sender);
        void __fastcall btnCosClick(TObject *Sender);
        void __fastcall btnLParentClick(TObject *Sender);
        void __fastcall btnRParentClick(TObject *Sender);
        void __fastcall btnXClick(TObject *Sender);
        void __fastcall btnYClick(TObject *Sender);
        void __fastcall btnZClick(TObject *Sender);
        void __fastcall btnBackClick(TObject *Sender);
        void __fastcall btnClearClick(TObject *Sender);
        void __fastcall btnResultClick(TObject *Sender);
private:	// User declarations
       // enum InsertState { NR, PAR, SIG, U_OP, D_OP, VAR, NONE } currState, prevState;
        //void __fastcall Insert(InsertState inState,char *str);

public:		// User declarations
        __fastcall TfrmCalc(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TfrmCalc *frmCalc;
//---------------------------------------------------------------------------
#endif
