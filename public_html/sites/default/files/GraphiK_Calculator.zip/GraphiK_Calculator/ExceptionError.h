//---------------------------------------------------------------------------

#ifndef ExceptionErrorH
#define ExceptionErrorH
//---------------------------------------------------------------------------
#include <iostream.h>
class ExceptionError
{
   private:
     string  msg;
   public:
     ExceptionError() {
       msg="No message";
     }
     ExceptionError(char * error) {
       msg=error;
     }
     string GetMessage()const {
       return msg;
     }
};
#endif
 