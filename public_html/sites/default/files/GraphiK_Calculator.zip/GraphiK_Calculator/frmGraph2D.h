//---------------------------------------------------------------------------

#ifndef frmGraph2DH
#define frmGraph2DH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TfrmGraphic2D : public TForm
{
__published:	// IDE-managed Components
        TPanel *Panel2;
        TPaintBox *Graph;
        TButton *btnDefault;
        TGroupBox *GroupBox1;
        TEdit *edtRes;
        TButton *btnResPlus;
        TButton *btnResMinus;
        void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
        void __fastcall FormPaint(TObject *Sender);
        void __fastcall GraphMouseMove(TObject *Sender, TShiftState Shift,
          int X, int Y);
        void __fastcall GraphMouseDown(TObject *Sender,
          TMouseButton Button, TShiftState Shift, int X, int Y);
        void __fastcall GraphMouseUp(TObject *Sender, TMouseButton Button,
          TShiftState Shift, int X, int Y);
        void __fastcall btnDefaultClick(TObject *Sender);
        void __fastcall btnResPlusClick(TObject *Sender);
        void __fastcall btnResMinusClick(TObject *Sender);
private:	// User declarations
                float resolution, zoom, dv, dh;
                 int Xold, Yold;
                bool MBLeft, MBRight, MBMiddle;
                void Draw();

public:		// User declarations
        __fastcall TfrmGraphic2D(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TfrmGraphic2D *frmGraphic2D;
//---------------------------------------------------------------------------
#endif
