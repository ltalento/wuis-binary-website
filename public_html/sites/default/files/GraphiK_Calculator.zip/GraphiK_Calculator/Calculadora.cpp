//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
USERES("Calculadora.res");
USEFORM("frmMain.cpp", frmCalc);
USEUNIT("ExceptionError.cpp");
USEUNIT("Expression.cpp");
USEUNIT("Stack.cpp");
USEFORM("frmGraph3D.cpp", frmGraphic3D);
USEFORM("frmGraph2D.cpp", frmGraphic2D);
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
        try
        {
                 Application->Initialize();
                 Application->CreateForm(__classid(TfrmCalc), &frmCalc);
                 Application->Run();
        }
        catch (Exception &exception)
        {
                 Application->ShowException(&exception);
        }
        return 0;
}
//---------------------------------------------------------------------------
