//---------------------------------------------------------------------------

#ifndef frmGraph3DH
#define frmGraph3DH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <ActnList.hpp>

#include <gl/gl.h>
#include <gl/glu.h>

//---------------------------------------------------------------------------
class TfrmGraphic3D : public TForm
{
__published:	// IDE-managed Components
        TPanel *Panel2;
        TButton *btnDefault;
        TPanel *Graph;
        TGroupBox *Resolution;
        TButton *btnResPlus;
        TButton *btnResMinus;
        TEdit *edtRes;
        TGroupBox *GroupBox1;
        TRadioButton *rbtWire;
        TRadioButton *rbtSolid1;
        TRadioButton *rbtSolid2;
        TCheckBox *cbxAxis;
        TCheckBox *cbxVertexN;
        void __fastcall FormDestroy(TObject *Sender);
        void __fastcall FormCreate(TObject *Sender);
        void __fastcall GraphMouseMove(TObject *Sender, TShiftState Shift,
          int X, int Y);
        void __fastcall GraphMouseDown(TObject *Sender,
          TMouseButton Button, TShiftState Shift, int X, int Y);
        void __fastcall GraphMouseUp(TObject *Sender, TMouseButton Button,
          TShiftState Shift, int X, int Y);
        void __fastcall btnDefaultClick(TObject *Sender);
        void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
        void __fastcall btnResPlusClick(TObject *Sender);
        void __fastcall btnResMinusClick(TObject *Sender);
private:	// User declarations

        //Opengl stuff
        HDC   gl_HDC;
        HGLRC gl_HRC;
        bool glCreate();
        void glInit(float w, float h);
        void glShutDwn();

        void __fastcall CalcVertexNormal(float x, float y, float vertexNormal[3]);
        
        void __fastcall DrawWithVertexNormals();
        void __fastcall DrawWithQuadNormals();
        void __fastcall DrawWireFrame();

        void __fastcall Draw(TObject*, bool& done);

        bool MBLeft, MBRight, MBMiddle;
        int rot_y, rot_x, zoom;
        float t_x , t_y, res;
        int Xold, Yold;

public:		// User declarations
        __fastcall TfrmGraphic3D(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TfrmGraphic3D *frmGraphic3D;
//---------------------------------------------------------------------------
#endif
