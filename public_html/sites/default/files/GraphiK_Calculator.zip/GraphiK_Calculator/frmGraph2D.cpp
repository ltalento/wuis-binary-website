//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "frmGraph2D.h"
#include "Expression.h"

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TfrmGraphic2D *frmGraphic2D;

extern double var_x, var_y, var_z;
extern AnsiString equ;
extern Expression *m_Exp;

//---------------------------------------------------------------------------
__fastcall TfrmGraphic2D::TfrmGraphic2D(TComponent* Owner)
        : TForm(Owner)
{
        MBLeft=false;
        MBRight=false;
        MBMiddle=false;

        resolution = 1;
        zoom = 10;
        dv=(Graph->Width)/2; // Desvio Vertical
        dh=(Graph->Height)/2; // Desvio Horizontal
        edtRes->Text = resolution;
        this->Caption = equ;
}
//---------------------------------------------------------------------------
void __fastcall TfrmGraphic2D::FormClose(TObject *Sender,
      TCloseAction &Action)
{
        Action = caFree;
}
//---------------------------------------------------------------------------
void __fastcall TfrmGraphic2D::GraphMouseMove(TObject *Sender,
      TShiftState Shift, int X, int Y)
{
        if( MBLeft ){
                 dv+= (X - Xold);
                 dh+= (Y - Yold);
                 Draw();
        }
        else if( MBRight ){
                zoom -= (Y - Yold);;
                Draw();
        }

        Xold = X;
        Yold = Y;
}
//---------------------------------------------------------------------------
void __fastcall TfrmGraphic2D::GraphMouseDown(TObject *Sender,
      TMouseButton Button, TShiftState Shift, int X, int Y)
{
        Xold = X;
        Yold = Y;
      switch(Button)
        {
               case mbLeft: MBLeft = true;
                                break;
               case mbRight: MBRight = true;
                                break;
               case mbMiddle: MBMiddle = true;
                                break;
        }
}
//---------------------------------------------------------------------------
void __fastcall TfrmGraphic2D::GraphMouseUp(TObject *Sender,
      TMouseButton Button, TShiftState Shift, int X, int Y)
{
      switch(Button)
        {
                case mbLeft: MBLeft = false;
                                break;
                case mbRight: MBRight = false;
                                break;
                case mbMiddle: MBMiddle = false;
                                break;
         }
}
//---------------------------------------------------------------------------

void TfrmGraphic2D::Draw()
{
    float height = Graph->Height;
    float width = Graph->Width;

    Graph->Canvas->Brush->Style = bsSolid;
    Graph->Canvas->Brush->Color = clWhite;

    Graph->Canvas->Pen->Width = 1;

    //desenha os limites do grafico
    Graph->Canvas->Pen->Color = clWhite;//clGreen;
    Graph->Canvas->Rectangle(0,0,width,height);

    //desenha os eixos
    Graph->Canvas->Pen->Color = clRed;
    Graph->Canvas->MoveTo(0,dh);
    Graph->Canvas->LineTo(width , dh);

    Graph->Canvas->MoveTo(dv,0);
    Graph->Canvas->LineTo(dv,height);

    //graph->Canvas->MoveTo(0,-dv);

    Graph->Canvas->Pen->Color = clBlue;

    if(zoom <= 0) zoom = 1;

    var_x = (-width-dv)/zoom;

    double fx = m_Exp->Value(true);

    double xx = dv + zoom * var_x;//dv + width/zoom * var_x;
    double yy = dh + zoom * -fx;//dh + height/zoom * -fx;

    Graph->Canvas->MoveTo(xx,yy);

//    for(double x = (-dh/zoom)-resolution ; x< ((width-dh)/zoom)+resolution ; x+=resolution)
    for(double x = (-width-dv)/zoom ; x<= (width-dv)/zoom+resolution ; x+=resolution)
     {
        var_x = x;

        fx = m_Exp->Value(true);

        xx = dv + /*width/2 +*/ zoom * x;
        yy = dh + /*height/2 +*/ zoom * -fx;

        Graph->Canvas->LineTo(xx,yy);
        Graph->Canvas->MoveTo(xx,yy);

             //for(double i=-(p->Width/2); i<0; i+=resolution){
               // p->Canvas->LineTo(i*zoom+(p->Width)/2,LongValue(i,0,0)*zoom+(p->Height)/2);
                //p->Canvas->MoveTo(i*zoom+(p->Width)/2,LongValue(i,0,0)*zoom+(p->Height)/2);

     }
     //Edit1->Text = dv;
}
void __fastcall TfrmGraphic2D::FormPaint(TObject *Sender)
{
        Draw();
}
//---------------------------------------------------------------------------

void __fastcall TfrmGraphic2D::btnDefaultClick(TObject *Sender)
{
         resolution = 1;
        zoom = 10;
        dv=(Graph->Width)/2; // Desvio Vertical
        dh=(Graph->Height)/2; // Desvio Horizontal
        Draw();
}
//---------------------------------------------------------------------------

void __fastcall TfrmGraphic2D::btnResPlusClick(TObject *Sender)
{
         resolution-=0.1;
         if(resolution<0.009) resolution=0.009;
        edtRes->Text = resolution;
        Draw();
}
//---------------------------------------------------------------------------

void __fastcall TfrmGraphic2D::btnResMinusClick(TObject *Sender)
{
         resolution+=0.1;

        edtRes->Text = resolution;

        Draw();
}
//---------------------------------------------------------------------------

