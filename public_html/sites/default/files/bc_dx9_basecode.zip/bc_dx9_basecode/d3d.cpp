//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "d3d.h"

//---------------------------------------------------------------------------

#pragma package(smart_init)
extern int angleX, angleY;

HRESULT D3D::Init( HWND hWnd )
{
    // Create the D3D object, which is needed to create the D3DDevice.
    if( NULL == ( g_pD3D = Direct3DCreate9( D3D_SDK_VERSION ) ) )
        return E_FAIL;

    // Set up the structure used to create the D3DDevice. Most parameters are
    // zeroed out. We set Windowed to TRUE, since we want to do D3D in a
    // window, and then set the SwapEffect to "discard", which is the most
    // efficient method of presenting the back buffer to the display.  And
    // we request a back buffer format that matches the current desktop display
    // format.
    D3DPRESENT_PARAMETERS d3dpp;
    ZeroMemory( &d3dpp, sizeof(d3dpp) );
    d3dpp.Windowed = TRUE;
    d3dpp.SwapEffect = D3DSWAPEFFECT_DISCARD;
    d3dpp.BackBufferFormat = D3DFMT_UNKNOWN;
    d3dpp.BackBufferWidth = SCREEN_WIDTH;
    d3dpp.BackBufferHeight = SCREEN_HEIGHT;
    d3dpp.EnableAutoDepthStencil = TRUE;        // automatically run the z-buffer for us
    d3dpp.AutoDepthStencilFormat = D3DFMT_D16;  // 16-bit pixel format for the z-buffer

    // Create the Direct3D device. Here we are using the default adapter (most
    // systems only have one, unless they have multiple graphics hardware cards
    // installed) and requesting the HAL (which is saying we want the hardware
    // device rather than a software one). Software vertex processing is 
    // specified since we know it will work on all cards. On cards that support 
    // hardware vertex processing, though, we would see a big performance gain 
    // by specifying hardware vertex processing.
    if( FAILED( g_pD3D->CreateDevice( D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, hWnd,
                                      D3DCREATE_SOFTWARE_VERTEXPROCESSING,
                                      &d3dpp, &g_pd3dDevice ) ) )
    {
        return E_FAIL;
    }

    // Device state would normally be set here

    return S_OK;
}

VOID D3D::Cleanup()
{
    if(meshTeapot != NULL)
        meshTeapot->Release();  // close and release the vertex buffer

    if(ppVertexBuffer != NULL)
        ppVertexBuffer->Release();  // close and release the vertex buffer

    if( g_pd3dDevice != NULL)
        g_pd3dDevice->Release(); // close and release the 3D device

    if( g_pD3D != NULL)
        g_pD3D->Release();   // close and release Direct3D
}

VOID D3D::Init2()
{
    //
    // create three vertices using the CUSTOMVERTEX struct built earlier
    CUSTOMVERTEX t_vert[] =
    {
        { 3.0f, -3.0f, 0.0f, D3DCOLOR_XRGB(0, 0, 255), },
        { 0.0f, 3.0f, 0.0f, D3DCOLOR_XRGB(0, 255, 0), },
        { -3.0f, -3.0f, 0.0f, D3DCOLOR_XRGB(255, 0, 0), },
    };

    // create the vertex and store the pointer into t_buffer, which is created globally
    g_pd3dDevice->CreateVertexBuffer(3*sizeof(CUSTOMVERTEX),
                               0,
                               CUSTOMFVF,
                               D3DPOOL_MANAGED,
                               &ppVertexBuffer,
                               NULL);

    VOID* pVoid;    // the void pointer

    ppVertexBuffer->Lock(0, 0, (void**)&pVoid, 0);    // lock the vertex buffer
    memcpy(pVoid, t_vert, sizeof(t_vert));    // copy the vertices to the locked buffer
    ppVertexBuffer->Unlock();    // unlock the vertex buffer


    g_pd3dDevice->SetRenderState(D3DRS_LIGHTING, FALSE);    // turn off the 3D lighting
    g_pd3dDevice->SetRenderState(D3DRS_ZENABLE, TRUE);    // turn on the z-buffer

}


//-----------------------------------------------------------------------------
// Name: Render()
// Desc: Draws the scene
//-----------------------------------------------------------------------------
VOID D3D::Render1()
{
    if( NULL == g_pd3dDevice )
        return;

    // Clear the backbuffer to a blue color
    g_pd3dDevice->Clear( 0, NULL, D3DCLEAR_TARGET, D3DCOLOR_XRGB(0,0,0), 1.0f, 0 );
    g_pd3dDevice->Clear(0, NULL, D3DCLEAR_ZBUFFER, D3DCOLOR_XRGB(0,0,0), 1.0f, 0);

    // Begin the scene
    if( SUCCEEDED( g_pd3dDevice->BeginScene() ) )
    {
        // Rendering of scene objects can happen here
                 // select which vertex format we are using
        g_pd3dDevice->SetFVF(CUSTOMFVF);

        // SET UP THE PIPELINE
        D3DXMATRIX matView;    // the view transform matrix

        D3DXMatrixLookAtLH(&matView,
                       &D3DXVECTOR3 (0.0f, 0.0f, 10.0f),    // the camera position
                       &D3DXVECTOR3 (0.0f, 0.0f, 0.0f),    // the look-at position
                       &D3DXVECTOR3 (0.0f, 1.0f, 0.0f));    // the up direction

        g_pd3dDevice->SetTransform(D3DTS_VIEW, &matView);    // set the view transform to matView

        D3DXMATRIX matProjection;     // the projection transform matrix

        D3DXMatrixPerspectiveFovLH(&matProjection,
                               D3DXToRadian(45),    // the horizontal field of view
                               (FLOAT)SCREEN_WIDTH / (FLOAT)SCREEN_HEIGHT, // aspect ratio
                               1.0f,    // the near view-plane
                               100.0f);    // the far view-plane

     g_pd3dDevice->SetTransform(D3DTS_PROJECTION, &matProjection);    // set the projection

     g_pd3dDevice->SetStreamSource(0, ppVertexBuffer, 0, sizeof(CUSTOMVERTEX));


    D3DXMATRIX matTranslateA;    // a matrix to store the translation for triangle A
    D3DXMATRIX matTranslateB;    // a matrix to store the translation for triangle B
    D3DXMATRIX matRotateYA;    // a matrix to store the rotation for each triangle
    D3DXMATRIX matRotateYB;    // a matrix to store the rotation for the reverse sides
    static float index = 0.0f; index+=0.05f; // an ever-increasing float value

    // build MULTIPLE matrices to rotate and translate the model
    D3DXMatrixTranslation(&matTranslateA, -1.0f, 0.0f, 2.0f);
    D3DXMatrixTranslation(&matTranslateB, 1.0f, 0.0f, -2.0f);
    D3DXMatrixRotationY(&matRotateYA, index);    // the front side
    D3DXMatrixRotationY(&matRotateYB, index + 3.14159f);    // the reverse side

    // tell Direct3D about each world transform, and then draw another triangle
    g_pd3dDevice->SetTransform(D3DTS_WORLD, &(matRotateYA * matTranslateA));
    g_pd3dDevice->DrawPrimitive(D3DPT_TRIANGLELIST, 0, 1);

    g_pd3dDevice->SetTransform(D3DTS_WORLD, &(matRotateYB * matTranslateA));
    g_pd3dDevice->DrawPrimitive(D3DPT_TRIANGLELIST, 0, 1);

    g_pd3dDevice->SetTransform(D3DTS_WORLD, &( matRotateYA * matTranslateB));
    g_pd3dDevice->DrawPrimitive(D3DPT_TRIANGLELIST, 0, 1);

    g_pd3dDevice->SetTransform(D3DTS_WORLD, &(matRotateYB * matTranslateB));
    g_pd3dDevice->DrawPrimitive(D3DPT_TRIANGLELIST, 0, 1);

        // End the scene
        g_pd3dDevice->EndScene();
    }

    // Present the backbuffer contents to the display
    g_pd3dDevice->Present( NULL, NULL, NULL, NULL );
}

VOID D3D::Init3()
{
    D3DXCreateTeapot(g_pd3dDevice, &meshTeapot, NULL);    // create the teapot
    //D3DXCreateSphere(g_pd3dDevice,1,20,20,&meshTeapot,NULL);
    //D3DXCreateBox( g_pd3dDevice, 1, 0.5, 0.1,&meshTeapot,NULL);


    D3DLIGHT9 light;    // create the light struct
    D3DMATERIAL9 material;    // create the material struct

    ZeroMemory(&light, sizeof(light));    // clear out the struct for use
    light.Type = D3DLIGHT_DIRECTIONAL;    // make the light type 'directional light'
    light.Diffuse.r = 0.5f;    // .5 red
    light.Diffuse.g = 0.5f;    // .5 green
    light.Diffuse.b = 0.5f;    // .5 blue
    light.Diffuse.a = 1.0f;    // full alpha (we'll get to that soon)

    D3DVECTOR vecDirection = {-1.0f, -0.3f, -1.0f};    // the direction of the light
    light.Direction = vecDirection;    // set the direction

    g_pd3dDevice->SetLight(0, &light);    // send the light struct properties to light #0
    g_pd3dDevice->LightEnable(0, TRUE);    // turn on light #0

    ZeroMemory(&material, sizeof(D3DMATERIAL9));    // clear out the struct for use
    material.Diffuse.r = material.Ambient.r = 1.0f;    // set the material to full red
    material.Diffuse.g = material.Ambient.g = 1.0f;    // set the material to full green
    material.Diffuse.b = material.Ambient.b = 1.0f;    // set the material to full blue
    material.Diffuse.a = material.Ambient.a = 1.0f;    // set the material to full alpha

    g_pd3dDevice->SetMaterial(&material);    // set the globably-used material to &material

//    g_pd3dDevice->SetRenderState(D3DRS_LIGHTING, FALSE);    // turn off the 3D lighting
    g_pd3dDevice->SetRenderState(D3DRS_ZENABLE, TRUE);    // turn on the z-buffer

    g_pd3dDevice->SetRenderState( D3DRS_FILLMODE, D3DFILL_WIREFRAME );
//    gD3dDevice->SetRenderState( D3DRS_FILLMODE, D3DFILL_SOLID );

}

VOID D3D::Render2()
{
    g_pd3dDevice->Clear(0, NULL, D3DCLEAR_TARGET, D3DCOLOR_XRGB(0, 0, 0), 1.0f, 0);
    g_pd3dDevice->Clear(0, NULL, D3DCLEAR_ZBUFFER, D3DCOLOR_XRGB(0, 0, 0), 1.0f, 0);

    g_pd3dDevice->BeginScene();

      // set the view transform
    D3DXMATRIX matView;    // the view transform matrix
    D3DXMatrixLookAtLH(&matView,
    &D3DXVECTOR3 (0.0f, 3.0f, 6.0f),    // the camera position
    &D3DXVECTOR3 (0.0f, 0.0f, 0.0f),      // the look-at position
    &D3DXVECTOR3 (0.0f, 1.0f, 0.0f));    // the up direction
    g_pd3dDevice->SetTransform(D3DTS_VIEW, &matView);    // set the view transform to matView 

      // set the projection transform
    D3DXMATRIX matProjection;    // the projection transform matrix
    D3DXMatrixPerspectiveFovLH(&matProjection,
                               D3DXToRadian(45),    // the horizontal field of view
                               (FLOAT)SCREEN_WIDTH / (FLOAT)SCREEN_HEIGHT, // aspect ratio
                               1.0f,    // the near view-plane
                               100.0f);    // the far view-plane
    g_pd3dDevice->SetTransform(D3DTS_PROJECTION, &matProjection);    // set the projection

      // set the world transform
    D3DXMATRIX matRotateY;
    D3DXMATRIX matRotateX;
    D3DXMatrixRotationY(&matRotateY, angleY/57.3);
    D3DXMatrixRotationX(&matRotateX, angleX/57.3);
    g_pd3dDevice->SetTransform(D3DTS_WORLD, &(matRotateY*matRotateX));    // set the world transform


    // draw the teapot
    meshTeapot->DrawSubset(0);
    //meshTeapot->DrawSubset(1);

    g_pd3dDevice->EndScene();

    g_pd3dDevice->Present(NULL, NULL, NULL, NULL);

    return;

}