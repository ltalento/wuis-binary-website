//---------------------------------------------------------------------------

#ifndef d3dH
#define d3dH
//---------------------------------------------------------------------------

#ifndef _MSC_VER
    #define sqrtf (float)sqrt
#endif

#include "..\Include\d3d9.h"
#include "..\Include\d3dx9.h"

#pragma comment(lib, "..\Libs\d3d9.lib")
#pragma comment(lib, "..\Libs\d3dx9.lib")
//#pragma comment(lib, "..\Libs\dxguid.lib")
//#pragma comment(lib, "..\Libs\d3dxof.lib")
//#pragma comment(lib, "..\Libs\d3dx9d.lib")

#define SCREEN_WIDTH 640
#define SCREEN_HEIGHT 480

#define CUSTOMFVF (D3DFVF_XYZ | D3DFVF_DIFFUSE)

class D3D
{
public:

LPDIRECT3D9             g_pD3D; // Used to create the D3DDevice
LPDIRECT3DDEVICE9       g_pd3dDevice; // Our rendering device

struct CUSTOMVERTEX {FLOAT X, Y, Z; DWORD COLOR;};

LPDIRECT3DVERTEXBUFFER9 ppVertexBuffer;

LPD3DXMESH meshTeapot;    // define the mesh pointer

D3D::D3D(){
    g_pD3D          = NULL;
    g_pd3dDevice    = NULL;
    ppVertexBuffer  = NULL;
    meshTeapot      = NULL;    }

HRESULT Init( HWND hWnd );
VOID Cleanup();
VOID Init2();
VOID Init3();
VOID Render1();
VOID Render2();
};

#endif
