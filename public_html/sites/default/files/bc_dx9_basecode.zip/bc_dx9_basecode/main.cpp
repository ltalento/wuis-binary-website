//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "main.h"
#include "d3d.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
D3D d3d;

int angleX=0, angleY=0;
int  oldMouseX, oldMouseY;
bool IsRot=0;

//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
    : TForm(Owner)
{
   Application->OnIdle = IdleLoop;
   d3d.Init( Panel1->Handle);
   d3d.Init3();

}
//---------------------------------------------------------------------------
void __fastcall TForm1::IdleLoop(TObject*, bool& done)
{
    done = false;
    d3d.Render2();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormDestroy(TObject *Sender)
{
    d3d.Cleanup();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Panel1MouseDown(TObject *Sender,
      TMouseButton Button, TShiftState Shift, int X, int Y)
{
    if(Button == mbLeft){
        oldMouseX=X;
        oldMouseY=Y;
        IsRot=true;
    }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Panel1MouseUp(TObject *Sender, TMouseButton Button,
      TShiftState Shift, int X, int Y)
{
        IsRot=false;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Panel1MouseMove(TObject *Sender, TShiftState Shift,
      int X, int Y)
{
     if(IsRot){
        angleX+=(Y-oldMouseY);
        angleY-=(X-oldMouseX);
        oldMouseX=X;
        oldMouseY=Y;
     }
}
//---------------------------------------------------------------------------
