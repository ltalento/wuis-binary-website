#ifndef _VARIAVEIS_H_
#define _VARIAVEIS_H_

DATAFILE *dat;
int opcao_M=0;

#endif