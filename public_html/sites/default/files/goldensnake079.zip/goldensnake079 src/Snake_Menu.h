/* Allegro datafile object indexes, produced by grabber v4.0.0, MSVC */
/* Datafile: d:\Work\goldensnake078\Snake_Menu.dat */
/* Date: Sat Mar 23 14:26:16 2002 */
/* Do not hand edit! */

#define F_Creditos                       0        /* BMP  */
#define F_OsMelhores                     1        /* BMP  */
#define Font_Melhores                    2        /* BMP  */
#define L_A                              3        /* BMP  */
#define L_C                              4        /* BMP  */
#define L_D                              5        /* BMP  */
#define L_E                              6        /* BMP  */
#define L_G                              7        /* BMP  */
#define L_H                              8        /* BMP  */
#define L_I                              9        /* BMP  */
#define L_J                              10       /* BMP  */
#define L_L                              11       /* BMP  */
#define L_M                              12       /* BMP  */
#define L_N                              13       /* BMP  */
#define L_O                              14       /* BMP  */
#define L_R                              15       /* BMP  */
#define L_S                              16       /* BMP  */
#define L_T                              17       /* BMP  */
#define L_V                              18       /* BMP  */
#define Main_F                           19       /* BMP  */
#define Pallete1                         20       /* PAL  */
#define RatoA_1                          21       /* BMP  */
#define RatoA_2                          22       /* BMP  */
#define RatoA_3                          23       /* BMP  */
#define RatoA_4                          24       /* BMP  */

