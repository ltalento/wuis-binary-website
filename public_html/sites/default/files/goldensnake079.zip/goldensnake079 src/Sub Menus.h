#include "Variaveis.h"

BITMAP *F_OsMelhores_BMP, *F_Creditos_BMP, *Font_melh_BMP;

  void OsMelhores()
    { 
      char k, cont;
      char nome[10];      
      int x_linha, Index;
      F_OsMelhores_BMP = (BITMAP *)dat[F_OsMelhores].dat;
      Font_melh_BMP    = (BITMAP *)dat[Font_Melhores].dat;
      Main_F_buffer = create_bitmap(SCREEN_W, SCREEN_H);            
      clear(Main_F_buffer);
      masked_blit(F_OsMelhores_BMP,Main_F_buffer, 0, 0, 0, 0, SCREEN_W, SCREEN_H);                                    
      blit(Main_F_buffer, screen, 0, 0, 0, 0, SCREEN_W, SCREEN_H);   
      rest(1000);
      x_linha=50;
      cont=0;
      while (!key[KEY_ENTER])
      {
       	
      k = readkey();
      //nome[cont] = (char *)k;//&0xFF;      
      
      nome[cont] = k&0xFF;      
      cont++;         	      
      masked_blit(Font_melh_BMP, Main_F_buffer, (nome[cont-1]-32)*24, 0, x_linha ,58, 24,24); //0 	      
      x_linha+=24;
 	
      blit(Main_F_buffer, screen, 0, 0, 0, 0, SCREEN_W, SCREEN_H);
      
      /*
      textprintf(screen, font, 8, SCREEN_H-16, makecol(0, 0, 0),
		 "ASCII code is %d", k&0xFF);
      */
      
      }
     
     }

  void Creditos()
    { 
      F_Creditos_BMP = (BITMAP *)dat[F_Creditos].dat;
      Main_F_buffer = create_bitmap(SCREEN_W, SCREEN_H);            
      clear(Main_F_buffer);
      masked_blit(F_Creditos_BMP,Main_F_buffer, 0, 0, 0, 0, SCREEN_W, SCREEN_H);
      blit(Main_F_buffer, screen, 0, 0, 0, 0, SCREEN_W, SCREEN_H);   
      rest(1000);
      while (!key[KEY_ENTER]){}
    }
  
