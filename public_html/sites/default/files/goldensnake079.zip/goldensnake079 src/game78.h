#include "Variaveis.h"
#include <stdio.h>
#include "string.h"

volatile int Game_Time = 0;
BITMAP *Temp_BMP, *Barra_Nivel_S_BMP, *Barra_Quadro_BMP, \
       *Main_F_buffer, *Estr_BMP, *Ovo_BMP, *Rato_BMP, *Sair_BMP, \
       *Voltar_BMP, *Game_Over_BMP, *Fundo_G_BMP,*Cabeca_BMP, \
       *Cabeca1_BMP, *Rabo_BMP, *Corpo_BMP, *PFont_BMP;

int pos, comp, xv=0, yh=0, grid=0, DELAY, MaxFrames, pontos;
char frame[3], Game_end, dir;
char nivel_vel, Pontos_txt[4];
volatile int timestart, Gametimestart;

struct Pres
{
 int x, y;
 char Id;
 BITMAP *Imagem;

} Presa;
//2,3,6,9
void inc_Game_Time(void)
{
   Game_Time++;
}
END_OF_FUNCTION(inc_Game_Time);

void draw()
 {       
         int x_linha, Index;
         clear(Main_F_buffer);
         
         masked_blit(Fundo_G_BMP,Main_F_buffer,0,0,0,0, SCREEN_W, SCREEN_H);
         
          rotate_sprite(Main_F_buffer, Presa.Imagem, Presa.x, Presa.y,  itofix(0));
          for(pos=0;pos<=comp; pos++ )
             rotate_sprite(Main_F_buffer, Cobra[pos].Imagem, Cobra[pos].x, Cobra[pos].y,  itofix(Cobra[pos].anglo));


	  if((key[KEY_F1]))
 	   {
 	    key[KEY_F1]=FALSE;
 	    if (grid==1)
 	       grid=0;
 	    else 
 	       grid=1;
  	   }

 	  Cobra_old[0].x=Cobra[0].x;
 	  Cobra_old[0].y=Cobra[0].y;

 	  sprintf(Pontos_txt,"%i",pontos);
 	  x_linha=593-(strlen(Pontos_txt)*13/2);
 	  for (Index=0; Index < strlen(Pontos_txt) ;Index++)
 	    {
 	      masked_blit(PFont_BMP, Main_F_buffer, (Pontos_txt[Index]-48)*13, 0, x_linha ,58, 13,13); //0
 	      x_linha+=13;
 	    }



 	  if (grid==1)
 	    {
 	     for(xv=0;xv<640;xv+=9 )
 	       vline(Main_F_buffer, xv, 0, 480, 40);
             for(yh=0;yh<480;yh+=9 )
               hline(Main_F_buffer, 0, yh, 640, 40);
            }

 blit(Main_F_buffer, screen, 0, 0, 0, 0, SCREEN_W, SCREEN_H);
}
void pontos_func()
{

 switch(nivel_vel)
 {
  case 10: pontos=(comp-7)*10;
           break;
  case 15: pontos=(comp-7)*8;
           break;
  case 20: pontos=(comp-7)*6;
           break;
  case 25: pontos=(comp-7)*4;
           break;
  case 30: pontos=(comp-7)*2;
           break;
  case 35: pontos=(comp-7)*1;
           break;
}

}

void Presas()
{
 DELAY=250;
 if (Presa.Id==0)
  {
    MaxFrames=4;
    if ((Game_Time-timestart)>=DELAY)
     {  
      Presa.Imagem=(BITMAP *)dat[Rato_1+frame[0]].dat;

      timestart=Game_Time;

    if ((frame[0]++)>(MaxFrames-2))
      frame[0]=0;
     }
   }
 if (Presa.Id==1)
  {
    MaxFrames=2;
    if ((Game_Time-timestart)>=DELAY)
     {  
      Presa.Imagem=(BITMAP *)dat[Ovo_1+frame[1]].dat;

      timestart=Game_Time;

    if ((frame[1]++)>(MaxFrames-2))
      frame[1]=0;
     }
  }
}
void rnd_presa()
{
char testxy=1;

  	  do{

  	      Presa.x=((rand()%29)+1)*18;
  	      Presa.y=((rand()%25)+1)*18;
  	      for(pos=0;pos<=comp; pos++ )
  	        {
  	         if ( ((Presa.x==Cobra[pos].dx) && (Presa.y==Cobra[pos].dy)) || ((Presa.x==Cobra[pos].dx-9) && (Presa.y==Cobra[pos].dy)) || ((Presa.x==Cobra[pos].dx) && (Presa.y==Cobra[pos].dy-9)) || ((Presa.x==Cobra[pos].dx+9) && (Presa.y==Cobra[pos].dy)) || ((Presa.x==Cobra[pos].dx) && (Presa.y==Cobra[pos].dy+9)) )
  	            {
  	             testxy=1;
  	             break;
  	            }
  	         else
  	           testxy=0;
  	        }
  	     }while  (testxy==1);

  	  Presa.Id=rand()%2;
  	  if (Presa.Id==0)
  	  Presa.Imagem=Rato_BMP;
  	  else
  	  Presa.Imagem=Ovo_BMP;
          comp++;
  	  /*Cobra[comp].Imagem=Rabo_BMP;
  	  Cobra[comp].x=Cobra[comp-1].x;
  	  Cobra[comp].y=Cobra[comp-1].y;
  	  Cobra[comp-1].Imagem=Corpo_BMP;
  	  */
  	  Cobra[comp-1].Imagem=Corpo_BMP;
  	  Cobra[comp].Imagem=Rabo_BMP;
  	  Cobra[comp].x=Cobra[comp].dx;
          Cobra[comp].y=Cobra[comp].dy;

}

void Colisao()
{  
  if (((Cobra[0].x>Presa.x-18) && (Cobra[0].x<Presa.x+18)) && ((Cobra[0].y>Presa.y-18) && (Cobra[0].y<Presa.y+18)))
     Cobra[0].Imagem=Cabeca1_BMP;
  else
     Cobra[0].Imagem=Cabeca_BMP;

  if ((Cobra[0].x==Presa.x) && (Cobra[0].y==Presa.y))
        rnd_presa();//verifica se presa foi comida e mete outra nova

  if (((Cobra[0].x>522) || (Cobra[0].y>450)) || ((Cobra[0].x<18) || (Cobra[0].y<18)))  
     Game_end=1;
  else
    for(pos=1;pos<=comp; pos++ )
      {
     	if (((Cobra[0].x>Cobra[pos].x-9) && (Cobra[0].x<Cobra[pos].x+9)) && ((Cobra[0].y>Cobra[pos].y-9) && (Cobra[0].y<Cobra[pos].y+9)))
           Game_end=1;
      }
   if (Game_end==1)
             { 
               int it=0;
               DELAY=50;
               MaxFrames=7;
               Temp_BMP = create_bitmap(SCREEN_W, SCREEN_H);
               masked_blit(Game_Over_BMP,Main_F_buffer,0,0,210,200, Game_Over_BMP->w, Game_Over_BMP->h);
               blit(Main_F_buffer, Temp_BMP, 0, 0, 0, 0, SCREEN_W, SCREEN_H);
               while (it<7) 
                 {
                   clear(Main_F_buffer);
                   blit(Temp_BMP, Main_F_buffer, 0, 0, 0, 0, SCREEN_W, SCREEN_H);
                   if ((Game_Time-timestart)>=DELAY) 
                    {  
                      Estr_BMP=(BITMAP *)dat[Estr_1+frame[2]].dat;
                      it++;
                      timestart=Game_Time;

                      if ((frame[2]++)>(MaxFrames-2)) 
                         frame[2]=0;
                    }
                   rotate_sprite(Main_F_buffer, Estr_BMP, Cobra_old[0].x-7, Cobra_old[0].y-7,  itofix(0));
                   blit(Main_F_buffer, screen, 0, 0, 0, 0, SCREEN_W, SCREEN_H); 

                 }
               clear(Main_F_buffer);
               blit(Temp_BMP, Main_F_buffer, 0, 0, 0, 0, SCREEN_W, SCREEN_H);
               blit(Main_F_buffer, screen, 0, 0, 0, 0, SCREEN_W, SCREEN_H);
 	       rest(1000);
               clear_keybuf();
               readkey();
               opcao_M=2;
	     }

}

void Sub_Menu()
{
   char Menu=1;
   BITMAP *Pause_BMP;
   Sair_BMP= (BITMAP *)dat[Sair].dat;
   Voltar_BMP= (BITMAP *)dat[Voltar].dat;
   Pause_BMP= (BITMAP *)dat[Pause].dat;
   Temp_BMP = create_bitmap(SCREEN_W, SCREEN_H); 
   masked_blit(Pause_BMP,Main_F_buffer,0,0,230,180, Pause_BMP->w, Pause_BMP->h);
   blit(Main_F_buffer, Temp_BMP, 0, 0, 0, 0, SCREEN_W, SCREEN_H);
   draw_sprite(Main_F_buffer, Voltar_BMP, 560, 200);
   stretch_sprite(Main_F_buffer, Sair_BMP, 575, 248,3*(Sair_BMP->w/4),3*(Sair_BMP->h/4));  
   blit(Main_F_buffer, screen, 0, 0, 0, 0, SCREEN_W, SCREEN_H);

   do{
      clear_keybuf();
      if (key[KEY_UP])
        {
          //key[KEY_UP]=0;
          if (Menu!=1)
             Menu--;
          switch(Menu)
	   { 
	    case 1:
	      clear(Main_F_buffer);
	      
	      blit(Temp_BMP, Main_F_buffer, 0, 0, 0, 0, SCREEN_W, SCREEN_H);
	      draw_sprite(Main_F_buffer, Voltar_BMP, 560, 200);
              stretch_sprite(Main_F_buffer, Sair_BMP, 575, 248, 3*(Sair_BMP->w/4),3*(Sair_BMP->h/4));
              blit(Main_F_buffer, screen, 0, 0, 0, 0, SCREEN_W, SCREEN_H); 
              Game_end=0;
            break;
            case 2:
	      clear(Main_F_buffer);
	      blit(Temp_BMP, Main_F_buffer, 0, 0, 0, 0, SCREEN_W, SCREEN_H);
	      draw_sprite(Main_F_buffer, Sair_BMP,  570, 248);
              stretch_sprite(Main_F_buffer, Voltar_BMP, 565, 195,3*(Voltar_BMP->w/4),3*(Voltar_BMP->h/4));
              blit(Main_F_buffer, screen, 0, 0, 0, 0, SCREEN_W, SCREEN_H); 
              Game_end=2;
            break; 
           }
         }  

      if (key[KEY_DOWN])
        {
          //key[KEY_DOWN]=0;
          if (Menu!=2)
             Menu++;
          switch(Menu)
	    {
	     case 1:
	       clear(Main_F_buffer);
	       blit(Temp_BMP, Main_F_buffer, 0, 0, 0, 0, SCREEN_W, SCREEN_H);
	        draw_sprite(Main_F_buffer, Voltar_BMP, 560, 200);
                stretch_sprite(Main_F_buffer, Sair_BMP, 575, 248, 3*(Sair_BMP->w/4),3*(Sair_BMP->h/4));
                blit(Main_F_buffer, screen, 0, 0, 0, 0, SCREEN_W, SCREEN_H); 
             Game_end=0;
             break;
             case 2:
	        clear(Main_F_buffer);
	        blit(Temp_BMP, Main_F_buffer, 0, 0, 0, 0, SCREEN_W, SCREEN_H);
	        draw_sprite(Main_F_buffer, Sair_BMP, 570, 248);
                stretch_sprite(Main_F_buffer, Voltar_BMP, 565, 195, 3*(Voltar_BMP->w/4),3*(Voltar_BMP->h/4));
                blit(Main_F_buffer, screen, 0, 0, 0, 0, SCREEN_W, SCREEN_H); 
             Game_end=2;
             break;
            }
         }   
        
    }while (!key[KEY_ENTER]);
}

void nivel()
{
  char tc;
  draw();
  nivel_vel=35;
  Temp_BMP = create_bitmap(SCREEN_W, SCREEN_H);
  masked_blit(Barra_Quadro_BMP,Main_F_buffer,0,0,274-(Barra_Quadro_BMP->w/2),(SCREEN_H/2)-(Barra_Quadro_BMP->h/2), Barra_Quadro_BMP->w, Barra_Quadro_BMP->h);
  blit(Main_F_buffer, Temp_BMP, 0, 0, 0, 0, SCREEN_W, SCREEN_H);
  blit(Main_F_buffer, screen, 0, 0, 0, 0, SCREEN_W, SCREEN_H);
  key[KEY_ENTER]=0;
  while(!key[KEY_ENTER])
   {
      if ((key[KEY_LEFT]) || (key[KEY_RIGHT]))
               {
                 if (key[KEY_LEFT])
                    {
                      key[KEY_LEFT]=0;
                      if (nivel_vel!=35)
                        {nivel_vel+=5; tc=0;}
                      else
                        tc++;
                    }
                 else if (key[KEY_RIGHT])
                    {
                      key[KEY_RIGHT]=0;
                      if (nivel_vel!=10)
                        {nivel_vel-=5; tc=0;}
                      else
                        tc++;
                    }
                 if (tc==0)
                   {
                     switch(nivel_vel)
		      {
		       case 35:
		         clear(Main_F_buffer);
	                 blit(Temp_BMP, Main_F_buffer, 0, 0, 0, 0, SCREEN_W, SCREEN_H);
  			 blit(Main_F_buffer, screen, 0, 0, 0, 0, SCREEN_W, SCREEN_H);
                       break;
                       case 30:
		         clear(Main_F_buffer);
	                 blit(Temp_BMP, Main_F_buffer, 0, 0, 0, 0, SCREEN_W, SCREEN_H);
		         stretch_sprite(Main_F_buffer, Barra_Nivel_S_BMP, 241, 265,Barra_Nivel_S_BMP->w,25);
  			 blit(Main_F_buffer, screen, 0, 0, 0, 0, SCREEN_W, SCREEN_H);
                       break;
                       case 25:
		         clear(Main_F_buffer);
	                 blit(Temp_BMP, Main_F_buffer, 0, 0, 0, 0, SCREEN_W, SCREEN_H);
		         stretch_sprite(Main_F_buffer, Barra_Nivel_S_BMP, 241, 265,Barra_Nivel_S_BMP->w,25);
  			 stretch_sprite(Main_F_buffer, Barra_Nivel_S_BMP, 261, 256,Barra_Nivel_S_BMP->w,34);
  			 blit(Main_F_buffer, screen, 0, 0, 0, 0, SCREEN_W, SCREEN_H);
                       break;
                       case 20:
		         clear(Main_F_buffer);
	                 blit(Temp_BMP, Main_F_buffer, 0, 0, 0, 0, SCREEN_W, SCREEN_H);
		         stretch_sprite(Main_F_buffer, Barra_Nivel_S_BMP, 241, 265,Barra_Nivel_S_BMP->w,25);
  			 stretch_sprite(Main_F_buffer, Barra_Nivel_S_BMP, 261, 256,Barra_Nivel_S_BMP->w,34);
  			 stretch_sprite(Main_F_buffer, Barra_Nivel_S_BMP, 281, 247,Barra_Nivel_S_BMP->w,43);
  			 blit(Main_F_buffer, screen, 0, 0, 0, 0, SCREEN_W, SCREEN_H);
                       break;
                       case 15:
		         clear(Main_F_buffer);
	                 blit(Temp_BMP, Main_F_buffer, 0, 0, 0, 0, SCREEN_W, SCREEN_H);
		         stretch_sprite(Main_F_buffer, Barra_Nivel_S_BMP, 241, 265,Barra_Nivel_S_BMP->w,25);
  			 stretch_sprite(Main_F_buffer, Barra_Nivel_S_BMP, 261, 256,Barra_Nivel_S_BMP->w,34);
  			 stretch_sprite(Main_F_buffer, Barra_Nivel_S_BMP, 281, 247,Barra_Nivel_S_BMP->w,43);
  			 stretch_sprite(Main_F_buffer, Barra_Nivel_S_BMP, 301, 238,Barra_Nivel_S_BMP->w,52);
  			 blit(Main_F_buffer, screen, 0, 0, 0, 0, SCREEN_W, SCREEN_H);
                       break;
                       case 10:
		         clear(Main_F_buffer);
	                 blit(Temp_BMP, Main_F_buffer, 0, 0, 0, 0, SCREEN_W, SCREEN_H);
		         stretch_sprite(Main_F_buffer, Barra_Nivel_S_BMP, 241, 265,Barra_Nivel_S_BMP->w,25);
  			 stretch_sprite(Main_F_buffer, Barra_Nivel_S_BMP, 261, 256,Barra_Nivel_S_BMP->w,34);
  			 stretch_sprite(Main_F_buffer, Barra_Nivel_S_BMP, 281, 247,Barra_Nivel_S_BMP->w,43);
  			 stretch_sprite(Main_F_buffer, Barra_Nivel_S_BMP, 301, 238,Barra_Nivel_S_BMP->w,52);
  			 stretch_sprite(Main_F_buffer, Barra_Nivel_S_BMP, 321, 229,Barra_Nivel_S_BMP->w,61);
  			 blit(Main_F_buffer, screen, 0, 0, 0, 0, SCREEN_W, SCREEN_H);
                       break;
                   }
                  }
               }   
   }
}

void Game()
 {     	
 	int i, g=0;
 	dir=1;
 	comp=6;
 	pontos=0;
 	Cabeca_BMP = (BITMAP *)dat[Cabeca].dat;
 	Cabeca1_BMP = (BITMAP *)dat[Cabeca1].dat;
 	Rabo_BMP = (BITMAP *)dat[Rabo].dat;
 	Corpo_BMP = (BITMAP *)dat[Corpo].dat;
 	Game_Over_BMP=(BITMAP *)dat[Game_Over].dat;
 	Rato_BMP=(BITMAP *)dat[Rato_1].dat;
 	Ovo_BMP=(BITMAP *)dat[Ovo_1].dat;
 	Estr_BMP=(BITMAP *)dat[Estr_1].dat;
 	Barra_Quadro_BMP=(BITMAP *)dat[Barra_Quadro].dat;
 	Barra_Nivel_S_BMP=(BITMAP *)dat[Barra_Nivel_S].dat;
 	PFont_BMP=(BITMAP *)dat[Pfont].dat;

 	Cobra[0].Imagem=Cabeca_BMP;
 	for(pos=1;pos<comp; pos++ )
 	   Cobra[pos].Imagem=Corpo_BMP;
	Cobra[comp].Imagem=Rabo_BMP;
 	Main_F_buffer = create_bitmap(SCREEN_W, SCREEN_H);

         for (i=0;i<=(comp+1);i++)
           {
          g+=18;
         Cobra[i].x=18*20-g;
         Cobra[i].y=18*13;
         Cobra[i].dx=18*20-g;
         Cobra[i].dy=18*13;
         Cobra[i].anglo=0;
         Cobra_old[i].anglo=0;
           }
         Game_end=0;
         install_int(inc_Game_Time, 1);
         srand(time(0));
         rnd_presa();
         Fundo_G_BMP = (BITMAP *)dat[Fundo_G1+(rand()%4)].dat;
         nivel();
         while (Game_end==0) 
         {           
 	 
 	 Gametimestart=Game_Time;
 	 
 	 if (Cobra[0].x==Cobra[0].dx && Cobra[0].y==Cobra[0].dy)
 	  {
 	  if((key[KEY_RIGHT]) && (dir>2))
 	       {
              
 	       	dir=1;
 	       }
 	  else if((key[KEY_LEFT]) && (dir>2))
 	      {
               
 	       	dir=2;
 	        
 	       }
 	  else if((key[KEY_UP]) && (dir<3)) 
 	       {
              
 	       	dir=3;
 	       }
 	  else if((key[KEY_DOWN]) && (dir<3))
 	       {
              
 	       	dir=4;
 	       }
 	
   
 	  
 	 for(pos=0;pos<=comp; pos++ )
          {
                 Cobra_old[pos].dx = Cobra[pos].dx;
                 Cobra_old[pos].dy = Cobra[pos].dy;
                 Cobra_old[pos].anglo = Cobra[pos].anglo;
          }
 	  
 	  switch(dir)
 	  {
 	   case 1:Cobra[0].anglo=0;
 	          Cobra[0].dx+=18;
 	          break;
 	   case 2:Cobra[0]. anglo=128;
 	          Cobra[0].dx-=18;
 	          break;
 	   case 3:Cobra[0]. anglo=196;
 	          Cobra[0].dy-=18;
 	   	  break;
 	   case 4:Cobra[0]. anglo=64;
 	          Cobra[0].dy+=18;
 	  	  break;
 	  }
 	 
         for(pos=0;pos<=comp; pos++ )
          {
             Cobra[pos+1].dx=Cobra_old[pos].dx;
             Cobra[pos+1].dy=Cobra_old[pos].dy;
             Cobra[pos+1].anglo=Cobra_old[pos].anglo;
          }
 	
 	
 	 }
 	
	 	
       for(pos=0;pos<=comp; pos++ )
 	 {
 	  if (Cobra[pos].x<Cobra[pos].dx)
	   {				
	    Cobra[pos].x+=3;
	   }
	  if (Cobra[pos].x>Cobra[pos].dx)
	   {
	    Cobra[pos].x-=3;
	   }
	  if (Cobra[pos].y<Cobra[pos].dy)
	   {
	    Cobra[pos].y+=3;
	   }
	  if (Cobra[pos].y>Cobra[pos].dy)
	   {
	    Cobra[pos].y-=3;
	    	   }
 	  } 
 	  
 	  
 	  if (key[KEY_ESC] || key[KEY_P])
 	   Sub_Menu();
	  
	  if (key[KEY_F2]) 
	      {
	      key[KEY_F2]=FALSE;
	      rnd_presa();
	      }
	      	
	  Colisao();
	  Presas();
 	  pontos_func(); 
 	  
 	  if (Game_end==0)
 	   draw();
 	  	 
 	  while( ((Game_Time-Gametimestart)) < nivel_vel)   {}
 	 
 	 }
 	key[KEY_ESC]=FALSE;
 	remove_int(inc_Game_Time);

}

/*
do {
      
      k = readkey();
           
      textprintf(screen, font, 8, SCREEN_H-16, makecol(0, 0, 0),
		 "ASCII code is %d", k&0xFF);
   } while ((k&0xFF) != 27);

*/
/*
09-03-2002 18:51
em falta:
fazer a parte de "os melhores"

Som: -efeitos:
            -quando bate 
            -quabdo come
            -menus  
     -sons de fundo: 
            -1 pra cada nivel 
            -1 pro menu  

pro finalizar:
        melhorar grafismos
        optimiza�ao de c�digo
        detec�ao e correc�ao de bug's
           
        nivel -> pontos
           10 -> 10p
           15 ->  8p
           20 ->  6p
           25 ->  4p
           30 ->  2p
           35 ->  1p 

*/
