#include "Variaveis.h"

struct obj
{
  int x, y;
  int dx, dy; //destino x e y
  unsigned char anglo;
  BITMAP *Imagem;

} Cobra[751], Cobra_old[751]; //(30*25)

/*void Menu_Anim()
 {
  int i;
  int comp=9;
  Cobra[0].Imagem=Cabeca_BMP;
  for (i=0;i<=(comp+1);i++)
           {
          g+=18;
         Cobra[i].x=18*20;
         Cobra[i].y=18*13+g;
         Cobra[i].dx=18*20;
         Cobra[i].dy=18*13+g;
         Cobra[i].anglo=0;
         Cobra_old[i].anglo=0;
           }	
 	
 	
 	
 	
 }*/






char Main_menu()
{
  int i;
  char op=1, tc=0;
  BITMAP *Main_F_buffer, *Main_F_BMP, *L_A_BMP, *L_C_BMP, *L_D_BMP, *L_E_BMP, *L_G_BMP, *L_I_BMP, *L_J_BMP, *L_O_BMP, *L_R_BMP, *L_S_BMP, *L_T_BMP, *L_L_BMP, *L_M_BMP, *L_H_BMP;
          

         Main_F_BMP = (BITMAP *)dat[Main_F].dat; 
         L_A_BMP = (BITMAP *)dat[L_A].dat;
         L_C_BMP = (BITMAP *)dat[L_C].dat;
         L_D_BMP = (BITMAP *)dat[L_D].dat;
         L_E_BMP = (BITMAP *)dat[L_E].dat;
         L_G_BMP = (BITMAP *)dat[L_G].dat;
         L_I_BMP = (BITMAP *)dat[L_I].dat;
         L_J_BMP = (BITMAP *)dat[L_J].dat;
         L_O_BMP = (BITMAP *)dat[L_O].dat;
         L_R_BMP = (BITMAP *)dat[L_R].dat;
         L_S_BMP = (BITMAP *)dat[L_S].dat;
         L_T_BMP = (BITMAP *)dat[L_T].dat;
         L_L_BMP = (BITMAP *)dat[L_L].dat;
         L_M_BMP = (BITMAP *)dat[L_M].dat;
         L_H_BMP = (BITMAP *)dat[L_H].dat;
                                    
         Main_F_buffer = create_bitmap(SCREEN_W, SCREEN_H);       
          
         //clear(screen);
         
         clear(Main_F_buffer);               
         masked_blit(Main_F_BMP,Main_F_buffer, 0, 0, 0, 0, SCREEN_W, SCREEN_H);
         
         masked_blit( L_J_BMP , Main_F_buffer , 0, 0, (320-(L_J_BMP->w/2))-88, 180, L_J_BMP->w, L_J_BMP->h);
         masked_blit( L_O_BMP , Main_F_buffer , 0, 0, (320-(L_O_BMP->w/2))-45, 180, L_O_BMP->w, L_O_BMP->h);
         masked_blit( L_G_BMP , Main_F_buffer , 0, 0, 320-(L_G_BMP->w/2), 180, L_G_BMP->w, L_G_BMP->h);
         masked_blit( L_A_BMP , Main_F_buffer , 0, 0, (320-(L_A_BMP->w/2))+45, 180, L_A_BMP->w, L_A_BMP->h);
         masked_blit( L_R_BMP , Main_F_buffer , 0, 0, (320-(L_R_BMP->w/2))+89, 180, L_R_BMP->w, L_R_BMP->h);
    
         masked_blit( L_O_BMP , Main_F_buffer , 0, 0, (320-(L_O_BMP->w/2))-116, 180+45, L_O_BMP->w, L_O_BMP->h);
         masked_blit( L_S_BMP , Main_F_buffer , 0, 0, (320-(L_S_BMP->w/2))-96, 180+45, L_S_BMP->w, L_S_BMP->h);
         masked_blit( L_M_BMP , Main_F_buffer , 0, 0, (320-(L_M_BMP->w/2))-56, 180+45, L_M_BMP->w, L_M_BMP->h);
         masked_blit( L_E_BMP , Main_F_buffer , 0, 0, (320-(L_E_BMP->w/2))-24, 180+45, L_E_BMP->w, L_E_BMP->h);
         masked_blit( L_L_BMP , Main_F_buffer , 0, 0, (320-(L_L_BMP->w/2)), 180+45, L_L_BMP->w, L_L_BMP->h);
         masked_blit( L_H_BMP , Main_F_buffer , 0, 0, (320-(L_H_BMP->w/2))+24, 180+45, L_H_BMP->w, L_H_BMP->h);
         masked_blit( L_O_BMP , Main_F_buffer , 0, 0, (320-(L_O_BMP->w/2))+54, 180+45, L_O_BMP->w, L_O_BMP->h);
         masked_blit( L_R_BMP , Main_F_buffer , 0, 0, (320-(L_R_BMP->w/2))+80, 180+45, L_R_BMP->w, L_R_BMP->h);
         masked_blit( L_E_BMP , Main_F_buffer , 0, 0, (320-(L_E_BMP->w/2))+108, 180+45, L_E_BMP->w, L_E_BMP->h);
         masked_blit( L_S_BMP , Main_F_buffer , 0, 0, (320-(L_S_BMP->w/2))+128, 180+45, L_S_BMP->w, L_S_BMP->h);
           
         masked_blit( L_C_BMP , Main_F_buffer , 0, 0, (320-(L_C_BMP->w/2))-82, 270, L_C_BMP->w, L_C_BMP->h);
         masked_blit( L_R_BMP , Main_F_buffer , 0, 0, (320-(L_R_BMP->w/2))-58, 270, L_R_BMP->w, L_R_BMP->h);
         masked_blit( L_E_BMP , Main_F_buffer , 0, 0, (320-(L_E_BMP->w/2))-34, 270, L_E_BMP->w, L_E_BMP->h);
         masked_blit( L_D_BMP , Main_F_buffer , 0, 0, (320-(L_D_BMP->w/2))-10, 270, L_D_BMP->w, L_D_BMP->h);
         masked_blit( L_I_BMP , Main_F_buffer , 0, 0, (320-(L_I_BMP->w/2))+12, 270, L_I_BMP->w, L_I_BMP->h);
         masked_blit( L_T_BMP , Main_F_buffer , 0, 0, (320-(L_T_BMP->w/2))+32, 270, L_T_BMP->w, L_T_BMP->h);
         masked_blit( L_O_BMP , Main_F_buffer , 0, 0, (320-(L_O_BMP->w/2))+56, 270, L_O_BMP->w, L_O_BMP->h);
         masked_blit( L_S_BMP , Main_F_buffer , 0, 0, (320-(L_S_BMP->w/2))+82, 270, L_S_BMP->w, L_S_BMP->h);
                                           
         masked_blit( L_S_BMP , Main_F_buffer , 0, 0, (320-(L_S_BMP->w/2))-36, 310, L_S_BMP->w, L_R_BMP->h);
         masked_blit( L_A_BMP , Main_F_buffer , 0, 0, (320-(L_A_BMP->w/2))-12, 310, L_A_BMP->w, L_A_BMP->h);
         masked_blit( L_I_BMP , Main_F_buffer , 0, 0, (320-(L_I_BMP->w/2))+12, 310, L_I_BMP->w, L_I_BMP->h);
         masked_blit( L_R_BMP , Main_F_buffer , 0, 0, (320-(L_R_BMP->w/2))+34, 310, L_R_BMP->w, L_R_BMP->h);
         
         blit(Main_F_buffer, screen, 0, 0, 0, 0, SCREEN_W, SCREEN_H); 
         rest(200);

          do{
               clear_keybuf();              
               
              if ((key[KEY_UP]) || (key[KEY_DOWN]))
               {
                 if (key[KEY_UP])                                                 
                    {                 
                      key[KEY_UP]=0;
                      if (op!=1)
                        {op--; tc=0;}
                      else
                        tc++;  
                    }
                 else if (key[KEY_DOWN])
                    {                 
                      key[KEY_DOWN]=0;
                      if (op!=4)
                        {op++; tc=0;}
                      else
                        tc++;  
                    }  
                 if (tc==0)
                   {
                 switch(op)
		   {   
		    case 1: 
		          for(i=0;i<20;i+=3 )
			   { 
		          clear(Main_F_buffer);               
                          masked_blit(Main_F_BMP,Main_F_buffer, 0, 0, 0, 0, SCREEN_W, SCREEN_H);
                          masked_blit( L_J_BMP , Main_F_buffer , 0, 0, (320-(L_J_BMP->w/2))-48-i-i, 180, L_J_BMP->w, L_J_BMP->h);
         		  masked_blit( L_O_BMP , Main_F_buffer , 0, 0, (320-(L_O_BMP->w/2))-25-i, 180, L_O_BMP->w, L_O_BMP->h);
         		  masked_blit( L_G_BMP , Main_F_buffer , 0, 0, 320-(L_G_BMP->w/2), 180, L_G_BMP->w, L_G_BMP->h);
         		  masked_blit( L_A_BMP , Main_F_buffer , 0, 0, (320-(L_A_BMP->w/2))+25+i, 180, L_A_BMP->w, L_A_BMP->h);
         		  masked_blit( L_R_BMP , Main_F_buffer , 0, 0, (320-(L_R_BMP->w/2))+49+i+i, 180, L_R_BMP->w, L_R_BMP->h);
         		  masked_blit( L_O_BMP , Main_F_buffer , 0, 0, (320-(L_O_BMP->w/2))-116, 180+45, L_O_BMP->w, L_O_BMP->h);
         		  masked_blit( L_S_BMP , Main_F_buffer , 0, 0, (320-(L_S_BMP->w/2))-96, 180+45, L_S_BMP->w, L_S_BMP->h);
         		  masked_blit( L_M_BMP , Main_F_buffer , 0, 0, (320-(L_M_BMP->w/2))-56, 180+45, L_M_BMP->w, L_M_BMP->h);
         		  masked_blit( L_E_BMP , Main_F_buffer , 0, 0, (320-(L_E_BMP->w/2))-24, 180+45, L_E_BMP->w, L_E_BMP->h);
         		  masked_blit( L_L_BMP , Main_F_buffer , 0, 0, (320-(L_L_BMP->w/2)), 180+45, L_L_BMP->w, L_L_BMP->h);
         		  masked_blit( L_H_BMP , Main_F_buffer , 0, 0, (320-(L_H_BMP->w/2))+24, 180+45, L_H_BMP->w, L_H_BMP->h);
         		  masked_blit( L_O_BMP , Main_F_buffer , 0, 0, (320-(L_O_BMP->w/2))+54, 180+45, L_O_BMP->w, L_O_BMP->h);
         		  masked_blit( L_R_BMP , Main_F_buffer , 0, 0, (320-(L_R_BMP->w/2))+80, 180+45, L_R_BMP->w, L_R_BMP->h);
         		  masked_blit( L_E_BMP , Main_F_buffer , 0, 0, (320-(L_E_BMP->w/2))+108, 180+45, L_E_BMP->w, L_E_BMP->h);
         		  masked_blit( L_S_BMP , Main_F_buffer , 0, 0, (320-(L_S_BMP->w/2))+128, 180+45, L_S_BMP->w, L_S_BMP->h);
         		  masked_blit( L_C_BMP , Main_F_buffer , 0, 0, (320-(L_C_BMP->w/2))-82, 270, L_C_BMP->w, L_C_BMP->h);
         		  masked_blit( L_R_BMP , Main_F_buffer , 0, 0, (320-(L_R_BMP->w/2))-58, 270, L_R_BMP->w, L_R_BMP->h);
         		  masked_blit( L_E_BMP , Main_F_buffer , 0, 0, (320-(L_E_BMP->w/2))-34, 270, L_E_BMP->w, L_E_BMP->h);
         		  masked_blit( L_D_BMP , Main_F_buffer , 0, 0, (320-(L_D_BMP->w/2))-10, 270, L_D_BMP->w, L_D_BMP->h);
         		  masked_blit( L_I_BMP , Main_F_buffer , 0, 0, (320-(L_I_BMP->w/2))+12, 270, L_I_BMP->w, L_I_BMP->h);
         		  masked_blit( L_T_BMP , Main_F_buffer , 0, 0, (320-(L_T_BMP->w/2))+32, 270, L_T_BMP->w, L_T_BMP->h);
         		  masked_blit( L_O_BMP , Main_F_buffer , 0, 0, (320-(L_O_BMP->w/2))+56, 270, L_O_BMP->w, L_O_BMP->h);
         		  masked_blit( L_S_BMP , Main_F_buffer , 0, 0, (320-(L_S_BMP->w/2))+82, 270, L_S_BMP->w, L_S_BMP->h);                
         		  masked_blit( L_S_BMP , Main_F_buffer , 0, 0, (320-(L_S_BMP->w/2))-36, 310, L_S_BMP->w, L_R_BMP->h);
         		  masked_blit( L_A_BMP , Main_F_buffer , 0, 0, (320-(L_A_BMP->w/2))-12, 310, L_A_BMP->w, L_A_BMP->h);
         		  masked_blit( L_I_BMP , Main_F_buffer , 0, 0, (320-(L_I_BMP->w/2))+12, 310, L_I_BMP->w, L_I_BMP->h);
         		  masked_blit( L_R_BMP , Main_F_buffer , 0, 0, (320-(L_R_BMP->w/2))+34, 310, L_R_BMP->w, L_R_BMP->h);
                          blit(Main_F_buffer, screen, 0, 0, 0, 0, SCREEN_W, SCREEN_H);
		          rest(10);
		           }
		           break;
		    case 2:
		           for(i=0;i<20;i+=3 )
		            {
		           clear(Main_F_buffer);               
                          masked_blit(Main_F_BMP,Main_F_buffer, 0, 0, 0, 0, SCREEN_W, SCREEN_H);
                          masked_blit( L_J_BMP , Main_F_buffer , 0, 0, (320-(L_J_BMP->w/2))-48, 180, L_J_BMP->w, L_J_BMP->h);
         		  masked_blit( L_O_BMP , Main_F_buffer , 0, 0, (320-(L_O_BMP->w/2))-25, 180, L_O_BMP->w, L_O_BMP->h);
         		  masked_blit( L_G_BMP , Main_F_buffer , 0, 0, 320-(L_G_BMP->w/2), 180, L_G_BMP->w, L_G_BMP->h);
         		  masked_blit( L_A_BMP , Main_F_buffer , 0, 0, (320-(L_A_BMP->w/2))+25, 180, L_A_BMP->w, L_A_BMP->h);
         		  masked_blit( L_R_BMP , Main_F_buffer , 0, 0, (320-(L_R_BMP->w/2))+49, 180, L_R_BMP->w, L_R_BMP->h);
         		  masked_blit( L_O_BMP , Main_F_buffer , 0, 0, (320-(L_O_BMP->w/2))-116-i-i-i-i-i, 180+45, L_O_BMP->w, L_O_BMP->h);
         		  masked_blit( L_S_BMP , Main_F_buffer , 0, 0, (320-(L_S_BMP->w/2))-96-i-i-i-i, 180+45, L_S_BMP->w, L_S_BMP->h);
         		  masked_blit( L_M_BMP , Main_F_buffer , 0, 0, (320-(L_M_BMP->w/2))-56-i-i, 180+45, L_M_BMP->w, L_M_BMP->h);
         		  masked_blit( L_E_BMP , Main_F_buffer , 0, 0, (320-(L_E_BMP->w/2))-24-i, 180+45, L_E_BMP->w, L_E_BMP->h);
         		  masked_blit( L_L_BMP , Main_F_buffer , 0, 0, (320-(L_L_BMP->w/2)), 180+45, L_L_BMP->w, L_L_BMP->h);
         		  masked_blit( L_H_BMP , Main_F_buffer , 0, 0, (320-(L_H_BMP->w/2))+24+i, 180+45, L_H_BMP->w, L_H_BMP->h);
         		  masked_blit( L_O_BMP , Main_F_buffer , 0, 0, (320-(L_O_BMP->w/2))+54+i+i, 180+45, L_O_BMP->w, L_O_BMP->h);
         		  masked_blit( L_R_BMP , Main_F_buffer , 0, 0, (320-(L_R_BMP->w/2))+80+i+i+i, 180+45, L_R_BMP->w, L_R_BMP->h);
         		  masked_blit( L_E_BMP , Main_F_buffer , 0, 0, (320-(L_E_BMP->w/2))+108+i+i+i+i, 180+45, L_E_BMP->w, L_E_BMP->h);
         		  masked_blit( L_S_BMP , Main_F_buffer , 0, 0, (320-(L_S_BMP->w/2))+128+i+i+i+i+i, 180+45, L_S_BMP->w, L_S_BMP->h);
         		  masked_blit( L_C_BMP , Main_F_buffer , 0, 0, (320-(L_C_BMP->w/2))-82, 270, L_C_BMP->w, L_C_BMP->h);
         		  masked_blit( L_R_BMP , Main_F_buffer , 0, 0, (320-(L_R_BMP->w/2))-58, 270, L_R_BMP->w, L_R_BMP->h);
         		  masked_blit( L_E_BMP , Main_F_buffer , 0, 0, (320-(L_E_BMP->w/2))-34, 270, L_E_BMP->w, L_E_BMP->h);
         		  masked_blit( L_D_BMP , Main_F_buffer , 0, 0, (320-(L_D_BMP->w/2))-10, 270, L_D_BMP->w, L_D_BMP->h);
         		  masked_blit( L_I_BMP , Main_F_buffer , 0, 0, (320-(L_I_BMP->w/2))+12, 270, L_I_BMP->w, L_I_BMP->h);
         		  masked_blit( L_T_BMP , Main_F_buffer , 0, 0, (320-(L_T_BMP->w/2))+32, 270, L_T_BMP->w, L_T_BMP->h);
         		  masked_blit( L_O_BMP , Main_F_buffer , 0, 0, (320-(L_O_BMP->w/2))+56, 270, L_O_BMP->w, L_O_BMP->h);
         		  masked_blit( L_S_BMP , Main_F_buffer , 0, 0, (320-(L_S_BMP->w/2))+82, 270, L_S_BMP->w, L_S_BMP->h);                
         		  masked_blit( L_S_BMP , Main_F_buffer , 0, 0, (320-(L_S_BMP->w/2))-36, 310, L_S_BMP->w, L_R_BMP->h);
         		  masked_blit( L_A_BMP , Main_F_buffer , 0, 0, (320-(L_A_BMP->w/2))-12, 310, L_A_BMP->w, L_A_BMP->h);
         		  masked_blit( L_I_BMP , Main_F_buffer , 0, 0, (320-(L_I_BMP->w/2))+12, 310, L_I_BMP->w, L_I_BMP->h);
         		  masked_blit( L_R_BMP , Main_F_buffer , 0, 0, (320-(L_R_BMP->w/2))+34, 310, L_R_BMP->w, L_R_BMP->h);
         		  blit(Main_F_buffer, screen, 0, 0, 0, 0, SCREEN_W, SCREEN_H);
		          rest(10);
		            }
		           break;
		   case 3:
		           for(i=0;i<20;i+=3 )
		            {
		          clear(Main_F_buffer);               
                          masked_blit(Main_F_BMP,Main_F_buffer, 0, 0, 0, 0, SCREEN_W, SCREEN_H);
                          masked_blit( L_J_BMP , Main_F_buffer , 0, 0, (320-(L_J_BMP->w/2))-48, 180, L_J_BMP->w, L_J_BMP->h);
         		  masked_blit( L_O_BMP , Main_F_buffer , 0, 0, (320-(L_O_BMP->w/2))-25, 180, L_O_BMP->w, L_O_BMP->h);
         		  masked_blit( L_G_BMP , Main_F_buffer , 0, 0, 320-(L_G_BMP->w/2), 180, L_G_BMP->w, L_G_BMP->h);
         		  masked_blit( L_A_BMP , Main_F_buffer , 0, 0, (320-(L_A_BMP->w/2))+25, 180, L_A_BMP->w, L_A_BMP->h);
         		  masked_blit( L_R_BMP , Main_F_buffer , 0, 0, (320-(L_R_BMP->w/2))+49, 180, L_R_BMP->w, L_R_BMP->h);
         		  masked_blit( L_O_BMP , Main_F_buffer , 0, 0, (320-(L_O_BMP->w/2))-116, 180+45, L_O_BMP->w, L_O_BMP->h);
         		  masked_blit( L_S_BMP , Main_F_buffer , 0, 0, (320-(L_S_BMP->w/2))-96, 180+45, L_S_BMP->w, L_S_BMP->h);
         		  masked_blit( L_M_BMP , Main_F_buffer , 0, 0, (320-(L_M_BMP->w/2))-56, 180+45, L_M_BMP->w, L_M_BMP->h);
         		  masked_blit( L_E_BMP , Main_F_buffer , 0, 0, (320-(L_E_BMP->w/2))-24, 180+45, L_E_BMP->w, L_E_BMP->h);
         		  masked_blit( L_L_BMP , Main_F_buffer , 0, 0, (320-(L_L_BMP->w/2)), 180+45, L_L_BMP->w, L_L_BMP->h);
         		  masked_blit( L_H_BMP , Main_F_buffer , 0, 0, (320-(L_H_BMP->w/2))+24, 180+45, L_H_BMP->w, L_H_BMP->h);
         		  masked_blit( L_O_BMP , Main_F_buffer , 0, 0, (320-(L_O_BMP->w/2))+54, 180+45, L_O_BMP->w, L_O_BMP->h);
         		  masked_blit( L_R_BMP , Main_F_buffer , 0, 0, (320-(L_R_BMP->w/2))+80, 180+45, L_R_BMP->w, L_R_BMP->h);
         		  masked_blit( L_E_BMP , Main_F_buffer , 0, 0, (320-(L_E_BMP->w/2))+108, 180+45, L_E_BMP->w, L_E_BMP->h);
         		  masked_blit( L_S_BMP , Main_F_buffer , 0, 0, (320-(L_S_BMP->w/2))+128, 180+45, L_S_BMP->w, L_S_BMP->h);
         		  masked_blit( L_C_BMP , Main_F_buffer , 0, 0, (320-(L_C_BMP->w/2))-77-i-i-i-i, 270, L_C_BMP->w, L_C_BMP->h);
         		  masked_blit( L_R_BMP , Main_F_buffer , 0, 0, (320-(L_R_BMP->w/2))-53-i-i-i, 270, L_R_BMP->w, L_R_BMP->h);
         		  masked_blit( L_E_BMP , Main_F_buffer , 0, 0, (320-(L_E_BMP->w/2))-29-i-i, 270, L_E_BMP->w, L_E_BMP->h);
         		  masked_blit( L_D_BMP , Main_F_buffer , 0, 0, (320-(L_D_BMP->w/2))-5-i, 270, L_D_BMP->w, L_D_BMP->h);
         		  masked_blit( L_I_BMP , Main_F_buffer , 0, 0, (320-(L_I_BMP->w/2))+7+i, 270, L_I_BMP->w, L_I_BMP->h);
         		  masked_blit( L_T_BMP , Main_F_buffer , 0, 0, (320-(L_T_BMP->w/2))+27+i+i, 270, L_T_BMP->w, L_T_BMP->h);
         		  masked_blit( L_O_BMP , Main_F_buffer , 0, 0, (320-(L_O_BMP->w/2))+51+i+i+i, 270, L_O_BMP->w, L_O_BMP->h);
         		  masked_blit( L_S_BMP , Main_F_buffer , 0, 0, (320-(L_S_BMP->w/2))+77+i+i+i+i, 270, L_S_BMP->w, L_S_BMP->h);  
         		  masked_blit( L_S_BMP , Main_F_buffer , 0, 0, (320-(L_S_BMP->w/2))-36, 310, L_S_BMP->w, L_R_BMP->h);
         		  masked_blit( L_A_BMP , Main_F_buffer , 0, 0, (320-(L_A_BMP->w/2))-12, 310, L_A_BMP->w, L_A_BMP->h);
         		  masked_blit( L_I_BMP , Main_F_buffer , 0, 0, (320-(L_I_BMP->w/2))+12, 310, L_I_BMP->w, L_I_BMP->h);
         		  masked_blit( L_R_BMP , Main_F_buffer , 0, 0, (320-(L_R_BMP->w/2))+34, 310, L_R_BMP->w, L_R_BMP->h);
		          blit(Main_F_buffer, screen, 0, 0, 0, 0, SCREEN_W, SCREEN_H);
		          rest(10);
		            }
		           break;        		    		      
		 case 4:
		          for(i=0;i<20;i+=3 )
		            {
		          clear(Main_F_buffer);               
                          masked_blit(Main_F_BMP,Main_F_buffer, 0, 0, 0, 0, SCREEN_W, SCREEN_H);
                          masked_blit( L_J_BMP , Main_F_buffer , 0, 0, (320-(L_J_BMP->w/2))-48, 180, L_J_BMP->w, L_J_BMP->h);
         		  masked_blit( L_O_BMP , Main_F_buffer , 0, 0, (320-(L_O_BMP->w/2))-25, 180, L_O_BMP->w, L_O_BMP->h);
         		  masked_blit( L_G_BMP , Main_F_buffer , 0, 0, 320-(L_G_BMP->w/2), 180, L_G_BMP->w, L_G_BMP->h);
         		  masked_blit( L_A_BMP , Main_F_buffer , 0, 0, (320-(L_A_BMP->w/2))+25, 180, L_A_BMP->w, L_A_BMP->h);
         		  masked_blit( L_R_BMP , Main_F_buffer , 0, 0, (320-(L_R_BMP->w/2))+49, 180, L_R_BMP->w, L_R_BMP->h);
         		  masked_blit( L_O_BMP , Main_F_buffer , 0, 0, (320-(L_O_BMP->w/2))-116, 180+45, L_O_BMP->w, L_O_BMP->h);
         		  masked_blit( L_S_BMP , Main_F_buffer , 0, 0, (320-(L_S_BMP->w/2))-96, 180+45, L_S_BMP->w, L_S_BMP->h);
         		  masked_blit( L_M_BMP , Main_F_buffer , 0, 0, (320-(L_M_BMP->w/2))-56, 180+45, L_M_BMP->w, L_M_BMP->h);
         		  masked_blit( L_E_BMP , Main_F_buffer , 0, 0, (320-(L_E_BMP->w/2))-24, 180+45, L_E_BMP->w, L_E_BMP->h);
         		  masked_blit( L_L_BMP , Main_F_buffer , 0, 0, (320-(L_L_BMP->w/2)), 180+45, L_L_BMP->w, L_L_BMP->h);
         		  masked_blit( L_H_BMP , Main_F_buffer , 0, 0, (320-(L_H_BMP->w/2))+24, 180+45, L_H_BMP->w, L_H_BMP->h);
         		  masked_blit( L_O_BMP , Main_F_buffer , 0, 0, (320-(L_O_BMP->w/2))+54, 180+45, L_O_BMP->w, L_O_BMP->h);
         		  masked_blit( L_R_BMP , Main_F_buffer , 0, 0, (320-(L_R_BMP->w/2))+80, 180+45, L_R_BMP->w, L_R_BMP->h);
         		  masked_blit( L_E_BMP , Main_F_buffer , 0, 0, (320-(L_E_BMP->w/2))+108, 180+45, L_E_BMP->w, L_E_BMP->h);
         		  masked_blit( L_S_BMP , Main_F_buffer , 0, 0, (320-(L_S_BMP->w/2))+128, 180+45, L_S_BMP->w, L_S_BMP->h);
         		  masked_blit( L_C_BMP , Main_F_buffer , 0, 0, (320-(L_C_BMP->w/2))-82, 270, L_C_BMP->w, L_C_BMP->h);
         		  masked_blit( L_R_BMP , Main_F_buffer , 0, 0, (320-(L_R_BMP->w/2))-58, 270, L_R_BMP->w, L_R_BMP->h);
         		  masked_blit( L_E_BMP , Main_F_buffer , 0, 0, (320-(L_E_BMP->w/2))-34, 270, L_E_BMP->w, L_E_BMP->h);
         		  masked_blit( L_D_BMP , Main_F_buffer , 0, 0, (320-(L_D_BMP->w/2))-10, 270, L_D_BMP->w, L_D_BMP->h);
         		  masked_blit( L_I_BMP , Main_F_buffer , 0, 0, (320-(L_I_BMP->w/2))+12, 270, L_I_BMP->w, L_I_BMP->h);
         		  masked_blit( L_T_BMP , Main_F_buffer , 0, 0, (320-(L_T_BMP->w/2))+32, 270, L_T_BMP->w, L_T_BMP->h);
         		  masked_blit( L_O_BMP , Main_F_buffer , 0, 0, (320-(L_O_BMP->w/2))+56, 270, L_O_BMP->w, L_O_BMP->h);
         		  masked_blit( L_S_BMP , Main_F_buffer , 0, 0, (320-(L_S_BMP->w/2))+82, 270, L_S_BMP->w, L_S_BMP->h);                
         		  masked_blit( L_S_BMP , Main_F_buffer , 0, 0, (320-(L_S_BMP->w/2))-24-i-i, 310, L_S_BMP->w, L_R_BMP->h);
         		  masked_blit( L_A_BMP , Main_F_buffer , 0, 0, (320-(L_A_BMP->w/2))-5-i, 310, L_A_BMP->w, L_A_BMP->h);
         		  masked_blit( L_I_BMP , Main_F_buffer , 0, 0, (320-(L_I_BMP->w/2))+5+i, 310, L_I_BMP->w, L_I_BMP->h);
         		  masked_blit( L_R_BMP , Main_F_buffer , 0, 0, (320-(L_R_BMP->w/2))+22+i+i, 310, L_R_BMP->w, L_R_BMP->h);
		          blit(Main_F_buffer, screen, 0, 0, 0, 0, SCREEN_W, SCREEN_H);
		          rest(10);
		            }
		      break;        		    		          
		   } 
		 }  
                }

		 
          }while (!key[KEY_ENTER]);        
  
     /*  
       destroy_bitmap(Main_F_BMP);
       
       destroy_bitmap(Jogar_S_BMP);
       destroy_bitmap(Jogar_US_BMP);
       destroy_bitmap(HighScores_L_BMP);
       destroy_bitmap(HighScores_UL_BMP);
       destroy_bitmap(Options_L_BMP);
       destroy_bitmap(Options_UL_BMP);
       destroy_bitmap(Credito_S_BMP);
       destroy_bitmap(Credito_US_BMP);
       //destroy_bitmap(Sair_S_BMP);
       //destroy_bitmap(Sair_US_BMP);
       
       destroy_bitmap(Main_F_buffer);     
     */
     return op;

}	
