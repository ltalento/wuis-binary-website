#include <stdlib.h>
#include <stdio.h>
#include "allegro.h"
#include "Snake_Game.h"
#include "Snake_Menu.h"
#include "Menus2.h"
#include "Game78.h"
#include "Sub Menus.h"
#include "Variaveis.h"

void main()
{   
   allegro_init();
   install_keyboard(); 
   install_timer();
   //LOCK_VARIABLE(x);  
   //LOCK_FUNCTION(inc_x);
   
   //if(MessageBox(NULL,"Would you like to run in fullscreen mode?", "GoldenSnake", MB_YESNO|MB_ICONQUESTION)==IDNO)
 /*  if(MessageBox(NULL,"Would you like to run in fullscreen mode?", "GoldenSnake", 0))
   {
     if (set_gfx_mode(GFX_AUTODETECT_WINDOWED, 640, 480, 0, 0) !=0) 
    {
    allegro_exit();
    printf("Erro configurando grafico\n");
    exit(1);
    }
   }
   else*/
   {
   if (set_gfx_mode(GFX_AUTODETECT, 640, 480, 0, 0) !=0) 
    {
    allegro_exit();
    printf("Erro configurando grafico\n");
    exit(1);
     }
   }  
      dat = load_datafile("Snake_Menu.dat");
      if (!dat) {
         allegro_exit();
         printf("Erro abrindo o ficheiro \"Snake_Menu.dat\" ");
         /* report an error! */
	 return;
      }
           
      set_palette((void *)dat[Pallete1].dat);
       if (opcao_M==2)
          OsMelhores(); 
                  
    while( opcao_M != 4) {    
      	opcao_M=Main_menu();
      	
      	if (opcao_M==1)
      	   {
      	    unload_datafile(dat);
      	    dat = load_datafile("Snake_Game.dat");
      	    Game();
      	    unload_datafile(dat);
      	    dat = load_datafile("Snake_Menu.dat");
           }
        if (opcao_M==2)
          OsMelhores(); 
        if (opcao_M==3)  
          Creditos();  
       }
       

 unload_datafile(dat);
 allegro_exit();
} 

END_OF_MAIN();
