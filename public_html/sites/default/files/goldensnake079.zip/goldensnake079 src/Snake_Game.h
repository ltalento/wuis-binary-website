/* Allegro datafile object indexes, produced by grabber v3.9.38 (WIP), MSVC */
/* Datafile: c:\Program Files\Microsoft Visual Studio\VC98\allegro\goldensnake076\goldensnake076\Snake_Game.dat */
/* Date: Tue Feb 26 10:33:34 2002 */
/* Do not hand edit! */

#define a                                0        /* PAL  */
#define Barra_Nivel_S                    1        /* BMP  */
#define Barra_Quadro                     2        /* BMP  */
#define Cabeca                           3        /* BMP  */
#define Cabeca1                          4        /* BMP  */
#define Corpo                            5        /* BMP  */
#define Estr_1                           6        /* BMP  */
#define Estr_2                           7        /* BMP  */
#define Estr_3                           8        /* BMP  */
#define Estr_4                           9        /* BMP  */
#define Estr_5                           10       /* BMP  */
#define Estr_6                           11       /* BMP  */
#define Estr_7                           12       /* BMP  */
#define Fundo_G1                         13       /* BMP  */
#define Fundo_G2                         14       /* BMP  */
#define Fundo_G3                         15       /* BMP  */
#define Fundo_G4                         16       /* BMP  */
#define Game_Over                        17       /* BMP  */
#define Ovo_1                            18       /* BMP  */
#define Ovo_2                            19       /* BMP  */
#define Pause                            20       /* BMP  */
#define Pfont                            21       /* BMP  */
#define Rabo                             22       /* BMP  */
#define Rato_1                           23       /* BMP  */
#define Rato_2                           24       /* BMP  */
#define Rato_3                           25       /* BMP  */
#define Rato_4                           26       /* BMP  */
#define Sair                             27       /* BMP  */
#define Voltar                           28       /* BMP  */

