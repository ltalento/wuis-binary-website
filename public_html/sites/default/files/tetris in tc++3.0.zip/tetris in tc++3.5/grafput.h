//#include <stdio.h>
//#include <conio.h>
#include <math.h>
#include <MEM.H>


void cls(unsigned char cor)
{
   _fmemset((void far*)0xA0000000,cor,64000);
}


void  pixel(int X, int Y, unsigned char Cor)
{ 
   asm {
        mov   ax, 0xA000
        mov   es, ax
   	mov   bx, [X]
   	mov   dx, [Y]
   	xchg  dh, dl
   	mov   al, [Cor]
   	mov   di, dx
   	shr   di, 2
   	add   di, dx
   	add   di, bx
   	stosb
        }
}

void linha(int x1,int y1,int x2,int y2,unsigned char cor)
{
	int i, deltax, deltay, numpixels,d, dinc1, dinc2,x, xinc1, xinc2,y, yinc1, yinc2;

	deltax = abs(x2 - x1);
	deltay = abs(y2 - y1);

	if(deltax >= deltay)
	{
		numpixels=deltax + 1;
		d=(2*deltay)-deltax;
		dinc1=deltay << 1;
		dinc2=(deltay-deltax) << 1;
		xinc1=1;
		xinc2=1;
		yinc1=0;
		yinc2=1;
	}
	else
	{
		numpixels = deltay + 1;
		d = (2 * deltax) - deltay;
		dinc1 = deltax << 1;
		dinc2 = (deltax - deltay) << 1;
		xinc1 = 0;
		xinc2 = 1;
		yinc1 = 1;
		yinc2 = 1;
	}

	if(x1 > x2)
	{
		xinc1 = - xinc1;
		xinc2 = - xinc2;
	}

	if(y1 > y2)
	{
		yinc1 = - yinc1;
		yinc2 = - yinc2;
	}

	x = x1;
	y = y1;

	for(i=1;i<=numpixels;i++)
	{
		pixel(x, y, cor);

		if(d < 0)
		{
			d = d + dinc1;
			x = x + xinc1;
			y = y + yinc1;
		}
		else
		{
			d = d + dinc2;
			x = x + xinc2;
			y = y + yinc2;
		}
	}
}

void modo13()
{
  asm {
      mov AX, 0013h
      int 10h
     }
}