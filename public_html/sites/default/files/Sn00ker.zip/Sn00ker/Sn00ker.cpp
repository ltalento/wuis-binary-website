//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
USERES("Sn00ker.res");
USEFORM("src\frmGame.cpp", frmMain);
USEUNIT("src\Ball.cpp");
USEUNIT("src\Circle.cpp");
USEUNIT("src\Figure.cpp");
USEUNIT("src\Line.cpp");
USEUNIT("src\Point2D.cpp");
USEUNIT("src\Vector2D.cpp");
USEUNIT("src\Polygons.cpp");
USEUNIT("src\Triangle.cpp");
USEUNIT("src\Player.cpp");
USEUNIT("src\Table.cpp");
USEUNIT("src\CueStick.cpp");
USEFORM("SRC\frmAbout.cpp", AboutBox);
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
        try
        {
                 Application->Initialize();
                 Application->CreateForm(__classid(TfrmMain), &frmMain);
                 Application->CreateForm(__classid(TAboutBox), &AboutBox);
                 Application->Run();
        }
        catch (Exception &exception)
        {
                 Application->ShowException(&exception);
        }
        return 0;
}
//---------------------------------------------------------------------------
