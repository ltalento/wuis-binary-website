//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "CueStick.h"

//---------------------------------------------------------------------------

#pragma package(smart_init)

/*
int CueStick::triangles[NRTRI][3]={
                {0, 1, 2}, {0, 3, 1}, {0, 4, 3},
                {0, 5, 4}, {0, 6, 5}, {0, 2, 6},
                {2, 7, 8}, {2, 1, 7}, {1, 9, 7},
                {1, 3, 9},  {3, 10, 9}, {3, 4, 10},
                {4, 11, 10},  {4, 5, 11}, {5, 12, 11},
                {5, 6, 12},  {6, 8, 12}, {6, 2, 8},
                {13, 8, 7},  {13, 7, 9}, {13, 9, 10},
                {13, 10, 11}, {13, 11, 12}, {13, 12, 8}};
 {0, 1, 2}, {1, 3, 2}, {3, 4, 2},
 {4, 5, 2}, {5, 6, 2}, {6, 0, 2},
 {7, 8, 0}, {8, 1, 0}, {8, 9, 1},
 {9, 3, 1}, {9, 10, 3}, {10, 4, 3},
 {10, 11, 4}, {11, 5, 4}, {11, 12, 5},
 {12, 6, 5}, {12, 7, 6}, {7, 0, 6},
 {8, 7, 13}, {9, 8, 13}, {10, 9, 13},
 {11, 10, 13}, {12, 11, 13}, {7, 12, 13}}; */
  /*
float CueStick::vertex[NRVERT][5] ={
                {0.001000, 0.001000, 0.001000, 0.079228, 0.475177},
                {0.001000, 0.087603, -0.049000, 0.079228, 0.119671},
                {0.001000, 0.001000, -0.099000, 0.079228, 0.475177},
                {0.001000, 0.087603, 0.051000, 0.079228, 0.119671},
                {0.001000, 0.001000, 0.101000, 0.079228, 0.475177},
                {0.001000, -0.085603, 0.051000, 0.079228, 0.830683},
                {0.001000, -0.085603, -0.049000, 0.079228, 0.830683},
                {15.000995, 0.111000, -0.074000, 0.971752, 0.023623},
                {15.000998, 0.001000, -0.149000, 0.971752, 0.475177},
                {15.000996, 0.111000, 0.076000, 0.971752, 0.023623},
                {15.000998, 0.001000, 0.151000, 0.971752, 0.475177},
                {15.000994, -0.109000, 0.076000, 0.971752, 0.926730},
                {15.000993, -0.109000, -0.074000, 0.971752, 0.926730},
                {15.000999, 0.001000, 0.001001, 0.971752, 0.475177}};
*/
CueStick::CueStick() : dir_ang(0)
{

}

CueStick::~CueStick()
{

}

void CueStick::SetPower(const int p)
{
  power=p;
}

void CueStick::SetVisible(const bool v)
{
     visible=v;
}


void CueStick::SetDirection(const Point2D &p)
{
        dir.Set(Point2D(target->Center().X(),target->Center().Y()),p);
        dir.Normalize();
        dir_ang = dir.Angle()*57.29+180;
}

void CueStick::SetTarget(Ball *t)
{
    target=t;
}

bool     CueStick::IsVisible() const
{
        return visible;
}

int CueStick::GetDirection() const
{
        return dir_ang;
}
Vector2D CueStick::GetVectDirection() const
{
        return dir;
}

GLuint*  CueStick::GetTexture()
{
        return &texture;
}

void CueStick::Draw()
{
        if(visible)
        {

                glColor3ub(255, 255, 255);
                glBindTexture(GL_TEXTURE_2D, texture );
                glPushMatrix();
                        glTranslatef( target->Center().X() , target->Center().Y() ,0);
                        glTranslatef( -dir.X()*(float(power+4)/5) , -dir.Y()*(float(power+4)/5) ,1);
                        glRotatef(dir_ang , 0 ,0 , 1);
                       /* glDisable(GL_LIGHTING);
                        glBegin( GL_TRIANGLES );
                        for(int tri=0;tri<NRTRI;tri++)
                        {
                                float A[3], B[3], C[3];
                                A[0]=vertex[triangles[tri][0]][0];
                                A[1]=vertex[triangles[tri][0]][1];
                                A[2]=vertex[triangles[tri][0]][2];

                                B[0]=vertex[triangles[tri][1]][0];
                                B[1]=vertex[triangles[tri][1]][1];
                                B[2]=vertex[triangles[tri][1]][2];

                                C[0]=A[1]*B[2]-A[2]*B[1];
                                C[1]=A[2]*B[0]-A[0]*B[2];
                                C[2]=A[0]*B[1]-A[1]*B[0];

                                glNormal3f(C[0],C[1],C[2]);

                                for(int i=0;i<3;i++)
                                {
                                   glTexCoord2f(vertex[ triangles[tri][i]][4] ,
                                                vertex[triangles[tri][i]][3]);

                                   glVertex3f(vertex[triangles[tri][i]][0] ,
                                                vertex[triangles[tri][i]][1],
                                                vertex[triangles[tri][i]][2]);
                                }
                        }
                        glEnd();
                        glEnable(GL_LIGHTING);*/
                         glBegin(GL_QUADS);
	                        glNormal3f(0, 0, 1);
                                glTexCoord2f(0, 1);
	                        glVertex3f(15,0.1,0);
	                        glTexCoord2f(0, 0);
	                        glVertex3f(0,0.05,0);
	                        glTexCoord2f(1, 0);
	                        glVertex3f(0,-0.05,0);
	                        glTexCoord2f(1, 1);
	                        glVertex3f(15,-0.1,0);
                        glEnd();
                glPopMatrix();

        }
}
