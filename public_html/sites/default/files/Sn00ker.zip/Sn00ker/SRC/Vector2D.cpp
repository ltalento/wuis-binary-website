//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Vector2D.h"

//---------------------------------------------------------------------------

#pragma package(smart_init)




Vector2D::Vector2D(): Point2D()
{

}

Vector2D::Vector2D(double x, double y): Point2D(x,y)
{
}

Vector2D::Vector2D(const Vector2D& other): Point2D(other.X(),other.Y())
{ }

Vector2D::~Vector2D()
{ }

void Vector2D::Set(const Point2D &a, const Point2D &b)
{
        SetX(b.X()-a.X());
        SetY(b.Y()-a.Y());
}

void Vector2D::Normalize()
{
        double n=Modulus();
        if (n>0)
        {
                SetX(X()/n);
                SetY(Y()/n);
        }
}

