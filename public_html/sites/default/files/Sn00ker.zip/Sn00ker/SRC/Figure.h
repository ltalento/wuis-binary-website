#ifndef FigureH
#define FigureH

#include <iostream.h>
class Point2D;
class Line;

class Figure {
   public:
       virtual ~Figure();

       virtual void Scale(double fx, double fy) = 0;
       virtual void Translate(double dx, double dy) = 0;
       virtual void Rotate(double angle) = 0;

       virtual void Write(ostream& = cout) const = 0;
       virtual void WriteLine(ostream& = cout) const = 0;

       virtual void RotateAround(double angle, const Point2D& p);
       virtual void Mirror(const Line& z);
};

#endif
