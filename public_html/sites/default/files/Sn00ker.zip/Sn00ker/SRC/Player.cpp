//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Player.h"

//---------------------------------------------------------------------------

#pragma package(smart_init)

Player::Player() : shoots(0),  ballTeam(Ball::UNDETERMINED), nrBalls(0)
{

}

Player::~Player()
{

}

void Player::SetIndex(const int &i)
{
        index=i;
}

int Player::GetIndex() const
{
        return index;
}

void Player::ShootsInc()
{
        shoots++;
}

void Player::ShootsDec()
{
        if(shoots>0)
                shoots--;
}

void Player::ShootsZero()
{
        shoots=0;
}

int  Player::GetShoots() const
{
        return shoots;
}

void Player::NrBallsInc()
{
        nrBalls++;
}

void Player::NrBallsZero()
{
        nrBalls=0;
}

int Player::GetNrBalls() const
{
        return nrBalls;
}

void Player::SetBallTeam(const Ball::BallTeamType &team)
{
        ballTeam=team;
}

Ball::BallTeamType Player::GetBallTeam() const
{
        return ballTeam;
}

char *Player::GetTeamStr() const
{
        static char *str1="Undetermined";
        static char *str2="Solids";
        static char *str3="Stripes";

        if(ballTeam==Ball::UNDETERMINED)
                return str1;
        else if(ballTeam==Ball::SOLIDS)
                return str2;
        else
                return str3;


}

void Player::SetNext(Player *n)
{
        next=n;
}

Player *Player::GetNext()
{
        return next;
}
