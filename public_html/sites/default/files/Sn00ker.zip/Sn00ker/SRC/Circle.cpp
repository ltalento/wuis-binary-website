//---------------------------------------------------------------------------
#pragma hdrstop
#include "Circle.h"
#include "Line.h"
#include "Triangle.h"
#pragma package(smart_init)
double Circle::PI=3.14159265358979323846;
//---------------------------------------------------------------------------
Circle::Circle():
   radius(0),
   center()
{
}
Circle::Circle(const Point2D& center, double radius):
   center(center),
   radius(radius)
{
}
Circle::Circle(const Circle& other):
   center(other.center),
   radius(other.radius)
{
}
Circle::~Circle()
{
}
//---------------------------------------------------------------------------
Point2D Circle::Center() const
{
   return center;
}
double Circle::Radius() const
{
   return radius;
}
void Circle::SetCenter(const Point2D& newCenter)
{
   center = newCenter;
}
void Circle::SetRadius(double newRadius)
{
   radius = newRadius;
}
void Circle::Set(const Point2D& newCenter,double newRadius)
{
   center = newCenter;
   radius = newRadius;
}
//---------------------------------------------------------------------------
void Circle::Translate(double dx, double dy)
{
  center.Translate(dx,dy);
}
void Circle::Scale(double sx, double sy)
{
  center.Scale(sx,sy);
}
void Circle::Rotate(double ang)
{
   center.Rotate(ang);
}
//---------------------------------------------------------------------------
void Circle::Write(ostream& output) const
{
   center.Write(output);
   output <<" " << radius;
}
void Circle::WriteLine(ostream& output) const
{
   Write(output);
   output << endl;
}
void Circle::Read(istream& input)
{
  center.Read(input);
  input >> radius;
}
//---------------------------------------------------------------------------
double Circle::Area() const
{
   return PI * radius * radius;
}
double Circle::Perimeter() const
{
   return PI * 2 * radius;
}
//---------------------------------------------------------------------------
bool Circle::Contains (const Point2D& p)
{
   return center.DistanceTo(p) <= radius;
}
bool Circle::Contains (const Circle& c)
{
 return center.DistanceTo(c.Center()) <= radius + c.Radius();
}
bool Circle::Intersect (const Circle& c)
{
 return center.DistanceTo(c.Center()) <= radius + c.Radius();
}
//---------------------------------------------------------------------------
Point2D Circle::TopMost() const
{
  Point2D p(center);
  p.Translate(0,radius);
  return p;
}
Point2D Circle::BottomMost() const
{
  Point2D p(center);
  p.Translate(0,-radius);
  return p;
}
Point2D Circle::LeftMost() const
{
  Point2D p(center);
  p.Translate(-radius,0);
  return p;
}
Point2D Circle::RightMost() const
{
  Point2D p(center);
  p.Translate(radius,0);
  return p;
}
//---------------------------------------------------------------------------
Point2D Circle::PointAt(double ang ) const
{
  Point2D p= RightMost();
  p.RotateAround(ang,center);
  return p;
}
void Circle::Plot(int numPoints,ostream& output) const
{
   double ang= M_PI * 2.0 / numPoints;
   for(int i=0; i< numPoints; i++)
     PointAt( ang * i).WriteLine(output);
}
//---------------------------------------------------------------------------
double Circle::Angle(const Point2D& p ) const
{
  return (Line(p,center)).Angle();
}

//---------------------------------------------------------------------------
double Circle::AbsAngle(double ang)
{
  while(ang < 0.0 )
    ang += 2*PI;
  while( ang > 2* PI)
    ang -= 2*PI;
 return ang;
}
double  Circle::SectorArea(double ang) const
{
  ang= AbsAngle(ang);
  return (PI * radius * radius * ang)/(2*PI);
}
double  Circle::SegmentArea(double ang) const
{
   Point2D p=RightMost();
   p.Rotate(ang);
   Triangle t(center,p,RightMost());
   return t.Area();
}

double  Circle::ArcLenght(double ang) const
{
  ang= AbsAngle(ang);
  return radius * ang;
}

double  Circle::ChordLenght(double ang) const
{
   Point2D p=RightMost();
   p.Rotate(ang);
   return p.DistanceTo(RightMost());
}
//---------------------------------------------------------------------------

bool Circle::Touch(const Line &ln) const
{
        if( (ln.DistanceTo( center )) <= radius )

                return true;
        return false;
}
////////////////////////////////////////
