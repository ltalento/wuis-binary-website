//---------------------------------------------------------------------------

#ifndef CircleH
#define CircleH
//--------------------------------------------------------------------------
#include "Point2D.h"
class Circle: public Figure 
{
   private:
       Point2D center;
       double radius;
   public:
       Circle();
       Circle(const Point2D& center, double radius);
       Circle(const Circle& other);
       virtual ~Circle();

       virtual Point2D Center() const;
       virtual double Radius() const;
       virtual void SetCenter(const Point2D& newCenter);
       virtual void SetRadius(double newRadius);
       virtual void Set(const Point2D& newCenter,double newRadius);

       virtual void Translate(double dx, double dy);
       virtual void Scale(double s1, double s2);
       virtual void Rotate(double ang);

       virtual void Write(ostream& output = cout) const;
       virtual void WriteLine(ostream& output = cout) const;
       virtual void Read(istream& input = cin);

       virtual double Area() const;
       virtual double Perimeter() const;

       virtual bool Contains (const Point2D& p);
       virtual bool Contains (const Circle& c);
       virtual bool Intersect (const Circle& c);

       virtual Point2D RightMost() const;
       virtual Point2D LeftMost() const;
       virtual Point2D TopMost() const;
       virtual Point2D BottomMost() const;
       virtual Point2D PointAt(double ang) const;
       virtual void Plot(int numPoints,ostream& output = cout) const;
       virtual double Angle(const Point2D& p) const;

       virtual double SectorArea(double ang) const;
       virtual double SegmentArea(double ang) const;
       virtual double ArcLenght(double ang) const;
       virtual double ChordLenght(double ang) const;

       virtual bool Touch(const Line &ln) const;

    private:
       static double PI;
       static double AbsAngle(double ang);

};
#endif
