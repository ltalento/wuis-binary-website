#ifndef TriangleH
#define TriangleH
//---------------------------------------------------------------------------
#include "Point2D.h"
#include "Polygons.h"
class Triangle: public Polygons {
   private:

   public:
       Triangle();
       Triangle(const Point2D& p0,const Point2D& p1,const Point2D& p2);
       Triangle(const Triangle& other);
       virtual ~Triangle();

       virtual double Base() const;
       virtual double Height() const;
       virtual double Area() const;
};

//---------------------------------------------------------------------------
#endif
