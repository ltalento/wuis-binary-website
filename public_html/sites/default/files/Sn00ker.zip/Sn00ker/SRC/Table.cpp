//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Table.h"

//---------------------------------------------------------------------------

#pragma package(smart_init)

Table::Table()
{
        pockets[0].SetCenter(Point2D(-13, 6.5));//top left
        pockets[1].SetCenter(Point2D(  0, 6.5));//top center
        pockets[2].SetCenter(Point2D( 13, 6.5));//top right
        pockets[3].SetCenter(Point2D(-13,-6.5));//bottom left
        pockets[4].SetCenter(Point2D(  0,-6.5));//bottom center
        pockets[5].SetCenter(Point2D( 13,-6.5));//bottom right
        for(int i=0; i<6; i++)
            pockets[i].SetRadius(1);

        limitis[0].Set(Point2D(-13, 6.5),Point2D(13, 6.5));//top
        limitis[1].Set(Point2D(-13,-6.5),Point2D(13,-6.5));//bottom
        limitis[2].Set(Point2D(-13,6.5),Point2D(-13,-6.5));//left
        limitis[3].Set(Point2D( 13,6.5),Point2D( 13, -6.5));//right

        /*limitis[4];
        limitis[5];*/

        texture=0;
        //textures[1]=0;
}

Table::~Table()
{

}

Circle&  Table::GetPockets(const int i) //const
{
        return pockets[i];
}

Line&    Table::GetLimitis(const int i)// const
{
       return limitis[i];
}

GLuint* Table::GetTexture() //const
{
       return &texture;
}

#define drawOneLine(x1,y1,x2,y2) glBegin(GL_LINES); \
glVertex3f ((x1),(y1),0); glVertex3f ((x2),(y2),0); glEnd();
void drawCirle(float x, float y)
{
        GLint circle_points = 10;
        glPushMatrix();
        glTranslatef(x,y,0);
        glBegin(GL_LINE_LOOP);
        for (int i = 0; i < circle_points; i++) {
                float angle = 2*(3.1415)*i/circle_points;
                glVertex3f(cos(angle), sin(angle),0);
        }
        glEnd();
        glPopMatrix();
}

void Table::Draw() const
{
        glPushMatrix();
        /*glDisable(GL_LIGHTING);
        glColor3ub(255, 0, 0);
        for (int i=0; i<6; i++) {
          drawCirle(pockets[i].Center().X(),pockets[i].Center().Y());
        }
        glColor3ub(255, 255, 255);
        drawOneLine(-13, 6.5, 13, 6.5);//top
        drawOneLine(-13,-6.5, 13,-6.5);//bottom
        drawOneLine(-13, 6.5,-13,-6.5);//left
        drawOneLine( 13, 6.5, 13,-6.5);//right
         glEnable(GL_LIGHTING);
                 */
         glBindTexture(GL_TEXTURE_2D, texture );
         glBegin(GL_QUADS);
	        glNormal3f(0, 0, 1);
                glTexCoord2f(0, 1);
	        glVertex3f(14.5,8,0);
	        glTexCoord2f(0, 0);
	        glVertex3f(-14.5,8,0);
	        glTexCoord2f(1, 0);
	        glVertex3f(-14.5,-8,0);
	        glTexCoord2f(1, 1);
	        glVertex3f(14.5,-8,0);
        glEnd();
        glPopMatrix();
}
