//---------------------------------------------------------------------------

#ifndef BallH
#define BallH
//---------------------------------------------------------------------------
#include <gl\gl.h>
#include <gl\glu.h>

#include "Circle.h"
#include "Vector2D.h"
#include "Line.h"

class Ball: public Circle
{
public:
	enum BallTeamType{ UNDETERMINED, SOLIDS, STRIPES};

private:
        static int BallCont;
	GLuint texture;
	Vector2D velocity;
	Point2D lastPosition;
	int nr;
	bool inGame;
	BallTeamType team;

        int ang_r;
        Vector2D vector_r;
public:
        Ball();
        virtual ~Ball();

        virtual void PutInGame(const Point2D &p);
        virtual void RePutInGame();
        virtual void RemFromGame();
        virtual void SavePosition();

        virtual bool IsInGame() const;
        virtual int  GetNR() const;
        virtual BallTeamType GetTeam() const;

        virtual void SetVelocity(const Vector2D &v);
        virtual Vector2D GetVelocity() const;
        virtual GLuint* GetTexture();

	virtual void Move();
	virtual void SlowDown(const double friction);
	virtual bool Touch(const Ball &o) const;

	virtual void Shock(const Line &l);
	virtual void Shock(Ball &o);
        virtual bool FallInPocket(const Circle &p);


	virtual void Draw() const;
};

#endif
