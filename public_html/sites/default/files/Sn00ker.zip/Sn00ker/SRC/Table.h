//---------------------------------------------------------------------------

#ifndef TableH
#define TableH
//---------------------------------------------------------------------------
#include <gl/gl.h> 
#include <gl/glu.h>
#include "Circle.h"
#include "Line.h"

class Table
{
private:
	Circle pockets[6];
	Line   limitis[4];
	GLuint texture;

public:
        Table();
        virtual ~Table();

       //virtual void    Init();
	virtual Circle& GetPockets(const int i)/* const*/;
	virtual Line&   GetLimitis(const int i) /*const*/;
        virtual GLuint* GetTexture() /*const*/;

	virtual void    Draw() const;
};

#endif
