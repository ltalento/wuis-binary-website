//---------------------------------------------------------------------------

#ifndef Vector2DH
#define Vector2DH
//---------------------------------------------------------------------------
#include "Point2D.h"

class Vector2D: public Point2D
{
public:
        Vector2D();
        Vector2D(double x, double y);
        Vector2D(const Vector2D& other);
        virtual ~Vector2D();
        virtual void Set(const Point2D &a, const Point2D &b);
        virtual void Normalize();
};

#endif
