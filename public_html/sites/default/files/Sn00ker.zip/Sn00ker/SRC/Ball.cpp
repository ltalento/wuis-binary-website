//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Ball.h"

//---------------------------------------------------------------------------

#pragma package(smart_init)

/*
GLuint texture;
	Vector2D velocity;
	Point2D lastPositon;
	int nr;
	bool inGame;
	BallTeamType team;
*/

int Ball::BallCont=0;

Ball::Ball(): Circle(Point2D(),0.45), ang_r(0)
{
        nr=BallCont;
        switch(BallCont)
        {
         case  1:
         case  2:
         case  3:
         case  4:
         case  5:
         case  6:
         case  7: team = SOLIDS;
                  break;
         case  9:
         case 10:
         case 11:
         case 12:
         case 13:
         case 14:
         case 15: team = STRIPES;
                  break;
         case  0:
         case  8:
         default: team = UNDETERMINED;
                  break;
        }

        BallCont++;
}

Ball::~Ball()
{

}

void Ball::PutInGame(const Point2D &p)
{
        inGame=true;
        SetCenter(p);
        velocity.Point2D::Set(0,0);
}

void Ball::RePutInGame()
{
        inGame=true;
        SetCenter(lastPosition);
        velocity.Point2D::Set(0,0);
}

void Ball::RemFromGame()
{
        inGame=false;
        //SetCenter(lastPositon);
        velocity.Point2D::Set(0,0);
}
void Ball::SavePosition()
{
     lastPosition=Center();
}

bool Ball::IsInGame() const
{
        return inGame;
}
int  Ball::GetNR() const
{
        return nr;
}

Ball::BallTeamType Ball::GetTeam() const
{
        return team;
}


void Ball::SetVelocity(const Vector2D &v)
{
        velocity.Point2D::Set(v.X(),v.Y());
}

Vector2D Ball::GetVelocity() const
{
        return velocity;
}

GLuint* Ball::GetTexture()
{
        return &texture;
}

void Ball::Move()
{       double vm = velocity.Modulus();
        if (vm>0.01){
                ang_r+=vm/Radius()*57.29; //w=v/r =)
                vector_r = velocity;
                vector_r.Rotate(1.57079); //PI/2
                vector_r.Normalize();
        }
        //lastPositon=Center();
        Translate(velocity.X(),velocity.Y());
        SlowDown(0.99);
}

void Ball::SlowDown(const double friction)
{
        velocity.Scale(friction,friction);
        if( velocity.Modulus() < 0.01)
                velocity = Vector2D();
}

bool Ball::Touch(const Ball &o) const
{
        return Center().DistanceTo(o.Center()) <= Radius()+ 0.001 + o.Radius();
}

void Ball::Shock(const Line &l)
{
        if( this->Circle::Touch(l) ){
                Vector2D tmp(velocity);
                tmp.Scale(-1,-1);
                double angle= l.Angle();
                velocity.Rotate(-angle);
                velocity.Scale(1,-1);
                velocity.Rotate(angle);
                while(this->Circle::Touch(l) /*&& tmp.Modulus()!=0*/ )
                        Translate(tmp.X()/4,tmp.Y()/4);
        }

}

void Ball::Shock(Ball &o)
{

        if( this->Touch(o) ) {
                Vector2D tmp(velocity);
                tmp.Scale(-1,-1);
                Line betwenBalls(Center(), o.Center());
                double ang=betwenBalls.Angle();
                Vector2D f1 = velocity;
                Vector2D f2 = o.velocity;
                f1.Rotate(-ang);
                f2.Rotate(-ang);
                if( cos(ang) > 0.01)
                {
                velocity.Point2D::Set(f2.X(),f1.Y());
                o.velocity.Point2D::Set(f1.X(),f2.Y());
                }
                else
                {
                 velocity.Point2D::Set(f1.X(),f2.Y());
                 o.velocity.Point2D::Set(f2.X(),f1.Y());
                }
                velocity.Rotate(ang);
                o.velocity.Rotate(ang);
                while(this->Touch(o) && tmp.Modulus()!=0 )
                    {
                        Translate(tmp.X()/4,tmp.Y()/4);
                        //o.Translate(o.velocity.X(),o.velocity.Y());
                     }
        }
}

bool Ball::FallInPocket(const Circle &c)
{
        if(Center().DistanceTo(c.Center()) <= c.Radius())
        {
         RemFromGame();
         return true;
        }

        return false;
}
void drawCirle2()
{
        GLint circle_points = 10;
        glPushMatrix();
        //glTranslatef(x,y,0);
        glBegin(GL_LINE_LOOP);
        for (int i = 0; i < circle_points; i++) {
                float angle = 2*(3.1415)*i/circle_points;
                glVertex3f(cos(angle)*0.45, sin(angle)*0.45,0);
        }
        glEnd();
        glPopMatrix();
}

void Ball::Draw() const
{
        if(inGame)
        {
                glBindTexture(GL_TEXTURE_2D, texture );
                glColor3ub(255, 255, 255);
                glPushMatrix();
                        glTranslatef( Center().X() , Center().Y() ,Radius());
                       // drawCirle2();
                        glRotatef(ang_r%360,vector_r.X() ,vector_r.Y() ,0);
                        glPushMatrix();
                        glRotatef(90 ,1 ,0 ,0);
                        glRotatef(180 ,0 ,0 ,1);
                        GLUquadricObj *pObj = gluNewQuadric();
                        gluQuadricTexture(pObj, true);
                        gluQuadricDrawStyle(pObj, GLU_FILL);
                        gluSphere(pObj, Radius() , 10, 10);
                        gluDeleteQuadric(pObj);
                        glPopMatrix();
                glPopMatrix();
        }
}
