//---------------------------------------------------------------------------

#pragma hdrstop

#include "Polygons.h"
#include "Triangle.h"
#include "Line.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)


Polygons::Polygons():
  count(3),
  vertices(new Point2D[3])
{
}

Polygons::Polygons(int count):
  count(count),
  vertices(new Point2D[count])
{
  Point2D p(1.0, 0.0);
  for (int i = 0; i < count; i++)
    (vertices[i] = p).Rotate(i * 2 * 3.1415926535 / count);
}

Polygons::Polygons(int count, const Point2D points[]):
  count(count),
  vertices(new Point2D[count])
{
  for (int i = 0; i < count; i++)
    vertices[i] = points[i];
}

Polygons::Polygons(int count, const double x[], const double y[]):
  count(count),
  vertices(new Point2D[count])
{
  for (int i = 0; i < count; i++)
    vertices[i] = Point2D(x[i], y[i]);
}

Polygons::Polygons(const Polygons& other):
  count(other.count),
  vertices(new Point2D[other.count])
{
  for (int i = 0; i < other.count; i++)
    vertices[i] = other.vertices[i];
}

//---------------------------------------------------------------------------
Polygons::~Polygons()
{
  delete [] vertices;
}
//---------------------------------------------------------------------------
int Polygons::Count() const
{
  return count;
}

const Point2D& Polygons::Vertex(int x) const
{
  return vertices[x];
}

 Point2D& Polygons::operator [](int x) 
{
  return vertices[x];
}

void Polygons::Set(const Point2D& p, int x)
{
  vertices[x] = p;
}
//---------------------------------------------------------------------------
void Polygons::Scale(double fx, double fy)
{
  for (int i = 0; i < count; i++)
    vertices[i].Scale(fx, fy);
}

void Polygons::Translate(double dx, double dy)
{
  for (int i = 0; i < count; i++)
    vertices[i].Translate(dx, dy);
}

void Polygons::Rotate(double angle)
{
  for (int i = 0; i < count; i++)
    vertices[i].Rotate(angle);
}
//---------------------------------------------------------------------------
void Polygons::Write(ostream& output) const
{
  output << count;
  for (int i = 0; i < count; i++)
  {
    output << " ";
    vertices[i].Write(output);
  }
}

void Polygons::WriteLine(ostream& output) const
{
  Write(output);
  output << endl;
}
//-------------------------------------------------------------------------

void Polygons::Copy(const Polygons& other)
{
  if (this != &other)
  {
    delete [] vertices;
    vertices = new Point2D[other.count];
    count = other.count;
    for (int i = 0; i < other.count; i++)
      vertices[i] = other.vertices[i];
  }
}


Polygons& Polygons::operator = (const Polygons& other)
{
  Copy(other);
  return *this;
}
//-------------------------------------------------------------------------

bool Polygons::Convex() const
{
  for (int i = 1; i < count; i++)
  {
    if (vertices[i] == vertices[(i+1)%count])
      return false;
    Line side(vertices[i], vertices[(i+1)%count]);
    if (!side.SameSide(vertices[(i-1)%count], vertices[(i+2)%count]))
        return false;
   }
  return true;
}
