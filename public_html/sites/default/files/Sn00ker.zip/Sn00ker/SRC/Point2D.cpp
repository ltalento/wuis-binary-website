#pragma hdrstop
#pragma package(smart_init)
#include "Point2D.h"
#include <math.h>
Point2D::Point2D():
  x(0),
  y(0)
{
//   cout <<"Point2D - construtor por Defeito\n";
}

Point2D::Point2D(double x, double y):
  x(x),
  y(y)
{
//   cout <<"Point2D - construtor com par�metros\n";
}

Point2D::Point2D(const Point2D& other):
  x(other.x),
  y(other.y)
{
//   cout <<"Point2D - construtor c�pia\n";
}
Point2D::~Point2D()
{
//   cout <<"Point2D - Destructor\n";
}

//-------------------------------------------------------
double Point2D::X() const
{
  return x;
}

double Point2D::Y() const
{
  return y;
}

void Point2D::SetX(double x)
{
  this->x = x;
}

void Point2D::SetY(double y)
{
  this->y = y;
}

void Point2D::Set(double x, double y)
{
  this->x = x;
  this->y = y;
}

//-------------------------------------------------------
void Point2D::Translate(double dx, double dy)
{
  x+=dx;
  y+=dy;
}
void Point2D::Scale(double sx, double sy)
{
 x*=sx;
 y*=sy;
}

void Point2D::Rotate(double angle)
{
  double x0 = x;
  double y0 = y;
  x = x0 * cos(angle) - y0 * sin(angle);
  y = x0 * sin(angle) + y0 * cos(angle);

}

double Point2D::DistanceTo(const Point2D& other)const
{
  return sqrt( pow( x- other.x , 2.0) + pow(y-other.y,2.0));
}

//------------------------------------------------------
double Point2D::Modulus() const
{
  return sqrt(x*x + y*y);
}

double Point2D::Angle() const
{
  return atan2(y, x);
}

//------------------------------------------------------
void Point2D::Write(ostream& output) const
{
  output << x << " " << y;
}

void Point2D::WriteLine(ostream& output) const
{
  Write(output);
  output << std::endl;
}

void Point2D::Read(istream& input)
{
  input >> x >> y;
}

//---------------------------------------------------------------
bool Point2D::Equal(const Point2D& other) const
{
  return x == other.x && y == other.y;
}

bool Point2D::operator ==(const Point2D& other) const
{
  return x == other.x && y == other.y;
}

bool Point2D::operator !=(const Point2D& other) const
{
  return ! (*this == other);
  //return ! operator == (other);
}

