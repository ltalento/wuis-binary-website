//---------------------------------------------------------------------------

#ifndef LineH
#define LineH
#include "Point2D.h"
//---------------------------------------------------------------------------
class Line:public Figure {
   private:
       double a;
       double b;
       double c;
       // invariant a != 0.0 || b != 0.0;
   public:
       Line();
       Line(const Point2D& p1, const Point2D& p2);  // pre p1 != p2;
       Line(const Point2D& p, double angle);
       Line(const Line& other);
       Line(double a, double b, double c);  // pre a != 0.0 || b != 0.0;
       virtual ~Line();

       virtual void Set(const Point2D& p1, const Point2D& p2);
       
       virtual bool operator == (const Line &other) const;
       virtual bool operator != (const Line &other) const;

       virtual double Angle() const;
       virtual double X0() const; // pre !Horizontal();
       virtual double Y0() const; // pre !Vertical();

       virtual bool Vertical() const;
       virtual bool Horizontal() const;

       virtual bool Has(const Point2D& p) const;
       virtual bool Between(const Point2D& p1, const Point2D& p2) const;
       virtual bool SameSide(const Point2D& p1, const Point2D& p2) const;

       virtual bool IsParallel(const Line& other) const;
       virtual Point2D Intersection(const Line& other) const; // pre !IsParallel(other);

       virtual Line Parallel(const Point2D& p) const;
       virtual Line Perpendicular(const Point2D& p) const;
       virtual double DistanceTo(const Point2D& p) const;

       virtual void Scale(double fx, double fy);  // pre fx != 0.0 || fy != 0.0;
       virtual void Rotate(double angle);
       virtual void Translate(double dx, double dy);

       virtual void Write(ostream& output = cout) const;
       virtual void WriteLine(ostream& output = cout) const;
   private: // functions
       virtual double Value(const Point2D& p) const;
};
#endif
