//---------------------------------------------------------------------------

#pragma hdrstop

#include "Triangle.h"
#include "Line.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------
Triangle::Triangle():
  Polygons(3)
{
  cout << "\nContrutor Triangle - Default ";
  Point2D origin;
  Set(origin, 0);
  Set(origin, 1);
  Set(origin, 2);
}
//---------------------------------------------------------------------------
Triangle::Triangle(const Point2D& p0,const Point2D& p1,const Point2D& p2):
  Polygons(3)
{
  cout << "\nContrutor Triangle - Parameters ";
  Set(p0, 0);
  Set(p1, 1);
  Set(p2, 2);
}
//---------------------------------------------------------------------------
Triangle::Triangle(const Triangle& other):
  Polygons(other)
{
  cout << "\nContrutor Triangle - Copy ";
}
//---------------------------------------------------------------------------

Triangle::~Triangle()
{
   cout << "\nDestructor Triangle ";
}

//---------------------------------------------------------------------------
double Triangle::Base() const
{
  return Vertex(0).DistanceTo(Vertex(1));
}
//---------------------------------------------------------------------------
double Triangle::Height() const
{
  const Point2D& p0 = Vertex(0);
  const Point2D& p1 = Vertex(1);
  const Point2D& p2 = Vertex(2);
  return Line(p0, p1).DistanceTo(p2);
}
//---------------------------------------------------------------------------
double Triangle::Area() const
{
  return Base() * Height() / 2;
}

