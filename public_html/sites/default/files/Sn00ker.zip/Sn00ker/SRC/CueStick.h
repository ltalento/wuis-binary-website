//---------------------------------------------------------------------------

#ifndef CueStickH
#define CueStickH
//---------------------------------------------------------------------------
#include "Ball.h"

//#define NRTRI  24
//#define NRVERT 14

class CueStick
{
private:
        bool visible;
        int dir_ang;
        Vector2D dir;
        GLuint texture;
        Ball *target;
        int power;

        //static int triangles[NRTRI][3];
        //static float vertex[NRVERT][5];
public:
        CueStick();
        virtual ~CueStick();
        //
        virtual void SetPower(const int p);
        virtual void SetVisible(const bool v);
        virtual void SetDirection(const Point2D &p);
        virtual void SetTarget(Ball *t);
        //
        virtual bool IsVisible() const;
        virtual int GetDirection() const;
        virtual Vector2D GetVectDirection() const;
        virtual GLuint*  GetTexture();
        //
        virtual void Draw();
};

#endif
