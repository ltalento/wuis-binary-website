//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include <algorithm>

#include "frmGame.h"
#include "frmAbout.h"

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TfrmMain *frmMain;


#define HALFGLSCENE_W 15
#define HALFGLSCENE_H  9.18

//---------------------------------------------------------------------------
__fastcall TfrmMain::TfrmMain(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TfrmMain::FormClose(TObject *Sender, TCloseAction &Action)
{
        delete[] myPlayer;
        delete myTable;
        delete myCueStick;
        delete[] myBall;
}
//---------------------------------------------------------------------------

void __fastcall TfrmMain::FormCreate(TObject *Sender)
{
        if(!glCreate())
        {
         MessageBox(NULL, "Can't Create A GL Device Context", "Error", MB_OK);
         Close();
        }

        glInit(Scene->Width, Scene->Height);

        myPlayer = new Player[2];
        myTable = new Table;
        myCueStick = new CueStick;
        myCueStick->SetPower(PowerBar->Position);
        myBall = new Ball[16];
        for(int i=0;i<16;i++)
	{
                char tmp[20];
		sprintf(tmp,"textures/ball%i.bmp",i);
                glLoadTexture(tmp,myBall[i].GetTexture());
        }

        glLoadTexture("textures/CueStick.BMP",myCueStick->GetTexture());
        glLoadTexture("textures/table.BMP",myTable->GetTexture());

        myPlayer[0].SetIndex(0);
        myPlayer[1].SetIndex(1);

        myPlayer[0].SetNext(&myPlayer[1]);
        myPlayer[1].SetNext(&myPlayer[0]);

        //Scene->Cursor  = crNone;
        myCueStick->SetTarget(&myBall[0]);


       // ImageList->GetBitmap(0,img7Play1->Picture->Bitmap);
        //img7Play1->Picture->Bitmap=NULL;


        GameRestart();


}
//---------------------------------------------------------------------------

void __fastcall TfrmMain::FormDestroy(TObject *Sender)
{
        glShutDwn();
}
//---------------------------------------------------------------------------
void __fastcall TfrmMain::GameRestart()
{
        Point2D Pos[14]= {
                Point2D(-4.5, 0),Point2D(-5.5, 0.5),Point2D(-5.5, -0.5),
                Point2D(-6.5, 1),Point2D(-6.5, -1),Point2D(-7.5, 1.5),
                Point2D(-7.5, 0.5),Point2D(-7.5,-0.5),Point2D(-7.5,-1.5),
                Point2D(-8.5, 2),Point2D(-8.5, 1),Point2D(-8.5, 0),
                Point2D(-8.5,-1),Point2D(-8.5,-2)};

        int PosIndx[14]={0,1,2,3,4,5,6,7,8,9,10,11,12,13};
        random_shuffle(PosIndx, PosIndx + 14);


        myBall[0].PutInGame(Point2D( 6.5, 0));
        myBall[8].PutInGame(Point2D(-6.5, 0));

        for(int i=1; i<8; i++)
            myBall[i].PutInGame(Pos[PosIndx[i-1]]);

        for(int i=9; i<16; i++)
        {
            int j=PosIndx[(i-9)+7];
            myBall[i].PutInGame(Pos[j]);
        }


        myPlayer[0].NrBallsZero();
        myPlayer[1].NrBallsZero();

        myPlayer[0].ShootsZero();
        myPlayer[0].ShootsInc();
        myPlayer[1].ShootsZero();

        myCueStick->SetDirection(Point2D(-1,0));
        myCueStick->SetVisible(true);

        CurrPlayer=0;

        myPlayer[0].SetBallTeam(myBall[0].GetTeam());
        myPlayer[1].SetBallTeam(myBall[0].GetTeam());

        img1Play1->Picture->Bitmap=NULL;
        img2Play1->Picture->Bitmap=NULL;
        img3Play1->Picture->Bitmap=NULL;
        img4Play1->Picture->Bitmap=NULL;
        img5Play1->Picture->Bitmap=NULL;
        img6Play1->Picture->Bitmap=NULL;
        img7Play1->Picture->Bitmap=NULL;
        img1Play2->Picture->Bitmap=NULL;
        img2Play2->Picture->Bitmap=NULL;
        img3Play2->Picture->Bitmap=NULL;
        img4Play2->Picture->Bitmap=NULL;
        img5Play2->Picture->Bitmap=NULL;
        img6Play2->Picture->Bitmap=NULL;
        img7Play2->Picture->Bitmap=NULL;

        UpdateLabels();
        
        mouseDown=false;
        GameState=WAIT;

        if(CurrPlayer==0)
                PlayersPage->ActivePage = TabSheet1;
        else
                PlayersPage->ActivePage = TabSheet2;
}
//---------------------------------------------------------------------------
void __fastcall TfrmMain::Action()
{
        //move as bolas
        for(int i=0; i<16; i++)
        {


                for(int p=0;p<6;p++)
                        if(myBall[i].IsInGame())
                        {
                           if(myBall[i].FallInPocket(myTable->GetPockets(p)))
                                BallInPocket(i);
                        }
                if(myBall[i].IsInGame()){
                for(int l=0;l<4;l++)
                        myBall[i].Shock(myTable->GetLimitis(l));

                for(int o=i+1;o<16;o++)
                       if(i!=o)myBall[i].Shock(myBall[o]);
                }
               myBall[i].Move();
        }
        bool cut=false;
        for(int i=0; i<16; i++){
             if(myBall[i].GetVelocity().Modulus()!=0){
                cut=false;
                break;
             }
         cut=true;
        }
        if(cut)CutAction();
}
//---------------------------------------------------------------------------
void __fastcall TfrmMain::CutAction()
{
        GameState=WAIT;
        if( !myBall[0].IsInGame() ){
                myPlayer[CurrPlayer].ShootsZero();
                myBall[0].RePutInGame();
        }

        if( !myBall[8].IsInGame() ){
                if(myPlayer[CurrPlayer].GetNrBalls()==7){
                 if(CurrPlayer==0)MessageBox(NULL, "Player 1 win!!", "", MB_OK);
                 else MessageBox(NULL, "Player 2 win!!", "", MB_OK);
                }
                else{
                 if(CurrPlayer==0)MessageBox(NULL, "Player 2 win!!", "", MB_OK);
                 else MessageBox(NULL, "Player 1 win!!", "", MB_OK);
                }
                GameRestart();
        }



        if(myPlayer[CurrPlayer].GetShoots()==0){

           CurrPlayer = myPlayer[CurrPlayer].GetNext()->GetIndex();
           myPlayer[CurrPlayer].ShootsInc(); 
        }

        UpdateLabels();
        //GameState=WAIT;
        myCueStick->SetVisible(true);
        if(CurrPlayer==0)
                PlayersPage->ActivePage = TabSheet1;
        else
                PlayersPage->ActivePage = TabSheet2;
}
//---------------------------------------------------------------------------
void __fastcall TfrmMain::BallInPocket(int b)
{

        if(b!=0 && b!=8)
        {
                if(myPlayer[CurrPlayer].GetBallTeam()==Ball::UNDETERMINED ){
                        myPlayer[CurrPlayer].SetBallTeam(myBall[b].GetTeam());
                        myPlayer[CurrPlayer].SetBallTeam(myBall[b].GetTeam());

                        myPlayer[CurrPlayer].ShootsInc();
                        myPlayer[CurrPlayer].NrBallsInc();
                        
                        Ball::BallTeamType tmp;
                        if(myBall[b].GetTeam()==Ball::SOLIDS) tmp=Ball::STRIPES;
                        else tmp=Ball::SOLIDS;
                        myPlayer[CurrPlayer].GetNext()->SetBallTeam(tmp);
                }
                else{
                       if(myPlayer[CurrPlayer].GetBallTeam()==myBall[b].GetTeam()){
                                myPlayer[CurrPlayer].NrBallsInc();
                                myPlayer[CurrPlayer].ShootsInc();
                       }
                       else{
                                myPlayer[CurrPlayer].ShootsZero();
                                myPlayer[CurrPlayer].GetNext()->NrBallsInc();
                       }
                }
                UpdatePainel(b);
        }

}
//---------------------------------------------------------------------------
void __fastcall TfrmMain::UpdatePainel(int b)
{
        int imgIndex;
        if(b<8) imgIndex=b-1;
        else imgIndex=b-2;

        if(myPlayer[0].GetBallTeam()==myBall[b].GetTeam()){
                switch(myPlayer[0].GetNrBalls())
                {
                 case 1:ImageList->GetBitmap(imgIndex,img1Play1->Picture->Bitmap);
                        break;
                 case 2:ImageList->GetBitmap(imgIndex,img2Play1->Picture->Bitmap);
                        break;
                 case 3:ImageList->GetBitmap(imgIndex,img3Play1->Picture->Bitmap);
                        break;
                 case 4:ImageList->GetBitmap(imgIndex,img4Play1->Picture->Bitmap);
                        break;
                 case 5:ImageList->GetBitmap(imgIndex,img5Play1->Picture->Bitmap);
                        break;
                 case 6:ImageList->GetBitmap(imgIndex,img6Play1->Picture->Bitmap);
                        break;
                 case 7:ImageList->GetBitmap(imgIndex,img7Play1->Picture->Bitmap);
                        break;
               }
        }
        else{
                switch(myPlayer[1].GetNrBalls())
                {
                 case 1:ImageList->GetBitmap(imgIndex,img1Play2->Picture->Bitmap);
                        break;
                 case 2:ImageList->GetBitmap(imgIndex,img2Play2->Picture->Bitmap);
                        break;
                 case 3:ImageList->GetBitmap(imgIndex,img3Play2->Picture->Bitmap);
                        break;
                 case 4:ImageList->GetBitmap(imgIndex,img4Play2->Picture->Bitmap);
                        break;
                 case 5:ImageList->GetBitmap(imgIndex,img5Play2->Picture->Bitmap);
                        break;
                 case 6:ImageList->GetBitmap(imgIndex,img6Play2->Picture->Bitmap);
                        break;
                 case 7:ImageList->GetBitmap(imgIndex,img7Play2->Picture->Bitmap);
                        break;
                }
        }
        UpdateLabels();

}
//---------------------------------------------------------------------------
void __fastcall TfrmMain::UpdateLabels()
{
        edtPlayer1Team->Text = myPlayer[0].GetTeamStr();
        edtPlayer2Team->Text = myPlayer[1].GetTeamStr();
        edtPlayer1Shoots->Text =  myPlayer[0].GetShoots();
        edtPlayer2Shoots->Text =  myPlayer[1].GetShoots();

}
//---------------------------------------------------------------------------
void __fastcall TfrmMain::TimerTimer(TObject *Sender)
{
        //Timer->Enabled=false;
        /*if(GameState==ACTION)
        {
                if(PowerBar->Position==1){
                myCueStick->SetVisible(false);
                Action();
                }else{
                PowerBar->Position--;//=PowerBar->Position-1;
                myCueStick->SetPower(PowerBar->Position);
                }
        }*/
        //draw scene =)
        glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
        glLoadIdentity();
        //gluLookAt(0, 0, 20,  0,0,0,  0,1,0);
//      myBall[0].Center().Y();
        myCueStick->Draw();
        myTable->Draw();
        for(int i=0; i<16; i++)
            myBall[i].Draw();

        SwapBuffers(gl_HDC);
        //Timer->Enabled=true;
}
//---------------------------------------------------------------------------

void __fastcall TfrmMain::RestartClick(TObject *Sender)
{
        GameRestart();
}
//---------------------------------------------------------------------------


void __fastcall TfrmMain::ExitClick(TObject *Sender)
{
        Close();
}
//---------------------------------------------------------------------------


void __fastcall TfrmMain::FastTimerTimer(TObject *Sender)
{
        if(GameState==ACTION)
        {
                if(PowerBar->Position==1){
                myCueStick->SetVisible(false);
                Action();
                }else{
                PowerBar->Position--;
                myCueStick->SetPower(PowerBar->Position);
                }
        }
}
//---------------------------------------------------------------------------

void __fastcall TfrmMain::SceneMouseUp(TObject *Sender,
      TMouseButton Button, TShiftState Shift, int X, int Y)
{
//
        mouseDown=false;
        if(GameState==WAIT){
                Vector2D tmp(myCueStick->GetVectDirection());
                tmp.Scale(0.044*PowerBar->Position,0.044*PowerBar->Position);
                myBall[0].SavePosition();
                myBall[0].SetVelocity(tmp);
                GameState=ACTION;
                myPlayer[CurrPlayer].ShootsDec();
                //update labels
                UpdateLabels();
        }

}
//---------------------------------------------------------------------------

void __fastcall TfrmMain::SceneMouseDown(TObject *Sender,
      TMouseButton Button, TShiftState Shift, int X, int Y)
{
       mouseDown=true;
       mouseOld_Y=Y;
}
//---------------------------------------------------------------------------

void __fastcall TfrmMain::SceneMouseMove(TObject *Sender,
      TShiftState Shift, int X, int Y)
{

if(GameState==WAIT)
{
        if(!mouseDown){
                //converte as coords..
                float x=X,y=Y;
                x-=(Scene->Width/2);
                y=(Scene->Height/2)-y;
                x=HALFGLSCENE_W*x/(Scene->Width/2);
                y=HALFGLSCENE_H*y/(Scene->Height/2);
                //------
                myCueStick->SetDirection(Point2D(x,y));
              }else
              {
                PowerBar->Position = (Y-mouseOld_Y)/10;
                myCueStick->SetPower(PowerBar->Position);
              }
}
}

//---------------------------------------------------------------------------
bool TfrmMain::glCreate()
{
        gl_HDC = GetDC(Scene->Handle);

        PIXELFORMATDESCRIPTOR pfd, *ppfd;
        int pixelformat;
        ppfd = &pfd;
        ppfd->nSize = sizeof(PIXELFORMATDESCRIPTOR);
        ppfd->nVersion = 1;
        ppfd->dwFlags = PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL |
                        PFD_DOUBLEBUFFER;
        ppfd->dwLayerMask = PFD_MAIN_PLANE;
        ppfd->iPixelType = PFD_TYPE_COLORINDEX;
        ppfd->cColorBits = 16;
        ppfd->cDepthBits = 8;
        ppfd->cAccumBits = 0;
        ppfd->cStencilBits = 0;

        if ( (pixelformat = ChoosePixelFormat(gl_HDC, ppfd)) == 0 )
            return false;//MessageBox(NULL, "ChoosePixelFormat failed", "Error", MB_OK);

        if (SetPixelFormat(gl_HDC, pixelformat, ppfd) == FALSE)
            return false;//MessageBox(NULL, "SetPixelFormat failed", "Error", MB_OK);

        gl_HRC = wglCreateContext(gl_HDC);
        if(gl_HRC==NULL)
                return false;
        if(wglMakeCurrent(gl_HDC, gl_HRC)== false)
                return false;
                
        return true;
}

void TfrmMain::glInit(float w, float h)
{
        glViewport( 0, 0, w, h);
        glMatrixMode( GL_PROJECTION );
        glLoadIdentity();
        //gluPerspective( 45.0, w/h, 1.0, 25.0 );
        glOrtho(-HALFGLSCENE_W,HALFGLSCENE_W,-HALFGLSCENE_H,HALFGLSCENE_H,-1,2);
        //glOrtho(-9,3,-3.67,3.67,-1,2);
        glMatrixMode( GL_MODELVIEW );

        glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
        glClearDepth( 1.0 );
        glEnable(GL_DEPTH_TEST);
        glEnable(GL_LIGHT0);
        glEnable(GL_LIGHTING);
        glEnable(GL_COLOR_MATERIAL);

        glEnable(GL_TEXTURE_2D);
}

void TfrmMain::glShutDwn()
{
        if (gl_HRC) wglDeleteContext(gl_HRC);
        if (gl_HDC) ReleaseDC(Scene->Handle, gl_HDC);
        wglMakeCurrent(NULL, NULL);
}

bool TfrmMain::glLoadTexture(const char *filename, GLuint *texture)
{
        Graphics::TBitmap* bitmap;
        bitmap = new Graphics::TBitmap;

        bitmap->LoadFromFile(filename);

        if(bitmap->Empty){
               delete bitmap;
               return false;
        }

        int w  = bitmap->Width;
        int h  = bitmap->Height;
        GLubyte *bits;
        bits = new GLubyte[w*h*4];

        //int m1[Z][Y][X];
        //int m2[X*Y*Z];
        //m1[z][y][x]=m2[z*(Y*X)+y*X+x];

        for(int i = 0; i < w; i++)
        {
            for(int j = 0; j < h; j++)
            {
                bits[i*(h*4)+j*4+0]= (GLbyte)GetRValue(bitmap->Canvas->Pixels[i][j]);
                bits[i*(h*4)+j*4+1]= (GLbyte)GetGValue(bitmap->Canvas->Pixels[i][j]);
                bits[i*(h*4)+j*4+2]= (GLbyte)GetBValue(bitmap->Canvas->Pixels[i][j]);
                bits[i*(h*4)+j*4+3]= (GLbyte)255;

            }
        }
        glPixelStorei(GL_UNPACK_ALIGNMENT, 4);
        glGenTextures(1, texture);
        glBindTexture(GL_TEXTURE_2D, *texture);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, bits);
        delete bits;
        bitmap->FreeImage();
        delete bitmap;

        return true;
}



void __fastcall TfrmMain::AboutClick(TObject *Sender)
{
///
        AboutBox->ShowModal();
}
//---------------------------------------------------------------------------

