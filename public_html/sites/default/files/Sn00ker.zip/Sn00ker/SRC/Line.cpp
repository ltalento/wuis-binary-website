//---------------------------------------------------------------------------

#pragma hdrstop

#include "Line.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
Line::Line():
  a(0.0),
  b(1.0),
  c(0.0)
{
}

Line::Line(const Point2D& p1, const Point2D& p2):
  a(p2.Y() - p1.Y()),
  b(p1.X() - p2.X()),
  c(p2.X()*p1.Y() - p2.Y() * p1.X())
{
}

Line::Line(const Point2D& p, double angle):
  a(sin(angle)),
  b(-cos(angle)),
  c(p.Y() * -b - p.X() * a)  // Attention: depends on initialization order!
{
}

Line::Line(const Line& other):
  a(other.a),
  b(other.b),
  c(other.c)
{
}

Line::Line(double a, double b, double c):
  a(a),
  b(b),
  c(c)
{
}

Line::~Line()
{
}

void Line::Set(const Point2D& p1, const Point2D& p2)
{
  a=p2.Y() - p1.Y();
  b=p1.X() - p2.X();
  c=p2.X()*p1.Y()-p2.Y()*p1.X();
}

bool Line::operator == (const Line &other) const
{
  return a*other.b == b*other.a &&
             a*other.c == c*other.a &&
             b*other.c == c*other.b;
}

bool Line::operator != (const Line &other) const
{
  return ! operator == (other);
}

double Line::Angle() const
{
  return b == 0.0 ? 3.1415926535 / 2 : atan(-a/b);
}

double Line::X0() const
{
  return -c / a;
}

double Line::Y0() const
{
  return -c / b;
}

bool Line::Vertical() const
{
  return b == 0.0;
}

bool Line::Horizontal() const
{
  return a == 0.0;
}

bool Line::Has(const Point2D& p) const
{
  return Value(p) == 0.0;
}

bool Line::Between(const Point2D& p1, const Point2D& p2) const
{
  return Value(p1) * Value(p2) <= 0.0;
}

bool Line::SameSide(const Point2D& p1, const Point2D& p2) const
{
  std::cout << "SameSide: " << Value(p1) << " " << Value(p2) << std::endl;
//  return (Value(p1) >= 0.0) == (Value(p2) >= 0.0);
  return Value(p1) * Value(p2) >= 0.0;
}

bool Line::IsParallel(const Line& other) const
{
  return a*other.b == b*other.a; 
}

Point2D Line::Intersection(const Line& other) const
{
  double x = (b * other.c - c * other.b) / (a * other.b - b * other.a);
  double y = (a * other.c - c * other.a) / (b * other.a - a * other.b);
  return Point2D(x, y);
}

Line Line::Parallel(const Point2D& p) const
{
  return Line(a, b, -(a * p.X() + b * p.Y()));
}

Line Line::Perpendicular(const Point2D& p) const
{
  return Line(-b, a, -(-b * p.X() + a * p.Y()));
}

double Line::DistanceTo(const Point2D& p) const
{
  return Intersection(Perpendicular(p)).DistanceTo(p);
}

void Line::Scale(double fx, double fy)
{
  a *= fy;
  b *= fx;
  c *= fx * fy;
}

void Line::Translate(double dx, double dy)
{
  c -= a * dx + b* dy;
}

void Line::Rotate(double angle)
{
  double a0 = a;
  double b0 = b;
  a = a0 * cos(angle) - b0 * sin(angle);
  b = a0 * sin(angle) + b0 * cos(angle);
}

void Line::Write(std::ostream& output) const
{
  output << a << " " << b << " " << c ;
}

void Line::WriteLine(std::ostream& output) const
{
  Write(output);
  output << endl;
}


double Line::Value(const Point2D& p) const
{
  return a * p.X() + b * p.Y() + c;
}
