//---------------------------------------------------------------------------
#ifndef PolygonsH
#define PolygonsH
#include "Point2D.h"
#include "Figure.h"
class Polygons : public Figure {
   private:
       int count;             // invariant count >= 3;
       Point2D* vertices;
   public:
       Polygons();
       explicit Polygons(int count);    // pre count >= 3;
       Polygons(int count, const Point2D points[]);  // pre count >= 3;
       Polygons(int count, const double x[], const double y[]);   // pre count >= 3;
       Polygons(const Polygons& other);
       virtual ~Polygons();

       
       virtual int Count() const;
       virtual const Point2D& Vertex(int x) const;  // pre 0 <= x && x < Count();
       virtual  Point2D& operator [](int x) ;  // pre 0 <= x && x < Count();
       virtual void Set(const Point2D& p, int x); // pre 0 <= x && x < Count();

       virtual void Scale(double fx, double fy);
       virtual void Rotate(double angle);
       virtual void Translate(double dx, double dy);

       virtual void Write(ostream& output = cout) const;
       virtual void WriteLine(ostream& output = cout) const;

       virtual void Copy(const Polygons& other);
       virtual Polygons& operator = (const Polygons& other);


       bool Convex() const;



};
#endif
