//---------------------------------------------------------------------------

#ifndef PlayerH
#define PlayerH
//---------------------------------------------------------------------------
#include "Ball.h"

class Player
{
private:
        int index;
	int shoots;
	Ball::BallTeamType ballTeam;
	int  nrBalls;
	Player	*next;
public:
        Player();
        virtual ~Player();

        virtual void SetIndex(const int &i);
        virtual int GetIndex() const ;

        virtual void ShootsInc();
        virtual void ShootsDec();
        virtual void ShootsZero();
        virtual int GetShoots() const;

        virtual void NrBallsInc();
        virtual void NrBallsZero();
        virtual int GetNrBalls() const;

        virtual void SetBallTeam(const Ball::BallTeamType &team);
        virtual Ball::BallTeamType GetBallTeam() const;
        virtual char *GetTeamStr() const;

        virtual void SetNext(Player *n);
        virtual Player *GetNext();
};

#endif
 