//---------------------------------------------------------------------------

#ifndef Point2DH
#define Point2DH
#include "Figure.h"
#include <iostream.h>
//---------------------------------------------------------------------------
class Point2D : public Figure{
  private:
       double x;
       double y;
  public:
        Point2D();
        Point2D(double x, double y);
        Point2D(const Point2D& other);
        virtual ~Point2D();

        virtual double X() const;
        virtual double Y() const;
        virtual void SetX(double x);
        virtual void SetY(double y);
        virtual void Set(double x, double y);

        virtual void Translate(double dx, double dy);
        virtual void Scale(double dx, double dy);
        virtual void Rotate(double ang);
        virtual double DistanceTo(const Point2D& other)const;

        virtual double Modulus() const;
        virtual double Angle() const;

        virtual void Write(ostream& output = cout) const;
        virtual void WriteLine(ostream& output = cout) const;
        virtual void Read(istream& input = cin);

        virtual bool Equal(const Point2D& other) const;
        virtual bool operator==(const Point2D& other) const;
        virtual bool operator!=(const Point2D& other) const;


};
#endif
