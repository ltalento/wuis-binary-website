//---------------------------------------------------------------------------

#ifndef frmGameH
#define frmGameH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <Buttons.hpp>
#include <ComCtrls.hpp>
#include <Menus.hpp>
#include <Graphics.hpp>
#include <ImgList.hpp>
#include <gl/gl.h> 
#include <gl/glu.h>

#include "Ball.h"
#include "Player.h"
#include "Table.h"
#include "CueStick.h"
//---------------------------------------------------------------------------
class TfrmMain : public TForm
{
__published:	// IDE-managed Components
        TPanel *Scene;
        TTimer *Timer;
        TProgressBar *PowerBar;
        TPageControl *PlayersPage;
        TTabSheet *TabSheet1;
        TTabSheet *TabSheet2;
        TMainMenu *MainMenu;
        TMenuItem *File;
        TMenuItem *Restart;
        TMenuItem *Exit;
        TMenuItem *Help;
        TMenuItem *About;
        TLabel *Label1;
        TLabel *Label2;
        TLabel *Label3;
        TLabel *Label4;
        TEdit *edtPlayer2Team;
        TEdit *edtPlayer2Shoots;
        TEdit *edtPlayer1Team;
        TEdit *edtPlayer1Shoots;
        TTimer *FastTimer;
        TImageList *ImageList;
        TImage *img1Play1;
        TImage *img2Play1;
        TImage *img3Play1;
        TImage *img4Play1;
        TImage *img5Play1;
        TImage *img6Play1;
        TImage *img7Play1;
        TImage *img1Play2;
        TImage *img2Play2;
        TImage *img3Play2;
        TImage *img4Play2;
        TImage *img5Play2;
        TImage *img6Play2;
        TImage *img7Play2;
        void __fastcall FormCreate(TObject *Sender);
        void __fastcall FormDestroy(TObject *Sender);
        void __fastcall TimerTimer(TObject *Sender);
        void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
        void __fastcall RestartClick(TObject *Sender);
        void __fastcall ExitClick(TObject *Sender);
        void __fastcall FastTimerTimer(TObject *Sender);
        void __fastcall SceneMouseUp(TObject *Sender, TMouseButton Button,
          TShiftState Shift, int X, int Y);
        void __fastcall SceneMouseDown(TObject *Sender,
          TMouseButton Button, TShiftState Shift, int X, int Y);
        void __fastcall SceneMouseMove(TObject *Sender, TShiftState Shift,
          int X, int Y);
        void __fastcall AboutClick(TObject *Sender);
private:	// User declarations
        //Opengl stuff
        HDC   gl_HDC;
        HGLRC gl_HRC;
        bool glCreate();
        void glInit(float w, float h);
        void glShutDwn();
        bool glLoadTexture(const char *filename, GLuint *texture);

        //Game stuff
        enum GameStateType { WAIT, ACTION};

	GameStateType GameState;
        Player *myPlayer;
	int CurrPlayer;
        bool mouseDown;
        int mouseOld_Y;
        
        Table *myTable;
	int  nrBalls;
	Ball *myBall;

        CueStick *myCueStick;
        void __fastcall Action();
        void __fastcall CutAction();
	void __fastcall GameRestart();
	void __fastcall UpdateLabels();
        void __fastcall BallInPocket(int b);
        void __fastcall UpdatePainel(int b);

public:		// User declarations
        __fastcall TfrmMain(TComponent* Owner);

};
//---------------------------------------------------------------------------
extern PACKAGE TfrmMain *frmMain;
//---------------------------------------------------------------------------
#endif
