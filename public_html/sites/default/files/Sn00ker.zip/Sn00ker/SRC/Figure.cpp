
#include <math.h>

#include "Figure.h"
#include "Point2D.h"
#include "Line.h"
Figure::~Figure()
{
}

void Figure::RotateAround(double angle, const Point2D& p)
{
  Translate(-p.X(), -p.Y());
  Rotate(angle);
  Translate(p.X(), p.Y());
}

void Figure::Mirror(const Line& z)
{
  Point2D p(z.Intersection(z.Perpendicular(Point2D())));
  Translate(-p.X(), -p.Y());
  Rotate(-z.Angle());
  Scale(1.0, -1.0);
  Rotate(z.Angle());
  Translate(p.X(), p.Y());
}
