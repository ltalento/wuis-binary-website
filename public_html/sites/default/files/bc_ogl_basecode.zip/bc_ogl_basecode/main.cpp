//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "main.h"
#include "GlDevice.h"

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;

GlDevice gl;

//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
    Application->OnIdle = IdleLoop;

    gl.Create(Panel1->Handle);
    gl.Init(Panel1->Width ,Panel1->Height );
    gl.FontSys_Init();
    Memo1->Clear();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::IdleLoop(TObject*, bool& done)
{
    done = false;
    glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
    glLoadIdentity();
    glColor3f(1,1,1);
    glRasterPos2f(100 ,100);
    gl.FontSys_Print("Hello");

    gl.Show();

    Label1->Caption = "fps = " + AnsiString(gl.ProcessFps());
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormDestroy(TObject *Sender)
{
    gl.FontSys_ShutDwn();
    gl.ShutDwn(Panel1->Handle);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button1Click(TObject *Sender)
{
    //GL_VENDOR
    //GL_RENDERER
    //GL_VERSION
    //GL_EXTENSIONS

    const char* sVendor = glGetString(GL_VENDOR);
    const char* sRender = glGetString(GL_RENDERER);
    const char* sVersion = glGetString(GL_VERSION);
    const char* sExtensions = glGetString(GL_EXTENSIONS);

    Memo1->Clear();

    Memo1->Lines->Add("GL_VENDOR:");
    Memo1->Lines->Add(sVendor);

    Memo1->Lines->Add("");
    Memo1->Lines->Add("GL_RENDERER:");
    Memo1->Lines->Add(sRender);

    Memo1->Lines->Add("");
    Memo1->Lines->Add("GL_VERSION:");
    Memo1->Lines->Add(sVersion);

    Memo1->Lines->Add("");
    Memo1->Lines->Add("GL_EXTENSIONS:");
    Memo1->Lines->Add(sExtensions);

}
//---------------------------------------------------------------------------
/*

SHADING_LANGUAGE_VERSION_ARB		0x8B8C
   const char* sEx = glGetString(0x8B8C);
   Memo1->Lines->Add("");
   Memo1->Lines->Add(sEx);

= wglGetProcAddress();

// This is a define that we use for our function pointers
#define APIENTRYP APIENTRY *

*/

