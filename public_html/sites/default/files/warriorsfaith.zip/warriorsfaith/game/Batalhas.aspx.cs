using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using System.Collections.Generic;
using System.Data.SqlClient;

public partial class game_Default : System.Web.UI.Page
{
    //string selectInimigo="";

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Profile.tipo == 3)
        { 
            Response.Redirect("~/game/EscolherProfile.aspx");
        }

        if (Profile.vida == 0)
        {
            if (Profile.DataRecuperado <= DateTime.Now) //curado
                Profile.vida = Profile.max_vida;
            else
                Response.Redirect("Hospital.aspx");
        }       

        SqlDataSource1.InsertParameters.Add("ParamTime", DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss"));

        //prenche a InimigosDropList
        //ProfileCommon otherUser = Profile.GetProfile(otherUsername);

        MembershipUserCollection users =  Membership.GetAllUsers();
        List<string> inimigos = new List<string>();
        foreach (MembershipUser user in users)
        {
            ProfileCommon userProfile = Profile.GetProfile(user.UserName);
            if ((userProfile.nivel == Profile.nivel || userProfile.nivel == Profile.nivel + 1))
            {
                if (Profile.tipo == 1 && userProfile.tipo == 2 && Profile.UserName != userProfile.UserName && userProfile.vida!=0)
                {                
                    inimigos.Add(userProfile.UserName);            
                }
                else if (Profile.tipo == 2 && userProfile.tipo == 1 && Profile.UserName != userProfile.UserName && userProfile.vida != 0)
                {
                    inimigos.Add(userProfile.UserName);            
                }
            }
        }
        if (!IsPostBack)
        {
            InimigosDropList.DataSource = inimigos;
            InimigosDropList.DataBind();
        }

    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        //if x rows in chat table
        //delete 1st row.               
        SqlDataSource1.Delete();
        SqlDataSource1.Insert();                
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        //
        Page.Response.Redirect(Page.Request.Url.ToString());

    }
    protected void AtacarButton_Click(object sender, EventArgs e)
    {
        if (InimigosDropList.SelectedItem == null)
            return;

        ProfileCommon otherUser = Profile.GetProfile(InimigosDropList.SelectedItem.Text);
        //Label1.Text = otherUser.UserName;
        
        int atacante = Profile.ataque + Profile.bonusAtaque;
        int defesa = otherUser.defesa + otherUser.bonusDefesa;
     
        if (atacante == defesa) //empate
        {            
            if (addExp(1))
                sendRelatorio("relatorio", Profile.UserName, "Relat�rio do ataque", "O combate ficou empatado mas ganhaste \n 1 de experi�ncia e subiste de n�vel!");
            else
               sendRelatorio("relatorio", Profile.UserName, "Relat�rio do ataque", "O combate ficou empatado mas ganhaste \n 1 de experi�ncia");
            sendRelatorio("relatorio", otherUser.UserName, "Relat�rio: Foste atacado", "Foste atacado pelo" +
            Profile.UserName + "\n N�o te aconteceu nada!");
        }
        else if (atacante > defesa) //ganha
        {
            int winMoney;
            int lostMoney;
            winMoney = (int)(otherUser.dinheiro * 0.10);
            lostMoney = (int)(otherUser.dinheiro * 0.10);
            Profile.dinheiro += winMoney;
            otherUser.dinheiro -= lostMoney;

            if (addExp(3))
                sendRelatorio("relatorio", Profile.UserName, "Relat�rio do ataque", "Ganhaste o combate e: \n 3 de experi�ncia \n"
                    + winMoney + " de dinheiro \n subiste de n�vel!");
            else
                sendRelatorio("relatorio", Profile.UserName, "Relat�rio do ataque", "Ganhaste o combate e:\n 3 de experi�ncia\n "
                + winMoney + " de dinheiro");

            otherUser.vida -= 25;
            if (otherUser.vida < 0) otherUser.vida = 0;
            if (otherUser.vida == 0)
            {
                sendRelatorio("relatorio", otherUser.UserName, "Relat�rio: Foste atacado", "Foste morto pelo: " +
            Profile.UserName + "\n perdeste " + lostMoney + " de dinheiro.. \n");
                otherUser.DataRecuperado = System.DateTime.Now.AddHours(4);
            }
            else
                sendRelatorio("relatorio", otherUser.UserName, "Relat�rio: Foste atacado", "Foste atacado pelo " +
            Profile.UserName + "\n Perdeste 25 de vida e o " + lostMoney + " de dinheiro..");            
        }
        else //perde
        {
                     
            Profile.vida -= 25;
            if (Profile.vida < 0) Profile.vida = 0;
            if (Profile.vida == 0) 
            {
                sendRelatorio("relatorio", Profile.UserName, "Relat�rio do ataque", "Morreste no combate..");
                Profile.DataRecuperado = System.DateTime.Now.AddHours(4);
            }
            else
                sendRelatorio("relatorio", Profile.UserName, "Relat�rio do ataque", "Perdeste o combate e 25 de vida..");

            sendRelatorio("relatorio", otherUser.UserName, "Relat�rio: Foste atacado", "Foste atacado pelo" +
            Profile.UserName + "\n mas nada te aconteceu!!");
        }
        otherUser.Save();
        Response.Redirect("mensagens_caixa_r.aspx");
    }

    public void sendRelatorio(string from, string to, string assunto, string mensagem)
    {
        //enviar msg 
        string ConnectionString = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
        SqlConnection connection = new SqlConnection(ConnectionString);
        connection.Open();

        string sql=
        "INSERT INTO msg(user_from, user_to, assunto, mensagem, [time], lida) " +
        "VALUES ('" + from + "','" + to + "','" + assunto + "','" + mensagem + "','" +
        DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss") + "'," + 0 + ");";

        SqlCommand cmd = new SqlCommand(sql, connection);
        cmd.CommandType = CommandType.Text;
        
        cmd.ExecuteNonQuery();
        /*
        sql =
       "INSERT INTO msg_user([user], id_msg, tipo) " +
       "SELECT user_from, id_msg, 1 " +
       "FROM msg " +
       "WHERE id_msg = (SELECT TOP 1 id_msg FROM msg ORDER BY id_msg DESC);";

        cmd.CommandText = sql;
        cmd.ExecuteNonQuery();
        */
        sql = 
        "INSERT INTO msg_user([user], id_msg, tipo) " +
        "SELECT user_to, id_msg, 2 " +
        "FROM msg " +
        "WHERE id_msg = (SELECT TOP 1 id_msg FROM msg ORDER BY id_msg DESC);";
        
        cmd.CommandText = sql;
        cmd.ExecuteNonQuery();
        
    }
    public bool addExp(int inc_exp)
    {
        bool levelUp = false;
        string ConnectionString = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
        SqlConnection connection = new SqlConnection(ConnectionString);
        connection.Open();

        string sql ="SELECT exp_for_next_level FROM nivel_rules WHERE (nivel = " + Profile.nivel + ");";

        SqlCommand cmd = new SqlCommand(sql, connection);
        cmd.CommandType = CommandType.Text;

        int exp_for_next_level = (int)cmd.ExecuteScalar();
        
        Profile.exp +=inc_exp;

        if (Profile.exp >= exp_for_next_level)//subir de nivel recebe ordenado
        {
            Profile.nivel++;
            sql = "SELECT ordenado FROM nivel_rules WHERE nivel = " + Profile.nivel;

            cmd.CommandText = sql;
            int ordenado = (int)cmd.ExecuteScalar();

            levelUp = true;
            Profile.ataque += 5;
            Profile.defesa += 5;
            Profile.max_vida += 25;
            Profile.dinheiro += ordenado;
        }

        connection.Close();

        return levelUp;
    }
}
