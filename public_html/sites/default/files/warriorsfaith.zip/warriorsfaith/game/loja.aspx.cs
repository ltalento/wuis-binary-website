using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class game_loja : System.Web.UI.Page
{

    public bool IsNoItemsLabelVisble;

    protected void Page_Load(object sender, EventArgs e)
    {
        IsNoItemsLabelVisble = false;
        if (Profile.vida == 0)
        {
            if (Profile.DataRecuperado <= DateTime.Now) //curado
                Profile.vida = Profile.max_vida;
            else
                Response.Redirect("Hospital.aspx");
        }
        if (Profile.tipo == 3)
        {
            Response.Redirect("~/game/EscolherProfile.aspx");
        }
    }

    protected void Repeater1_ItemCommand(object source, RepeaterCommandEventArgs e)
    {                        
        string[] args = e.CommandArgument.ToString().Split(',');
        //arg0 = id item
        //arg1 = item price
        //ResultLabel.Text = string.Format("arg 1 : {0}, arg 1 : {1}", args[0], args[1]);
                               
        if (Profile.dinheiro >= Int64.Parse(args[1]) )
        {
            //compra se tiver guito
            UserItemsSqlDataSource.InsertParameters.Add("ParamItemId", args[0]);
            UserItemsSqlDataSource.Insert();
            ResultLabel.Text = "Item comprado";
            Profile.dinheiro -= Int64.Parse(args[1]);
        }
        else
        {
            //se nao tiver dita.. mostar m
            ResultLabel.Text = "N�o tens dinheiro suficiente para comprar o Item!";
        }
        Master.RefreshProfileValues();
                 
    }

    protected void Repeater2_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        
        if(e.CommandName == "vender")
        {
            //vender
            string[] args = e.CommandArgument.ToString().Split(',');
            //arg0 = id user item
            //arg1 = item price 
            //arg2 = item activo
            //arg3 = tipo;

            UserItemsSqlDataSource.DeleteParameters.Add("ParamIdUserItem",args[0]);
            UserItemsSqlDataSource.Delete();
            Profile.dinheiro += Int64.Parse(args[1])/2;

            //update for�a bonus e defesa bonus if item vendido estava activo
            if (bool.Parse(args[2]) == true)
            {
                if(Int16.Parse(args[3])==1)
                    Profile.bonusAtaque = 0;
                else
                    Profile.bonusDefesa = 0;            
            }

            //ResultLabel.Text = "vender: " + e.CommandArgument.ToString();


        }
        else if (e.CommandName == "activar")
        {
            //activar 
            string[] args = e.CommandArgument.ToString().Split(',');
            //args:
            //0 id user item           
            //1 activo
            //2 bonus / valor
            //3 tipo           
            
            int IdUserItem = int.Parse(args[0]);
            bool activo = bool.Parse(args[1]);
            Int16 bonus = Int16.Parse(args[2]);
            int tipo = int.Parse(args[3]);
            
            

            if (tipo == 1)//item de ataque
            { 
                //desactiva todas os item do tipo 1                
                UserItemsSqlDataSource.UpdateCommand 
                    = "UPDATE user_item SET activo = 0 WHERE [user] = '" + 
                    Profile.UserName + "' AND id_item IN (SELECT id_item FROM item WHERE tipo = 1)";
                UserItemsSqlDataSource.Update(); 
                if (!activo)
                {
                    //activa
                    UserItemsSqlDataSource.UpdateCommand
                        = "UPDATE user_item SET activo = 1 WHERE id_user_item = " + IdUserItem;
                    UserItemsSqlDataSource.Update(); 
                    //update profile
                    Profile.bonusAtaque = bonus;
                }
                else 
                {
                    UserItemsSqlDataSource.UpdateCommand
                         = "UPDATE user_item SET activo = 0 WHERE id_user_item = " + IdUserItem;
                    UserItemsSqlDataSource.Update();
                    //update profile
                    Profile.bonusAtaque = 0;
                }
                
            }
            else if(tipo == 2) //item de defesa
            {
                //desactiva todas os item do tipo 2                
                UserItemsSqlDataSource.UpdateCommand
                    = "UPDATE user_item SET activo = 0 WHERE [user] = '" +
                    Profile.UserName + "' AND id_item IN (SELECT id_item FROM item WHERE tipo = 2)";
                UserItemsSqlDataSource.Update();
                if (!activo)
                {
                    //activa
                    UserItemsSqlDataSource.UpdateCommand
                        = "UPDATE user_item SET activo = 1 WHERE id_user_item = " + IdUserItem;
                    UserItemsSqlDataSource.Update();
                    //update profile
                    Profile.bonusDefesa = bonus;
                }
                else
                {
                    UserItemsSqlDataSource.UpdateCommand
                         = "UPDATE user_item SET activo = 0 WHERE id_user_item = " + IdUserItem;
                    UserItemsSqlDataSource.Update();
                    //update profile
                    Profile.bonusDefesa = 0;
                }
            }            
            else if (tipo == 3) //item de porcao
            {
                //apaga o item
                UserItemsSqlDataSource.DeleteParameters.Add("ParamIdUserItem", IdUserItem.ToString());
                UserItemsSqlDataSource.Delete();
                //update profile
                Profile.vida += bonus;
                if (Profile.vida > Profile.max_vida) Profile.vida = Profile.max_vida;
            }
                        
            ResultLabel.Text = "";
        }
        Master.RefreshProfileValues();

    }

    protected string WriteItemActiveButtonName(bool active, int tipo)
    {
        if (tipo == 3)
            return "Consumir";
        else if (active) return "Activo";
        return "Inactivo";   
    }

    protected void UserItemsSqlDataSource_Selected(object sender, SqlDataSourceStatusEventArgs e)
    {
        if (e.AffectedRows == 0)
                IsNoItemsLabelVisble=true;
    }
}
