using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class game_EscolherProfile : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Profile.tipo != 3)
        { 
        
        
        
        }           
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if( RadioButtonList1.SelectedItem.Value == "2")
            Profile.tipo = 2;  
        else
            Profile.tipo = 1;

        Master.RefreshProfileValues();

        Response.Redirect("~/game/Aquartelamento.aspx");
    }
    protected void RadioButtonList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        //
        if (RadioButtonList1.SelectedItem.Value == "2")
        {
            ImageButton1.ImageUrl = "~/game/images/avatars/mouro1.png";
            ImageButton2.ImageUrl = "~/game/images/avatars/mouro2.png";
            ImageButton3.ImageUrl = "~/game/images/avatars/mouro3.png";
            Profile.avatar = ImageButton1.ImageUrl;         
            Master.RefreshProfileValues(); 
        }
        else
        {
            ImageButton1.ImageUrl = "~/game/images/avatars/templario1.png";
            ImageButton2.ImageUrl = "~/game/images/avatars/templario2.png";
            ImageButton3.ImageUrl = "~/game/images/avatars/templario3.png";
            Profile.avatar = ImageButton1.ImageUrl;
            Master.RefreshProfileValues();
        }
    }
    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        //
        Profile.avatar = ImageButton1.ImageUrl;
        Master.RefreshProfileValues();
    }
    protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
    {
        Profile.avatar = ImageButton2.ImageUrl;
        Master.RefreshProfileValues();
    }
    protected void ImageButton3_Click(object sender, ImageClickEventArgs e)
    {
        Profile.avatar = ImageButton3.ImageUrl;
        Master.RefreshProfileValues();
    }
}
