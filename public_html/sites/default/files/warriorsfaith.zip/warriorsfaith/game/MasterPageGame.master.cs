using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class game_MasterPageGame : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        RefreshProfileValues();
    }

    public void RefreshProfileValues()
    {
        UserNivelLable.Text = Profile.nivel.ToString();
        UserAtaqueLabel.Text = Profile.ataque.ToString() + " (+" + Profile.bonusAtaque.ToString() + ")";
        UserDefesaLabel.Text = Profile.defesa.ToString() + " (+" + Profile.bonusDefesa.ToString() + ")";
        UserDinheiroLabel.Text = Profile.dinheiro.ToString();
        UserExpLabel.Text = Profile.exp.ToString();
        UserVidaLabel.Text = Profile.vida.ToString() + "/" + Profile.max_vida;

        UserAvatarImageButton.ImageUrl = Profile.avatar;
    }

    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
       Page.Response.Redirect("aquartelamento.aspx");
    }
    protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
    {
       Page.Response.Redirect("loja.aspx");
    }

    protected void ImageButton4_Click(object sender, ImageClickEventArgs e)
    {
        Page.Response.Redirect("mensagens_caixa_r.aspx");
    }
    protected void UserAvatarImageButton_Click(object sender, ImageClickEventArgs e)
    {
        Page.Response.Redirect("EditarProfile.aspx");
    }
    protected void ImageButton3_Click(object sender, ImageClickEventArgs e)
    {
        Page.Response.Redirect("Batalhas.aspx");
    }
}
