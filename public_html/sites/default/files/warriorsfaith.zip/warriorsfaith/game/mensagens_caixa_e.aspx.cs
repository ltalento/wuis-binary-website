using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class game_mensagens : System.Web.UI.Page
{
    public bool IsMsgLabelVisble;
    
    protected void Page_Load(object sender, EventArgs e)
    {  
        IsMsgLabelVisble = false; 
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Page.Response.Redirect("mensagens_caixa_r.aspx");
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Page.Response.Redirect("mensagens_caixa_e.aspx");
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        Page.Response.Redirect("mensagens_enviar.aspx");
    }
    protected void Button4_Click(object sender, EventArgs e)
    {
     
        string selectedIds = "";
        foreach (RepeaterItem row in Repeater1.Items)
        {
            CheckBox cb = (CheckBox)row.FindControl("ckb_del");
            /*if (cb != null)
                cb.Checked = !cb.Checked;
            */
            if (cb != null && cb.Checked)
            {
                string id = ((HiddenField)row.FindControl("HiddenField1")).Value;
                selectedIds += id + ",";
            }

        }

        if (selectedIds != "")
        {
            //query para apagar mensagens selecionadas
            selectedIds = selectedIds.Remove(selectedIds.Length - 1);            
            SqlDataSource1.DeleteCommand = "DELETE FROM msg_user WHERE id_msg IN ( " +
                selectedIds + " )" +  
                " AND [user] = '" + Profile.UserName + 
                "' AND tipo=1";
            
           SqlDataSource1.Delete();

            //query para apagar as mensagens nao usadas
            SqlDataSource1.DeleteCommand = "DELETE FROM msg WHERE id_msg NOT IN (SELECT id_msg FROM msg_user WHERE msg_user.id_msg=msg.id_msg)";
            SqlDataSource1.Delete();
        }
   
    }
    
    protected string WriteIfNLida(bool value)
    {
        if (!value) return " (N�o Lida)";
        return "";
    }

    protected void SqlDataSource1_Selected(object sender, SqlDataSourceStatusEventArgs e)
    {
        if (e.AffectedRows == 0)
        {
            IsMsgLabelVisble = true;

        } 
    }
}
