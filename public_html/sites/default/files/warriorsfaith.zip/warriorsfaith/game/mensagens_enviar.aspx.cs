using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class game_mensagens : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
    
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        Page.Response.Redirect("mensagens_caixa_r.aspx");
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Page.Response.Redirect("mensagens_caixa_e.aspx");
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        Page.Response.Redirect("mensagens_enviar.aspx");
    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        //enviar msg 

        SqlDataSource1.InsertCommand =
        "INSERT INTO msg(user_from, user_to, assunto, mensagem, [time], lida) "+
        "VALUES ('" + Profile.UserName + "','"
        + TextBox1.Text + "','"
        + TextBox2.Text + "','"
        + TextBox3.Text + "','"
        + DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss") + "'," + 0 + ");";
        SqlDataSource1.Insert();


        //mensagem enviada
        SqlDataSource1.InsertCommand =
       "INSERT INTO msg_user([user], id_msg, tipo) " +
       "SELECT user_from, id_msg, 1 " +
       "FROM msg " +        
       "WHERE id_msg = (SELECT TOP 1 id_msg FROM msg ORDER BY id_msg DESC);";
        SqlDataSource1.Insert();

       //mensagem recebida
        SqlDataSource1.InsertCommand =
        "INSERT INTO msg_user([user], id_msg, tipo) " +
        "SELECT user_to, id_msg, 2 " +
        "FROM msg " +
        "WHERE id_msg = (SELECT TOP 1 id_msg FROM msg ORDER BY id_msg DESC);";
        SqlDataSource1.Insert();
        
        Page.Response.Redirect("mensagens_caixa_e.aspx");
    }
}
