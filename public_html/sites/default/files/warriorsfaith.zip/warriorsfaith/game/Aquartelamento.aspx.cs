using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class game_Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Profile.tipo == 3)
        { 
            Response.Redirect("~/game/EscolherProfile.aspx");
        }
        if (Profile.vida == 0)
        {
            if (Profile.DataRecuperado <= DateTime.Now) //curado
                Profile.vida = Profile.max_vida;
            else
                Response.Redirect("Hospital.aspx");
        }

        SqlDataSource1.InsertParameters.Add("ParamTime", DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss"));            
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        //if x rows in chat table
        //delete 1st row.               
        SqlDataSource1.Delete();
        SqlDataSource1.Insert();                
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        //
        Page.Response.Redirect(Page.Request.Url.ToString());

    }
}
