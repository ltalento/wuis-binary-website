using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class game_mensagens : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

	/*
        if (Request.QueryString["id_msg"] != null || Request.QueryString["id_msg"].Length  != 0)
               SqlDataSource1.Update();
	*/

        if (Request.QueryString["id_msg"] != null || Request.QueryString["id_msg"].Length != 0)
        {
            HyperLink user_from = (HyperLink)FormView1.FindControl("user_fromHyperLink");
            if (user_from != null && user_from.Text != Profile.UserName)
                SqlDataSource1.Update();
        }
 
 
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Page.Response.Redirect("mensagens_caixa_r.aspx");
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Page.Response.Redirect("mensagens_caixa_e.aspx");
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        Page.Response.Redirect("mensagens_enviar.aspx");
    }
}
