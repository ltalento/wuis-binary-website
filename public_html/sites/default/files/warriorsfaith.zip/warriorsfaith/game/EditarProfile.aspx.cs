using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class game_EditarProfile : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Profile.tipo == 3)
        {
            Response.Redirect("~/game/EscolherProfile.aspx");
        }

        if (!IsPostBack)
        {
            if (Profile.tipo==2)
            {
                ImageButton1.ImageUrl = "~/game/images/avatars/mouro1.png";
                ImageButton2.ImageUrl = "~/game/images/avatars/mouro2.png";
                ImageButton3.ImageUrl = "~/game/images/avatars/mouro3.png";                
            }
            else
            {
                ImageButton1.ImageUrl = "~/game/images/avatars/templario1.png";
                ImageButton2.ImageUrl = "~/game/images/avatars/templario2.png";
                ImageButton3.ImageUrl = "~/game/images/avatars/templario3.png";
            }
        }
    }
    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        Profile.avatar = ImageButton1.ImageUrl;
        Master.RefreshProfileValues();
    }
    protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
    {
        Profile.avatar = ImageButton2.ImageUrl;
        Master.RefreshProfileValues();
    }
    protected void ImageButton3_Click(object sender, ImageClickEventArgs e)
    {
        Profile.avatar = ImageButton3.ImageUrl;
        Master.RefreshProfileValues();
    }
}
