using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class game_VerProfile : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack)
        {
            string otherUsername = Request.QueryString["username"];

            if (otherUsername != null || otherUsername.Length != 0)
            {
                ProfileCommon otherUser = Profile.GetProfile(otherUsername);
                if (otherUser != null)
                {
                    UserAvatarImage.ImageUrl = otherUser.avatar;
                    UserNameLabel.Text = otherUser.UserName;
                    if (otherUser.tipo == 1)
                        UserLadoLabel.Text = "Templario";
                    else
                        UserLadoLabel.Text = "Mouro";
                    UserNivelLabel.Text = otherUser.nivel.ToString();
                    UserAtaqueLabel.Text = otherUser.ataque + " (+" + otherUser.bonusAtaque + ")";
                    UserDefesaLabel.Text = otherUser.defesa + " (+" + otherUser.bonusDefesa + ")";
                }
            }
        }              
    }
}
