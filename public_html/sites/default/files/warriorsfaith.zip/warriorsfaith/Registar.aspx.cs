using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Registar : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void CreateUserWizard1_FinishButtonClick(object sender, WizardNavigationEventArgs e)
    {
        Response.Redirect("~/game/EscolherProfile.aspx");
    }
    protected void CreateUserWizard1_ContinueButtonClick(object sender, EventArgs e)
    {
        Response.Redirect("~/game/EscolherProfile.aspx");
    }
    protected void ContinueButton_Click(object sender, EventArgs e)
    {
        /////
        Roles.AddUserToRole(User.Identity.Name, "jogadores");
        Response.Redirect("~/game/EscolherProfile.aspx");
    }
}
