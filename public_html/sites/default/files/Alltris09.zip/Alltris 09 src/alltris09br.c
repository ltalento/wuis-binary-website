#include <stdlib.h>
#include <stdio.h>
#include "string.h"
#include "allegro.h"
#include "alltris.h"
#include "matrizes.h"

void put_text(int a,int b,char *LinesTX); 
void desenha_bloco(int x,int y,char cor);
void display();
void matriz();
void matriz2();
void checa_linhas();
void gameover();
void youwin();
void play_game();
void desenha_next();
int teste(int escolhida,int posicao);
char pause();
char Main_menu();
void About_Menu();

struct{
unsigned char nr_posicoes;
unsigned char posicao, old_posicao;
unsigned char x, old_x;
unsigned char y, old_y;
unsigned char tamanho;
}peca[7];

int escolhida, next_p, endgame=0,pontuacao=0, game_speed=0, cont1=0; 
unsigned int vel, frame_count, fps, Lines, Score, Level;

char tabuleiro_final[23][13], tabuleiro[23][13], velo[20], pss[20], grid, bfps, LinesTXT[10], ScoreTXT[6], LevelTXT[2];

BITMAP *buffer, *fundo, *pec[7], *letra;
DATAFILE *dat;

void game_speeds()
{
 game_speed++;
 cont1++;
}
END_OF_FUNCTION(game_speeds);

void fps_proc()
{  
   sprintf(pss,"FPS-> %i",frame_count);
   frame_count = 0;
}
END_OF_FUNCTION(fps_proc);


void main()
{
   allegro_init();
   install_keyboard(); 
   install_timer();

   if (set_gfx_mode(GFX_AUTODETECT, 640, 480, 0, 0) !=0) {
    allegro_exit();
    printf("Erro configurando grafico\n");
    exit(1);
   }  
      dat = load_datafile("alltris.dat");
      if (!dat) {
         allegro_exit();
         printf("Erro abrindo o ficheiro \"alltris.dat\" ");
         /* report an error! */
	 return;
      }
      
      set_palette(dat[Pal].dat);
      fundo= (BITMAP *)dat[Fundo].dat;
      buffer= create_bitmap(SCREEN_W, SCREEN_H);     
      
      pec[0]= (BITMAP *)dat[p1].dat;
      pec[1]= (BITMAP *)dat[p2].dat;
      pec[2]= (BITMAP *)dat[p3].dat;
      pec[3]= (BITMAP *)dat[p4].dat;
      pec[4]= (BITMAP *)dat[p5].dat;
      pec[5]= (BITMAP *)dat[p6].dat;
      pec[6]= (BITMAP *)dat[p7].dat;
      while( Main_menu() != 3) {      }
 

// destroy_bitmap(buffer);
// destroy_bitmap(peca);
 unload_datafile(dat);
   /*  Finaliza Allegro  */
 allegro_exit();
} 

void display()
{
 int a,b,i,c;
  clear(buffer);
  blit(fundo,buffer, 0, 0, 0, 0, SCREEN_W, SCREEN_H); // buffer = fundo;
  desenha_next();
 a=214;
 b=30;
 for (i=1;i<21;i++)
   {
     for (c=1;c<11;c++)
      {
	if (tabuleiro_final[i][c] != 0 )
	   desenha_bloco(a,b,tabuleiro_final[i][c]);
	a+=21;
      }
	a=214;
	b+=21;
    }

//linhas 

if (grid)
{
 a=214;
 b=50;
 for (i=1;i<20;i++)
   { 
    hline(buffer,a,b,423,9);    
    b+=21;
   }   
 
 a=235;
 b=30;
 for (c=1;c<10;c++)
      {
        vline(buffer,a,b,449,9);      
	a+=21;
      }
 
}

 /*if (endgame)
   {
    gameover();
   }*/
 sprintf(velo,"velocidade-> %i",vel);
 frame_count++;
 if(bfps) textout_centre(buffer, font, pss , 320, 10, 255);
 
 //excreve as linhas
 put_text(515-(strlen(ScoreTXT)*4.5),127,ScoreTXT);
 put_text(515-(strlen(LinesTXT)*4.5),245,LinesTXT); 
 put_text(515-(strlen(LevelTXT)*4.5),368,LevelTXT);
 //vsync();
 blit(buffer, screen, 0, 0, 0, 0, SCREEN_W, SCREEN_H);
}

void play_game()
{
 int carregada=0,carre=0, stop=0,tecla=0, a,b;

 LOCK_VARIABLE(cont1);
 LOCK_VARIABLE(game_speed);
 LOCK_FUNCTION(game_speeds);

 LOCK_VARIABLE(frame_count);
 LOCK_FUNCTION(fps_proc);

 
peca[0].nr_posicoes=1;
peca[0].tamanho=2;
peca[1].nr_posicoes=2;
peca[1].tamanho=3;
peca[2].nr_posicoes=2;
peca[2].tamanho=3;
peca[3].nr_posicoes=2;
peca[3].tamanho=4;
peca[4].nr_posicoes=4;
peca[4].tamanho=3;
peca[5].nr_posicoes=4;
peca[5].tamanho=3;
peca[6].nr_posicoes=4;
peca[6].tamanho=3;
for(a=0;a<23;a++)
  for(b=0;b<13;b++)
    {
     tabuleiro[a][b]=tabuleiro_ini[a][b];   
    }
// display();
  
 Score=0; 
 Level=1;
 Lines=0;
 sprintf(ScoreTXT,"%i",Score);
 sprintf(LevelTXT,"%i",Level);
 sprintf(LinesTXT,"%i",Lines);
 
 grid=0;
 bfps=0;
 vel=20;
 install_int(game_speeds, 50);
 install_int(fps_proc, 1000);

 srand(time(0));

 
 next_p=rand()%7;
for(;;) //infinit loop
{
	 escolhida=next_p;
	 next_p=rand()%7;
         peca[escolhida].y=1;
	 peca[escolhida].x=4;
	 peca[escolhida].posicao=0;
	 stop=0;
	 if(!teste(escolhida,peca[escolhida].posicao))
	   {
	   endgame=1;
	   display();          
           gameover();
           rest(500);
           clear_keybuf();
           readkey();
           goto fim;
	   }
	 if(vel==0)
	   {	   
	   display();          
           youwin();
           rest(500);
           clear_keybuf();
           readkey();
           About_Menu();
           goto fim;  	   	   
	  }
	
   clear_keybuf();
   do{
	game_speed=1;
        cont1=0;   
	do{
       while ((game_speed > 0) )//
                  {//
                if (key[KEY_F1])
		   {
		    grid=!grid;				   
		    key[KEY_F1]=FALSE;
		   }		    
		if (key[KEY_F])
		   {
		    bfps=!bfps;
		    key[KEY_F]=FALSE;
		   }
		if (key[78])
		{
		 vel-=1;
		}
		if (key[74])
		{
		 vel+=1;
		}
		if (key[KEY_RIGHT])
		   {		    	     		     
		      peca[escolhida].old_x=peca[escolhida].x;
		      peca[escolhida].x+=1;                     
                      //clear_keybuf();		     
		   }

		else if (key[KEY_LEFT]) 
		   {      
		     // tecla++;
		     //if (tecla>0) 
		      //{
		      peca[escolhida].old_x=peca[escolhida].x;
		      if (peca[escolhida].x>0)
			  peca[escolhida].x-=1;
		    //clear_keybuf();
		      //}
		   }
		   
	        else if (key[KEY_DOWN])
		      {	
			Score+=1; 
                        sprintf(ScoreTXT,"%i",Score);
			goto yy;
		      }			
		else if (key[KEY_UP])
		   {
		    if(carregada==0)
		     {
		      carregada=1;
		      peca[escolhida].old_posicao=peca[escolhida].posicao;
		      peca[escolhida].posicao+=1;
		      if(peca[escolhida].posicao==peca[escolhida].nr_posicoes)
			 peca[escolhida].posicao=0;
		      }
		   
		    //else
		      //carregada=0;  
		   }
	   
	   else  {carregada=0;                       
	          tecla=0;
	         }
     
      	    if(teste(escolhida,peca[escolhida].posicao))
	   	     {
	    		matriz();
	   	     }
	             else
	   		{
	   		 if (carregada==1)
	       		   peca[escolhida].posicao=peca[escolhida].old_posicao;
	    		  else
	       		    peca[escolhida].x=peca[escolhida].old_x;
	                 matriz();
	                }
   		    game_speed=0;	           
  	         }//         
     
      	   
            display();
            if (key[KEY_ESC])
               {
                if ( pause()==2 )
                     
                     goto fim;
               }
         }while (cont1<vel);
     yy:
     game_speed=0;
     cont1=0;
     peca[escolhida].y+=1;
     if(teste(escolhida,peca[escolhida].posicao))
       {
        matriz();
        stop=0;
       }
        else
       {
        peca[escolhida].y--;
   	matriz2();
   	checa_linhas();
   	stop=1;
       }
   	display();
        //clear_keybuf();
    }while(!stop);

}//fim do loop

fim:
rest(1);
//unload_datafile(dat);  
}//fim do processo

void matriz()
{
int x,y;

	for(y=0;y<23;y++)
	       for(x=0;x<13;x++)
		 tabuleiro_final[y][x]=tabuleiro[y][x];

	    switch(escolhida)
	     {
	      case 0:
		     for(y=0;y<peca[escolhida].tamanho;y++)
			for(x=0;x<peca[escolhida].tamanho;x++)
			    tabuleiro_final[y+peca[escolhida].y][x+peca[escolhida].x]=peca1[peca[escolhida].posicao][y][x];
		     break;
	      case 1:
		     for(y=0;y<peca[escolhida].tamanho;y++)
			for(x=0;x<peca[escolhida].tamanho;x++)
			   if (peca2[peca[escolhida].posicao][y][x]!=0)
			    tabuleiro_final[y+peca[escolhida].y][x+peca[escolhida].x]=peca2[peca[escolhida].posicao][y][x];

		     break;
	      case 2:
		     for(y=0;y<peca[escolhida].tamanho;y++)
			for(x=0;x<peca[escolhida].tamanho;x++)
			    if (peca3[peca[escolhida].posicao][y][x]!=0)
			      tabuleiro_final[y+peca[escolhida].y][x+peca[escolhida].x]=peca3[peca[escolhida].posicao][y][x];
		     break;
	      case 3:
		     for(y=0;y<peca[escolhida].tamanho;y++)
			for(x=0;x<peca[escolhida].tamanho;x++)
			    if (peca4[peca[escolhida].posicao][y][x]!=0)
			      tabuleiro_final[y+peca[escolhida].y][x+peca[escolhida].x]=peca4[peca[escolhida].posicao][y][x];
		     break;
	      case 4:
		     for(y=0;y<peca[escolhida].tamanho;y++)
			for(x=0;x<peca[escolhida].tamanho;x++)
			    if (peca5[peca[escolhida].posicao][y][x]!=0)
			      tabuleiro_final[y+peca[escolhida].y][x+peca[escolhida].x]=peca5[peca[escolhida].posicao][y][x];
		     break;
	      case 5:
		     for(y=0;y<peca[escolhida].tamanho;y++)
			for(x=0;x<peca[escolhida].tamanho;x++)
			    if (peca6[peca[escolhida].posicao][y][x]!=0)
			      tabuleiro_final[y+peca[escolhida].y][x+peca[escolhida].x]=peca6[peca[escolhida].posicao][y][x];
		     break;
	      case 6:
		     for(y=0;y<peca[escolhida].tamanho;y++)
			for(x=0;x<peca[escolhida].tamanho;x++)
			    if (peca7[peca[escolhida].posicao][y][x]!=0)
			      tabuleiro_final[y+peca[escolhida].y][x+peca[escolhida].x]=peca7[peca[escolhida].posicao][y][x];
		     break;
	      }
}

void matriz2()
{
int x,y;

	    switch(escolhida)
	     {
	      case 0:
		     for(y=0;y<peca[escolhida].tamanho;y++)
			for(x=0;x<peca[escolhida].tamanho;x++)
			    tabuleiro[y+peca[escolhida].y][x+peca[escolhida].x]=peca1[peca[escolhida].posicao][y][x];
		     break;
	      case 1:
		     for(y=0;y<peca[escolhida].tamanho;y++)
			for(x=0;x<peca[escolhida].tamanho;x++)
			   if (peca2[peca[escolhida].posicao][y][x]!=0)
			    tabuleiro[y+peca[escolhida].y][x+peca[escolhida].x]=peca2[peca[escolhida].posicao][y][x];

		     break;
	      case 2:
		     for(y=0;y<peca[escolhida].tamanho;y++)
			for(x=0;x<peca[escolhida].tamanho;x++)
			    if (peca3[peca[escolhida].posicao][y][x]!=0)
			      tabuleiro[y+peca[escolhida].y][x+peca[escolhida].x]=peca3[peca[escolhida].posicao][y][x];
		     break;
	      case 3:
		     for(y=0;y<peca[escolhida].tamanho;y++)
			for(x=0;x<peca[escolhida].tamanho;x++)
			    if (peca4[peca[escolhida].posicao][y][x]!=0)
			      tabuleiro[y+peca[escolhida].y][x+peca[escolhida].x]=peca4[peca[escolhida].posicao][y][x];
		     break;
	      case 4:
		     for(y=0;y<peca[escolhida].tamanho;y++)
			for(x=0;x<peca[escolhida].tamanho;x++)
			    if (peca5[peca[escolhida].posicao][y][x]!=0)
			      tabuleiro[y+peca[escolhida].y][x+peca[escolhida].x]=peca5[peca[escolhida].posicao][y][x];
		     break;
	      case 5:
		     for(y=0;y<peca[escolhida].tamanho;y++)
			for(x=0;x<peca[escolhida].tamanho;x++)
			    if (peca6[peca[escolhida].posicao][y][x]!=0)
			      tabuleiro[y+peca[escolhida].y][x+peca[escolhida].x]=peca6[peca[escolhida].posicao][y][x];
		     break;
	      case 6:
		     for(y=0;y<peca[escolhida].tamanho;y++)
			for(x=0;x<peca[escolhida].tamanho;x++)
			    if (peca7[peca[escolhida].posicao][y][x]!=0)
			      tabuleiro[y+peca[escolhida].y][x+peca[escolhida].x]=peca7[peca[escolhida].posicao][y][x];
		     break;
	      }

	      for(y=0;y<23;y++)
	       for(x=0;x<13;x++)
		 tabuleiro_final[y][x]=tabuleiro[y][x];
}


int teste(int escolhida,int posicao)
{
  int x, y;
  char passa;
  for (y=0; y<peca[escolhida].tamanho;y++)
     for (x=0;x<peca[escolhida].tamanho;x++)
	switch(escolhida)
	 {
	   case 0:
		  if (peca1[posicao][y][x]!=0)
		     if ((peca1[posicao][y][x]+tabuleiro[y+peca[escolhida].y][x+peca[escolhida].x])==peca1[posicao][y][x])
			  passa=1;
		      else
			{
			  passa=0;
			  goto continua;
			 }
		  break;
	   case 1:
		  if (peca2[posicao][y][x]!=0)
		     if ((peca2[posicao][y][x]+tabuleiro[y+peca[escolhida].y][x+peca[escolhida].x])==peca2[posicao][y][x])
			  passa=1;
		     else
		       {
			  passa=0;
			  goto continua;
		       }
		  break;
	   case 2:
		  if (peca3[posicao][y][x]!=0)
		     if ((peca3[posicao][y][x]+tabuleiro[y+peca[escolhida].y][x+peca[escolhida].x])==peca3[posicao][y][x])
			  passa=1;
		     else
		       {
			  passa=0;
			  goto continua;
		       }
		  break;
	   case 3:
		  if (peca4[posicao][y][x]!=0)
		     if ((peca4[posicao][y][x]+tabuleiro[y+peca[escolhida].y][x+peca[escolhida].x])==peca4[posicao][y][x])
			  passa=1;
		     else
		       {
			  passa=0;
			  goto continua;
		       }
		  break;
	   case 4:
		  if (peca5[posicao][y][x]!=0)
		     if ((peca5[posicao][y][x]+tabuleiro[y+peca[escolhida].y][x+peca[escolhida].x])==peca5[posicao][y][x])
			  passa=1;
		     else
		       {
			  passa=0;
			  goto continua;
		       }
		  break;
	   case 5:
		  if (peca6[posicao][y][x]!=0)
		     if ((peca6[posicao][y][x]+tabuleiro[y+peca[escolhida].y][x+peca[escolhida].x])==peca6[posicao][y][x])
			  passa=1;
		     else
		       {
			  passa=0;
			  goto continua;
		       }
		  break;
	   case 6:
		  if (peca7[posicao][y][x]!=0)
		     if ((peca7[posicao][y][x]+tabuleiro[y+peca[escolhida].y][x+peca[escolhida].x])==peca7[posicao][y][x])
			  passa=1;
		     else
		       {
			  passa=0;
			  goto continua;
		       }
		  break;
	 }

continua:
return passa;
}

void desenha_bloco(int x,int y,char cor)
{
 
 blit(pec[cor-1], buffer, 0, 0,x ,y,21 ,21 );
 
}

void gameover()
{
 BITMAP *GameOver_BMP; 
 
 GameOver_BMP = (BITMAP *)dat[GameOver].dat;
 masked_blit(GameOver_BMP, screen, 0, 0, 320-(GameOver_BMP->w/2),240-(GameOver_BMP->h/2) , GameOver_BMP->w, GameOver_BMP->h);
 
}

void youwin()
{
 BITMAP *YouWin_BMP; 
 
 YouWin_BMP = (BITMAP *)dat[YouWin].dat;
 masked_blit(YouWin_BMP, screen, 0, 0, 320-(YouWin_BMP->w/2),240-(YouWin_BMP->h/2) , YouWin_BMP->w, YouWin_BMP->h);
 
}

void checa_linhas()
{
 int L,C,L2,C2,linha, nr_linhas=0;
 for (L=1;L<21;L++)
   {
    linha=L;
    for (C=1;C<11;C++)
       if (tabuleiro[L][C]==0)
	 {
	  linha=0;
	  C=12;
	 }
    if (linha!=0)
       {
	nr_linhas+=1;
	Lines+=1;
	sprintf(LinesTXT,"%i",Lines);
	
	for (L2=linha;L2>0;L2--)
	   for (C2=1;C2<11;C2++)
	       if(L2 != 1 )
	       tabuleiro[L2][C2]=tabuleiro[L2-1][C2];
	       else
	       tabuleiro[L2][C2]=0;
       }
   }
 
 switch(nr_linhas)
  {
   case 1: Score+=1;
           break;
   case 2: Score+=4;
           break;
   case 3: Score+=9;
           break;
   case 4: Score+=16;
           break;
  }             
 

 if (Lines>40){
 	Level=2;
        vel=18;}
 if (Lines>80){
 	Level=3;
        vel=16;}       
 if (Lines>120){
 	Level=4;
        vel=14;}
 if (Lines>160){
 	Level=5;
        vel=12;}
 if (Lines>200){
 	Level=6;
        vel=10;}
 if (Lines>240){
 	Level=7;
        vel=8;}
 if (Lines>280){
 	Level=8;
        vel=6;}
 if (Lines>320){
 	Level=9;
        vel=4;}       
 if (Lines>360){
 	Level=10;
        vel=2;}                
 if (Lines>400) vel=0;
        
sprintf(ScoreTXT,"%i",Score);
sprintf(LevelTXT,"%i",Level);

}
void desenha_next()
{
     int x, y, a, b;
  
        switch(next_p)
	 {
	   case 0:
              a=86;
              b=97;
              for(y=0;y<peca[next_p].tamanho;y++)
	      {	
		for(x=0;x<peca[next_p].tamanho;x++)
		   {  
		    if (peca1[0][y][x]!=0)
                          desenha_bloco(a,b,peca1[0][y][x]);
                    a+=21;
                    }
	       a=86;
	       b+=21;
               }                
                break;
	   case 1:             
              a=76;
              b=97;
              for(y=0;y<peca[next_p].tamanho;y++)
	      {	
		for(x=0;x<peca[next_p].tamanho;x++)
		   {  
		    if (peca2[0][y][x]!=0)
                          desenha_bloco(a,b,peca2[0][y][x]);
                    a+=21;
                    }
	       a=76;
	       b+=21;
               }                
                break;
	  case 2:             
              a=76;
              b=97;
              for(y=0;y<peca[next_p].tamanho;y++)
	      {	
		for(x=0;x<peca[next_p].tamanho;x++)
		   {  
		    if (peca3[0][y][x]!=0)
                          desenha_bloco(a,b,peca3[0][y][x]);
                    a+=21;
                    }
	       a=76;
	       b+=21;
               }                
                break;
	  case 3:             
              a=76;
              b=76;
              for(y=0;y<peca[next_p].tamanho;y++)
	      {	
		for(x=0;x<peca[next_p].tamanho;x++)
		   {  
		    if (peca4[0][y][x]!=0)
                          desenha_bloco(a,b,peca4[0][y][x]);
                    a+=21;
                    }
	       a=76;
	       b+=21;
               }                
                break;
	  case 4:             
              a=86;
              b=76;
              for(y=0;y<peca[next_p].tamanho;y++)
	      {	
		for(x=0;x<peca[next_p].tamanho;x++)
		   {  
		    if (peca5[0][y][x]!=0)
                          desenha_bloco(a,b,peca5[0][y][x]);
                    a+=21;
                    }
	       a=76;
	       b+=21;
               }                
                break;
	  case 5:             
              a=65;
              b=86;
              for(y=0;y<peca[next_p].tamanho;y++)
	      {	
		for(x=0;x<peca[next_p].tamanho;x++)
		   {  
		    if (peca6[0][y][x]!=0)
                          desenha_bloco(a,b,peca6[0][y][x]);
                    a+=21;
                    }	       
	       a=65;
	       b+=21;
               }                
                break;
	  case 6:             
              a=65;
              b=86;
              for(y=0;y<peca[next_p].tamanho;y++)
	      {	
		for(x=0;x<peca[next_p].tamanho;x++)
		   {  
		    if (peca7[0][y][x]!=0)
                          desenha_bloco(a,b,peca7[0][y][x]);
                    a+=21;
                    }
	       a=65;
	       b+=21;
               }                
                break;                                             
      }
}


void put_text(int a,int b,char *LinesTX) 
{
 
 int x=a, y=b, Index;
 
   letra= (BITMAP *)dat[NiniFont].dat;   


   for(Index=0; Index < strlen(LinesTX) ;Index++)                   
     switch (LinesTX[Index])
      {
      	case 48: //0
      	blit(letra, buffer, 0, 0,x ,y, 9 ,12 );
      	x+=9;
      	break;
      	case 49: //1
      	blit(letra, buffer, 9, 0,x ,y, 4 , 12 );
      	x+=4;
      	break;
      	case 50: //2
      	blit(letra, buffer, 14, 0,x ,y, 9 ,12 );
      	x+=9;
      	break;
      	case 51: //3
      	blit(letra, buffer, 23, 0,x ,y, 9 , 12 );
      	x+=9;
      	break;
      	case 52: //4
      	blit(letra, buffer, 32, 0,x ,y, 10 , 12 );
      	x+=10;
      	break;
      	case 53: //5
      	blit(letra, buffer, 42, 0,x ,y, 9 , 12 );
      	x+=9;
      	break;
      	case 54: //6
      	blit(letra, buffer, 51, 0,x ,y, 8 , 12 );
      	x+=8;
      	break;
      	case 55: //7
      	blit(letra, buffer, 59, 0,x ,y, 9 , 12 );
      	x+=9;
      	break;
      	case 56: //8
      	blit(letra, buffer, 68, 0,x ,y, 11 , 12 );
      	x+=11;
      	break;
      	case 57: //9
      	blit(letra, buffer, 79, 0,x ,y, 8 , 12 );
      	x+=8;
      	break;      
        default:
      	blit(letra, buffer, 0, 0,x ,y, 9 ,12 );
      	x+=0;
        break;
      }
}
//Pause  
char pause()  
{  
         char op=1;
         BITMAP *pausebuffer, *Pause_BMP, *Resume_L_BMP, *Resume_UL_BMP, *Quit_L_BMP, *Quit_UL_BMP;
                
         
         Pause_BMP = (BITMAP *)dat[Pause].dat;
         Resume_L_BMP = (BITMAP *)dat[Resume_L].dat;
         Resume_UL_BMP = (BITMAP *)dat[Resume_UL].dat;
         Quit_L_BMP = (BITMAP *)dat[Quit_L].dat;
         Quit_UL_BMP = (BITMAP *)dat[Quit_UL].dat;
         
         pausebuffer = create_bitmap(SCREEN_W, SCREEN_H);                 
         
         clear(pausebuffer);
         blit(Pause_BMP,pausebuffer, 0, 0, 220, 170, 199, 141);
                     	         
         masked_blit( Resume_L_BMP , pausebuffer , 0, 0, 270, 224, 100, 33);
         masked_blit( Quit_UL_BMP , pausebuffer , 0, 0, 291, 343-80, 59, 35);
         
         masked_blit(pausebuffer, screen, 0, 0, 0, 0, SCREEN_W, SCREEN_H);
         rest(200);
         do{                                                     
                clear_keybuf(); 
                if (key[KEY_UP])
                 {
                  if (op==2)
                      {
                       op=1;                     
                       clear(pausebuffer);
                       blit(Pause_BMP,pausebuffer, 0, 0, 220, 170, 199, 141);
                     	         
                       masked_blit( Resume_L_BMP , pausebuffer , 0, 0, 270, 224, 100, 33);
                       masked_blit( Quit_UL_BMP , pausebuffer , 0, 0, 291, 343-80, 59, 35);
         
         
                       masked_blit(pausebuffer, screen, 0, 0, 0, 0, SCREEN_W, SCREEN_H);
                       //rest(200);
                      }                
                 }
                else if (key[KEY_DOWN])
		 {	
		  if (op==1)
                      {
                       op=2;  
		       clear(pausebuffer);
                       blit(Pause_BMP,pausebuffer, 0, 0, 220, 170, 199, 141);
                     	         
                       masked_blit( Resume_UL_BMP , pausebuffer , 0, 0, 270, 224, 100, 33);
                       masked_blit( Quit_L_BMP , pausebuffer , 0, 0, 291, 343-80, 59, 35);      
         
                       masked_blit(pausebuffer, screen, 0, 0, 0, 0, SCREEN_W, SCREEN_H);
		       //rest(200);
		      }
		 }

          }while (!key[KEY_ENTER]);
         
       /*
       destroy_bitmap(Pause_BMP);
       destroy_bitmap(Resume_L_BMP);
       destroy_bitmap(Resume_UL_BMP);
       //destroy_bitmap(Quit_L_BMP);
       //destroy_bitmap(Quit_UL_BMP);
       
       destroy_bitmap(pausebuffer);
 */
          if (op==2)
             return 2;
          else
             return 1;

}
char Main_menu()
{
  char op=1;
  BITMAP *MainMbuffer, *MainM_BMP, *Play_L_BMP, *Play_UL_BMP, *About_L_BMP, *About_UL_BMP, *Quit_L_BMP, *Quit_UL_BMP;
          
         MainM_BMP = (BITMAP *)dat[MainM].dat;
         Play_L_BMP = (BITMAP *)dat[Play_L].dat;
         Play_UL_BMP = (BITMAP *)dat[Play_UL].dat;                         
         About_L_BMP = (BITMAP *)dat[About_L].dat;
         About_UL_BMP = (BITMAP *)dat[About_UL].dat;
         Quit_L_BMP = (BITMAP *)dat[Quit_L].dat;
         Quit_UL_BMP = (BITMAP *)dat[Quit_UL].dat;
         
         MainMbuffer = create_bitmap(SCREEN_W, SCREEN_H);       
          
         //clear(screen);
         
         clear(MainMbuffer);               
         masked_blit(MainM_BMP,MainMbuffer, 0, 0, 0, 0, SCREEN_W, SCREEN_H);
                     	         
                 
         masked_blit( Play_L_BMP , MainMbuffer , 0, 0, 287, 217, 66, 33);
         masked_blit( About_UL_BMP , MainMbuffer , 0, 0, 278, 261, 92, 34);
         masked_blit( Quit_UL_BMP , MainMbuffer , 0, 0, 292, 306, 59, 35);        
         
         blit(MainMbuffer, screen, 0, 0, 0, 0, SCREEN_W, SCREEN_H); 
          
         rest(200);
          
          do{
               clear_keybuf();
               if (key[KEY_UP])                                                 
                 { 
                  if (op!=1)
                     {
                      op--;                  
                  switch(op)
		   {   
		    case 1: 
		           clear(MainMbuffer);               
                           masked_blit(MainM_BMP,MainMbuffer, 0, 0, 0, 0, SCREEN_W, SCREEN_H);
                     	                         
                           masked_blit( Play_L_BMP , MainMbuffer , 0, 0, 287, 217, 66, 33);                           
                           masked_blit( About_UL_BMP , MainMbuffer , 0, 0, 278, 261, 92, 34);
                           masked_blit( Quit_UL_BMP , MainMbuffer , 0, 0, 292, 306, 59, 35);        
         
                           blit(MainMbuffer, screen, 0, 0, 0, 0, SCREEN_W, SCREEN_H);
		           break;
		    case 2:
		           clear(MainMbuffer);               
                           masked_blit(MainM_BMP,MainMbuffer, 0, 0, 0, 0, SCREEN_W, SCREEN_H);
                     	                         
                           masked_blit( Play_UL_BMP , MainMbuffer , 0, 0, 287, 217, 66, 33);                      
                           masked_blit( About_L_BMP , MainMbuffer , 0, 0, 278, 261, 92, 34);
                           masked_blit( Quit_UL_BMP , MainMbuffer , 0, 0, 292, 306, 59, 35);        
         
                           blit(MainMbuffer, screen, 0, 0, 0, 0, SCREEN_W, SCREEN_H);
		           break;
		    case 3:
		           clear(MainMbuffer);               
                           masked_blit(MainM_BMP,MainMbuffer, 0, 0, 0, 0, SCREEN_W, SCREEN_H);
                     	                         
                           masked_blit( Play_UL_BMP , MainMbuffer , 0, 0, 287, 217, 66, 33);
                           masked_blit( About_UL_BMP , MainMbuffer , 0, 0, 278, 261, 92, 34);
                           masked_blit( Quit_L_BMP , MainMbuffer , 0, 0, 292, 306, 59, 35);        
         
                           blit(MainMbuffer, screen, 0, 0, 0, 0, SCREEN_W, SCREEN_H);
		           break;		    		      
		      
		 }
                   
                   
                }
                }
                else if (key[KEY_DOWN])
		  {
		   if (op!=3)
                      {
                       op++; 
		
		 switch(op)
		   {   
		    case 1: 
		           clear(MainMbuffer);               
                           masked_blit(MainM_BMP,MainMbuffer, 0, 0, 0, 0, SCREEN_W, SCREEN_H);
                     	                         
                           masked_blit( Play_L_BMP , MainMbuffer , 0, 0, 287, 217, 66, 33);                          
                           masked_blit( About_UL_BMP , MainMbuffer , 0, 0, 278, 261, 92, 34);
                           masked_blit( Quit_UL_BMP , MainMbuffer , 0, 0, 292, 306, 59, 35);        
         
                           blit(MainMbuffer, screen, 0, 0, 0, 0, SCREEN_W, SCREEN_H);
		           break;
		    case 2:
		           clear(MainMbuffer);               
                           masked_blit(MainM_BMP,MainMbuffer, 0, 0, 0, 0, SCREEN_W, SCREEN_H);
                     	                         
                           masked_blit( Play_UL_BMP , MainMbuffer , 0, 0, 287, 217, 66, 33);                           
                           masked_blit( About_L_BMP , MainMbuffer , 0, 0, 278, 261, 92, 34);
                           masked_blit( Quit_UL_BMP , MainMbuffer , 0, 0, 292, 306, 59, 35);        
         
                           blit(MainMbuffer, screen, 0, 0, 0, 0, SCREEN_W, SCREEN_H);
		           break;
		    case 3:
		           clear(MainMbuffer);               
                           masked_blit(MainM_BMP,MainMbuffer, 0, 0, 0, 0, SCREEN_W, SCREEN_H);
                     	                         
                           masked_blit( Play_UL_BMP , MainMbuffer , 0, 0, 287, 217, 66, 33);                           
                           masked_blit( About_UL_BMP , MainMbuffer , 0, 0, 278, 261, 92, 34);
                           masked_blit( Quit_L_BMP , MainMbuffer , 0, 0, 292, 306, 59, 35);        
         
                           blit(MainMbuffer, screen, 0, 0, 0, 0, SCREEN_W, SCREEN_H);
		           break;		    		   	    		      		      		      		      
		 }
		      } 
		      }
		 
          }while (!key[KEY_ENTER]);        

       /*
       destroy_bitmap(MainM_BMP);
       
       destroy_bitmap(Play_L_BMP);
       destroy_bitmap(Play_UL_BMP);
       destroy_bitmap(HighScores_L_BMP);
       destroy_bitmap(HighScores_UL_BMP);
       destroy_bitmap(Options_L_BMP);
       destroy_bitmap(Options_UL_BMP);
       destroy_bitmap(About_L_BMP);
       destroy_bitmap(About_UL_BMP);
       //destroy_bitmap(Quit_L_BMP);
       //destroy_bitmap(Quit_UL_BMP);
       
       destroy_bitmap(MainMbuffer);
       */
       if (op==1)
       play_game();
       else if (op==2)
       About_Menu();
       
       return op;

}	
void About_Menu()
{
  BITMAP *AboutM_BMP;
  
  AboutM_BMP = (BITMAP *)dat[AboutM].dat;                 
  blit(AboutM_BMP, screen, 0, 0, 0, 0, SCREEN_W, SCREEN_H);

  rest(1000);
  clear_keybuf();
  readkey(); 
}