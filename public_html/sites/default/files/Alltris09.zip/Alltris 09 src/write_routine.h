void Write_font(int X, int Y, unsigned char *Cadena)
{
 register int Index, Line, Pos;
 register int Longit=StrLen(Cadena);

 letra= (BITMAP *)dat[NiniFont].dat;          
 
 for(Index=0;Index<Longit;Index++)                   
     switch (Cadena[Index])
      {
      	case 48: //0
      	blit(letra, buffer, 0, 0,x ,y, 16 ,20 );
      	x+=16;
      	break;
      	case 49: //1
      	blit(letra, buffer, 17, 0,x ,y, 7 ,20 );
      	x+=7;
      	break;
      	case 50: //2
      	blit(letra, buffer, 25, 0,x ,y, 15 ,20 );
      	x+=15;
      	break;
      	case 51: //3
      	blit(letra, buffer, 41, 0,x ,y, 16 ,20 );
      	x+=16;
      	break;
      	case 52: //4
      	blit(letra, buffer, 58, 0,x ,y, 17 ,21 );
      	x+=17;
      	break;
      	case 53: //5
      	blit(letra, buffer, 76, 0,x ,y, 15 ,21 );
      	x+=15;
      	break;
      	case 54: //6
      	blit(letra, buffer, 92, 0,x ,y, 14 ,20 );
      	x+=14;
      	break;
      	case 55: //7
      	blit(letra, buffer, 117, 0,x ,y, 15 ,20 );
      	x+=15;
      	break;
      	case 56: //8
      	blit(letra, buffer, 123, 0,x ,y, 19 ,21 );
      	x+=19;
      	break;
      	case 57: //9
      	blit(letra, buffer, 143, 0,x ,y, 14 ,20 );
      	x+=14;
      	break;      
        default:
      	blit(letra, buffer, 0, 0,x ,y, 16 ,20 );
      	x+=16;
        break;
      }
}