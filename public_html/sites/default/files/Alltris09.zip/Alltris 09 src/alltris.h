/* Allegro datafile object indexes, produced by grabber v3.12 */
/* Datafile: c:\djgpp\alltris\alltris.dat */
/* Date: Wed Nov  7 17:38:09 2001 */
/* Do not hand edit! */

#define About_L                          0        /* BMP  */
#define About_UL                         1        /* BMP  */
#define AboutM                           2        /* BMP  */
#define Fundo                            3        /* BMP  */
#define GameOver                         4        /* BMP  */
#define MainM                            5        /* BMP  */
#define NiniFont                         6        /* BMP  */
#define p1                               7        /* BMP  */
#define p2                               8        /* BMP  */
#define p3                               9        /* BMP  */
#define p4                               10       /* BMP  */
#define p5                               11       /* BMP  */
#define p6                               12       /* BMP  */
#define p7                               13       /* BMP  */
#define Pal                              14       /* PAL  */
#define Pause                            15       /* BMP  */
#define Play_L                           16       /* BMP  */
#define Play_UL                          17       /* BMP  */
#define Quit_L                           18       /* BMP  */
#define Quit_UL                          19       /* BMP  */
#define Resume_L                         20       /* BMP  */
#define Resume_UL                        21       /* BMP  */
#define YouWin                           22       /* BMP  */

