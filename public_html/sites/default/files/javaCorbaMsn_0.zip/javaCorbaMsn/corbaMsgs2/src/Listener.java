/*
 * Listener.java
 *
 * Created on 11 de Outubro de 2007, 2:38
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

import corba.iListenerPOA;
import java.util.Vector;
/**
 * Implementa�ao da interface Listener
 * 
 * @author Luis Talento & Daniel Metelo
 */
public class Listener extends iListenerPOA {
            
    /**
     * Construtor por defeito da classe Listener
     */
    public Listener(){                
    }

    /**
     * Cria ou actualiza uma janela de conversa��o com determinada mensagem de um utilizador.
     * @param conversationUsrs utilizadores associados � conversa��o para qual a mensagem � destinada
     * @param Msg mensagem enviada pelo utilizador remoto
     */
    public void ReciveMsg(corba.UserInfo[] conversationUsrs, String Msg) {
        ChatWindow.ProcessReceivedMsg(
                Util.ArrayUserInfo2VectorUserInfo(conversationUsrs),
                Msg);
    }

    /**
     * Adiciona novos utilizadores � conversa��o
     * @param usersOnchat utilizadores actuais da conversa��o
     * @param newsUsers novos utilizadores a adicionar
     */
    public void AddNewsUsers2Conversation(corba.UserInfo[] usersOnchat, corba.UserInfo[] newsUsers) {        
        ChatWindow.AddUsers2Conversation(
                Util.ArrayUserInfo2VectorUserInfo(newsUsers),
                Util.ArrayUserInfo2VectorUserInfo(usersOnchat));
    }

    /**
     * Remove utilizadores na conversa��o
     * @param usersOnchat utilizadores presentes na actual conversa��o
     * @param delUsr utilizador a apagar
     */
    public void DelUsersInConversation(corba.UserInfo[] usersOnchat, corba.UserInfo delUsr) {
        ChatWindow.DelUserInConversation(
                delUsr,
                Util.ArrayUserInfo2VectorUserInfo(usersOnchat));
        
    }
}
