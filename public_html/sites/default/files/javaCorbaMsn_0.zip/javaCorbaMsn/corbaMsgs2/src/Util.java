import corba.UserInfo;
import java.util.Vector;
/*
 * Util.java
 *
 * Created on 12 de Novembro de 2007, 21:25
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

/**
 * Classe Util
 * @author Luis Talento & Daniel Metelo
 */
public class Util {
    
    /**
     * Construtor por defeito da classe Util
     */
    public Util() {
    }
    
    /**
     * Converte um array de UserInfo para um vector
     * @param a recebe o array a ser convertido
     * @return Vector
     */
    public static Vector<UserInfo> ArrayUserInfo2VectorUserInfo(UserInfo[] a){
        Vector<UserInfo> v = new  Vector<UserInfo>();
        for(int i=0; i<a.length; i++)
            v.add(a[i]);
        
        return v;
    }
    
    /**
     * Converte um Vector para um Array UserInfo
     * @param v vector a ser convertido
     * @return Array
     */
    public static UserInfo[] VectorUserInfo2arrayUserInfo(Vector<UserInfo> v){
        UserInfo[] a = new UserInfo[v.size()];        
        for(int i=0; i<v.size(); i++)
            a[i]=v.get(i);            
        return a;
    }
}
