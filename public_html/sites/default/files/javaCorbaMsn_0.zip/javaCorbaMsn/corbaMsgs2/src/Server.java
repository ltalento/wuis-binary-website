import corba.UserInfo;
import corba.iServer;
import corba.iServerHelper;
import corba.iServerPOA;
import org.omg.CORBA.ORB;
import org.omg.CosNaming.NameComponent;
import org.omg.CosNaming.NamingContextExt;
import org.omg.CosNaming.NamingContextExtHelper;
import org.omg.PortableServer.POA;
import org.omg.PortableServer.POAHelper;
/*
 * Server.java
 *
 * Created on 28 de Outubro de 2007, 19:57
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

/**
 * Classe de implementa��o da interface do servidor
 * @author Luis Talento & Daniel Metelo
 */
public class Server extends iServerPOA{
    /**
     * Vari�vel ORB do servidor
     */
    ORB orb  = null;
    
    /**
     * M�todo para cliente aceder remotamente e registar-se
     * @param x dados do utilizador a registar
     * @return verdadeiro se o utilizador for registado, falso se o utilizador n�o for registado
     */
    public boolean SignIn(corba.UserInfo x) {
       
        if(ServerForm.users.contains(x)) return false;
        
        ServerForm.users.add(x);
        ServerForm.UpdateApp();
        return true;
        
    }
    
    /**
     * M�todo para o cliente informar o servidor que vai sair
     * @param x dados do utilizador que vai sair
     */
    public void SignOut(corba.UserInfo x) {
        ServerForm.users.remove(x);
        ServerForm.UpdateApp();
    }
    
    /**
     * M�todo para obter a lista do utilizadores que est�o no servidor
     * @param x dados do utilizador que faz o pedido
     * @return vector com a lista dos utilizadores ligados
     */
    public corba.UserInfo[] GetUsersList(corba.UserInfo x) {
        int i = ServerForm.users.indexOf(x);
        if(i!=-1)
            ServerForm.users.get(i).setLastRequestTimeNow();
                   
            //UserInfo[] ls = new UserInfo[ServerForm.users.size()] ;
            //for(int j=0; j< ServerForm.users.size(); j++)
            //ls[j] = ServerForm.users.get(j);
            return Util.VectorUserInfo2arrayUserInfo(ServerForm.users);
        //return (corba.UserInfo[]) ServerForm.users.toArray();
    }
    
    
    /**
     * M�todo para o servidor iniciar, regista o objecto servidor no Corba
     * @param port valor do porto onde o servidor vai estar disponivel
     */
    public void Start(int port){
        try{
            
            //Localiza��o do objecto remoto
            String ip = "127.0.0.1";
            String initOrb[] = {"-ORBInitialPort" , String.valueOf(port), "-ORBInitialHost",ip };
            
            //----------------- ORB -------------------------------------
            // criar e inicializar o ORB
            orb = ORB.init(initOrb, null);
            // obtem a referencia para RootPOA e activa o  POAManager
            POA rootpoa = POAHelper.narrow(orb.resolve_initial_references("RootPOA"));
            rootpoa.the_POAManager().activate();
            //------------------- OBJECTO REMOTO ----------------------------------
            //  regista object no ORB
            // referencia corba do objecto
            org.omg.CORBA.Object ref = rootpoa.servant_to_reference(this);
            // referencia remota do objecto
            iServer href = iServerHelper.narrow(ref);
            //--------------------- REGISTO NO SERVIDOR DE NOMES -------------
           //servidor de nomes
            org.omg.CORBA.Object objRef =
                    orb.resolve_initial_references("NameService");          
            NamingContextExt ncRef = NamingContextExtHelper.narrow(objRef);            
            //nome remoto da interface
            String name = "Server";
            NameComponent path[] = ncRef.to_name( name );
            //colocar a interface remota no servidor de nomes
            ncRef.rebind(path, href);
            
            System.out.println("Server ready and waiting ...");            
            //----------------- ESPERA POR CLIENTES ------------------------
            orb.run();
        }
        
        catch (Exception e) {
            System.err.println("ERROR: " + e);
            e.printStackTrace(System.out);
        }

    }
    
    /**
     * M�todo para desregistar o objecto servidor do Corba
     */
    public void Stop(){
        orb.shutdown(false);
         System.out.println("Server shutdown"); 
    }
    
    
}
