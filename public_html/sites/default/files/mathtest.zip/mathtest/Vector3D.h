#ifndef VECTOR3D_H
#define VECTOR3D_H

class Vector3D
{
private:
	
	float x, y, z;
	
	friend class Matrix33;
	friend class Matrix44;

public:
 	//constructores
  	Vector3D();
  	Vector3D(const Vector3D &other);
  	Vector3D(const float *v);
  	Vector3D(const float &x, const float &y, const float &z);
  	
  	//destrutor
	~Vector3D();
 	
 	//Modificadores
 	void Zero();
 	void SetX(const float &x);
 	void SetY(const float &y);
 	void SetZ(const float &z);
 	void Set(const float &x, const float &y, const float &z);
 	void Normalize();
 	
 	//selectores
 	const float GetX() const;
 	const float GetY() const;
 	const float GetZ() const;
	const float* Get() const;
   	const float Length() const;
 
  	//outros m�todos
  	const float Dot(const Vector3D &v) const;
  	const Vector3D Cross(const Vector3D &v) const;
  		
  		//equal within an error 'e'
	const bool NearlyEquals(const Vector3D &v, const float &e) const;

	// compute the reflected vector R of L w.r.t N - vectors need to be 
	// normalized
	//
	//                R     N     L
	//                  _       _
	//                 |\   ^   /|
	//                   \  |  /
	//                    \ | /
	//                     \|/
	//                      +
	const Vector3D Reflect(const Vector3D &n);



  	//operadores
	const float operator[] (const int &index) const;
	
	const Vector3D operator - () const;

	const Vector3D& operator += (const Vector3D &v);
	const Vector3D& operator -= (const Vector3D &v);
	const Vector3D& operator *= (const Vector3D &v);
	const Vector3D& operator /= (const Vector3D &v);
	
	const Vector3D& operator *= (const float &s);
	const Vector3D& operator /= (const float &s);
	
    	const Vector3D operator + (const Vector3D &v) const;
	const Vector3D operator - (const Vector3D &v) const;
	const Vector3D operator * (const Vector3D &v) const;
	const Vector3D operator / (const Vector3D &v) const;
	
	const Vector3D operator * (const float &s) const;
	const Vector3D operator / (const float &s) const;
     
    	const bool operator == (const Vector3D &v) const;
    	const bool operator != (const Vector3D& v ) const;

};

#endif