#include "Vector3D.h"

#include <math.h>



//constructores
Vector3D::Vector3D(): x(0), y(0), z(0)
{}

//-----------------------------------------------------------

Vector3D::Vector3D(const Vector3D &other):  x(other.x), y(other.y), z(other.z)
{}

//-----------------------------------------------------------	

Vector3D::Vector3D(const float *v)
{
	x=v[0]; y=v[1]; z=v[2];
}

//-----------------------------------------------------------

Vector3D::Vector3D(const float &x, const float &y, const float &z)
: x(x), y(y), z(z)
{}

//-----------------------------------------------------------

//destrutor
Vector3D::~Vector3D()
{}

//-----------------------------------------------------------
//-----------------------------------------------------------
 	
//Modificadores
void Vector3D::Zero()
{
	x=0; y=0; z=0;
}

//-----------------------------------------------------------

void Vector3D::SetX(const float &x)
{
	this->x=x;	
}

//-----------------------------------------------------------

void Vector3D::SetY(const float &y)
{
	this->y=y;
}

//-----------------------------------------------------------

void Vector3D::SetZ(const float &z)
{
	this->z=z;
}

//-----------------------------------------------------------

void Vector3D::Set(const float &x, const float &y, const float &z)
{
	this->x=x; this->y=y; this->z=z;
}

//-----------------------------------------------------------

void Vector3D::Normalize()
{
	(*this) /= this->Length();
}

//-----------------------------------------------------------
//-----------------------------------------------------------
 	
//selectores
const float Vector3D::GetX() const
{
	return x;
}
const float Vector3D::GetY() const
{
	return y;
}
const float Vector3D::GetZ() const
{
	return z;
}
const float* Vector3D::Get() const
{
	return &x;
}
const float Vector3D::Length() const
{
	return (float)sqrt( (double)this->Dot(*this) );
}
 
//outros m�todos
const float Vector3D::Dot(const Vector3D &v) const
{
	return x*v.x + y*v.y + z*v.z;	
}
const Vector3D Vector3D::Cross(const Vector3D &v) const
{
	return Vector3D( y*v.z - z*v.y, z*v.x - x*v.z, x*v.y - y*v.x );	
}
  		
  		//equal within an error 'e'
const bool Vector3D::NearlyEquals(const Vector3D &v, const float &e) const
{
	return fabs(x-v.x)<e && fabs(y-v.y)<e && fabs(z-v.z)<e;	
}

const Vector3D Vector3D::Reflect(const Vector3D &n)
{
  float n_dot_l = 2 * n.Dot(*this);

  Vector3D r = (*this) * -1;

  r = n * n_dot_l + r;

  return Vector3D(r);
}

//-----------------------------------------------------------
//-----------------------------------------------------------

//operadores
const float Vector3D::operator[] (const int &index) const
{
	return *((&x) + index);
}
	
const Vector3D Vector3D::operator - () const
{
	return Vector3D( -x, -y, -z );
}

//-----------------------------------------------------------
//-----------------------------------------------------------

const Vector3D& Vector3D::operator += (const Vector3D &v)
{
	x+= v.x; y+= v.y; z+= v.z; 
	return *this;	
}

//-----------------------------------------------------------

const Vector3D& Vector3D::operator -= (const Vector3D &v)
{
	x-= v.x; y-= v.y; z-= v.z; 
	return *this;
}

//-----------------------------------------------------------

const Vector3D& Vector3D::operator *= (const Vector3D &v)
{
	x*= v.x; y*= v.y; z*= v.z; 
	return *this;
}

//-----------------------------------------------------------

const Vector3D& Vector3D::operator /= (const Vector3D &v)
{
	x/= v.x; y/= v.y; z/= v.z;
	return *this;
}
	
//-----------------------------------------------------------

const Vector3D& Vector3D::operator *= (const float &s)
{
	x*= s; y*= s; z*= s;
	return *this;
}
//-----------------------------------------------------------

const Vector3D& Vector3D::operator /= (const float &s)
{
	x/= s; y/= s; z/= s;
	return *this;
}

//-----------------------------------------------------------
//-----------------------------------------------------------

const Vector3D Vector3D::operator + (const Vector3D &v) const
{
	return Vector3D(x+v.x, y+v.y , z+v.z);	
}

//-----------------------------------------------------------

const Vector3D Vector3D::operator - (const Vector3D &v) const
{
	return Vector3D(x-v.x, y-v.y , z-v.z);	
}

//-----------------------------------------------------------

const Vector3D Vector3D::operator * (const Vector3D &v) const
{
	return Vector3D(x*v.x, y*v.y , z*v.z);		
}

//-----------------------------------------------------------

const Vector3D Vector3D::operator / (const Vector3D &v) const
{
	return Vector3D(x/v.x, y/v.y , z/v.z);	
}

//-----------------------------------------------------------
	
const Vector3D Vector3D::operator * (const float &s) const
{
	return Vector3D(x*s,y*s,z*s);
}

//-----------------------------------------------------------

const Vector3D Vector3D::operator / (const float &s) const
{
	return Vector3D(x/s,y/s,z/s);
}

//-----------------------------------------------------------
//-----------------------------------------------------------
     
const bool Vector3D::operator == (const Vector3D &v) const
{
	return (v.x==x && v.y==y && v.z==z);
}

//-----------------------------------------------------------

const bool Vector3D::operator != (const Vector3D &v ) const
{
	return !(v == *this);
}