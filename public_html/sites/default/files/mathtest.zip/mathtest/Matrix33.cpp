#include "Matrix33.h"
#include "Vector3D.h"
//#include "Quaternion.h"

#include <math.h>
#include <memory.h>

Matrix33::Matrix33()
{
	Identify();	
}

//-----------------------------------------------------------

Matrix33::Matrix33(const float *m)
{
	memcpy(mat, m, sizeof(float)*9);	
}

//-----------------------------------------------------------

Matrix33::Matrix33(const Matrix33 &other)
{
	memcpy(mat, other.mat, sizeof(float)*9);
}

//-----------------------------------------------------------

Matrix33::~Matrix33()
{}

//-----------------------------------------------------------
//-----------------------------------------------------------
 
void  Matrix33::SetRow(const int &row, const Vector3D &v)
{	
	mat[row  ]=v[0];//=mat[row + 0*3 ]=v[0];
	mat[row+3]=v[1];//=mat[row + 1*3 ]=v[0];
	mat[row+6]=v[2];//=mat[row + 2*3 ]=v[0];
}

//-----------------------------------------------------------

void  Matrix33::SetCol(const int &col, const Vector3D &v)
{
	mat[    col*3 ]=v[0];
	mat[1 + col*3 ]=v[1];
	mat[2 + col*3 ]=v[2];
}

//-----------------------------------------------------------

void  Matrix33::Set(const int &row, const int &col, const float &v)
{
	mat[ row + col*3 ]=v;
}
	
//-----------------------------------------------------------
//-----------------------------------------------------------
 
const float* Matrix33::Get() const
{
	return mat;
}

//-----------------------------------------------------------

const Vector3D Matrix33::GetRow(const int &row) const
{
	return Vector3D(mat[row ], mat[row+3], mat[row+6]);	
}

//-----------------------------------------------------------

const Vector3D Matrix33::GetCol(const int &col) const
{
	return Vector3D(mat[col*3], mat[1+col*3], mat[2+col*3]);	
}

//-----------------------------------------------------------
//-----------------------------------------------------------
 	
void Matrix33::Identify()
{
	mat[0]=1; mat[3]=0; mat[6]=0;
	mat[1]=0; mat[4]=1; mat[7]=0;
	mat[2]=0; mat[5]=0; mat[8]=1;
}

//-----------------------------------------------------------
	
void Matrix33::Transpose()
{
	Matrix33 tmp(*this);
    
	mat[0] = tmp.mat[0];    	
	mat[1] = tmp.mat[3];
	mat[2] = tmp.mat[6];
	mat[3] = tmp.mat[1];    	
	mat[4] = tmp.mat[4];
	mat[5] = tmp.mat[7];
	mat[6] = tmp.mat[2];
	mat[7] = tmp.mat[5];
	mat[8] = tmp.mat[8];
     	
}	

//-----------------------------------------------------------

void Matrix33::Invert()
{
    	float det, oodet;
	Matrix33 tmp;
	
    	tmp.mat[0] =  (mat[4] * mat[8] - mat[5] * mat[7]);
    	tmp.mat[1] = -(mat[1] * mat[8] - mat[2] * mat[7]);
    	tmp.mat[2] =  (mat[1] * mat[5] - mat[2] * mat[4]);
    	
		tmp.mat[3] = -(mat[3] * mat[8] - mat[5] * mat[6]);
    	tmp.mat[4] =  (mat[0] * mat[8] - mat[2] * mat[6]);
    	tmp.mat[5] = -(mat[0] * mat[5] - mat[2] * mat[3]);
    	
		tmp.mat[6] =  (mat[3] * mat[7] - mat[4] * mat[6]);
    	tmp.mat[7] = -(mat[0] * mat[7] - mat[1] * mat[6]);
    	tmp.mat[8] =  (mat[0] * mat[4] - mat[1] * mat[3]);

    	det = (mat[0] * tmp.mat[0]) 
		+ (mat[3] * tmp.mat[1]) + (mat[6] * tmp.mat[2]);
    
    	oodet = 1 / det;


	tmp*=oodet;
    
  
	*this=tmp;

}

//-----------------------------------------------------------

void Matrix33::RotationX(const float &radians)
{
	float s = (float)sin(radians);
	float c = (float)cos(radians);
	mat[0] = 1.0f; mat[3] = 0.0f; mat[6] = 0.0f;
	mat[1] = 0.0f; mat[4] =    c; mat[7] =   -s;
	mat[2] = 0.0f; mat[5] =    s; mat[8] =    c;
}

//-----------------------------------------------------------

void Matrix33::RotationY(const float &radians)
{
	float s = (float)sin(radians);
	float c = (float)cos(radians);
	mat[0] =    c; mat[3] = 0.0f; mat[6] =    s;	
	mat[1] = 0.0f; mat[4] = 1.0f; mat[7] = 0.0f;	
	mat[2] =   -s; mat[5] = 0.0f; mat[8] =    c;
}

//-----------------------------------------------------------

void Matrix33::RotationZ(const float &radians)
{
	float s = (float)sin(radians);
	float c = (float)cos(radians);
	mat[0] =    c; mat[3] =   -s; mat[6] = 0.0f;
	mat[1] =    s; mat[4] =    c; mat[7] = 0.0f;
	mat[2] = 0.0f; mat[5] = 0.0f; mat[8] = 1.0f;
}

//-----------------------------------------------------------

void Matrix33::RotationAxis(const float &radians, const Vector3D &axis)
{
	float s = (float)sin(radians);
	float c = (float)cos(radians);

//	axis.Normalize();

  	// optimize
	float invcos = 1.0f - c; // or (1- c) in the formula
	float xs = axis[0] * s;
	float ys = axis[1] * s;
	float zs = axis[2] * s;

  	// store matrix already transposed
	mat[0] = (axis[0] * axis[0]) * invcos + c;
  	mat[1] = (axis[0] * axis[1]) * invcos + zs;
  	mat[2] = (axis[2] * axis[0]) * invcos - ys;
  
  	mat[3] = (axis[0] * axis[1]) * invcos - zs;
  	mat[4] = (axis[1] * axis[1]) * invcos + c;
  	mat[5] = (axis[1] * axis[2]) * invcos + xs;
  
	mat[6] = (axis[2] * axis[0]) * invcos + ys;
  	mat[7] = (axis[1] * axis[2]) * invcos - xs;
  	mat[8] = (axis[2] * axis[2]) * invcos + c;	
}

//-----------------------------------------------------------
	
	//Make a rotation matrix from Euler angles
void Matrix33::Rotation(const Vector3D &angles_rad)
{
	float cr = (float)cos(angles_rad[0]);
	float sr = (float)sin(angles_rad[0]);
	float cp = (float)cos(angles_rad[1]);
	float sp = (float)sin(angles_rad[1]);
	float cy = (float)cos(angles_rad[2]);
	float sy = (float)sin(angles_rad[2]);

	mat[0] = cp*cy;
	mat[1] = cp*sy;
	mat[2] = -sp;

	float srsp = sr*sp;
	float crsp = cr*sp;

	mat[3] = srsp*cy-cr*sy;
	mat[4] = srsp*sy+cr*cy;
	mat[5] = sr*cp;

	mat[6] = crsp*cy+sr*sy;
	mat[7] = crsp*sy-sr*cy;
	mat[8] = cr*cp;
}


//-----------------------------------------------------------
/*
	//Make a rotation matrix from a quaternion.
void Matrix33::RotationQuaternion(const Quaternion& quat);
{
	m_matrix[0] = ( float )( 1.0 - 2.0*quat[1]*quat[1] - 2.0*quat[2]*quat[2] );
	m_matrix[1] = ( float )( 2.0*quat[0]*quat[1] + 2.0*quat[3]*quat[2] );
	m_matrix[2] = ( float )( 2.0*quat[0]*quat[2] - 2.0*quat[3]*quat[1] );

	m_matrix[4] = ( float )( 2.0*quat[0]*quat[1] - 2.0*quat[3]*quat[2] );
	m_matrix[5] = ( float )( 1.0 - 2.0*quat[0]*quat[0] - 2.0*quat[2]*quat[2] );
	m_matrix[6] = ( float )( 2.0*quat[1]*quat[2] + 2.0*quat[3]*quat[0] );

	m_matrix[8] = ( float )( 2.0*quat[0]*quat[2] + 2.0*quat[3]*quat[1] );
	m_matrix[9] = ( float )( 2.0*quat[1]*quat[2] - 2.0*quat[3]*quat[0] );
	m_matrix[10] = ( float )( 1.0 - 2.0*quat[0]*quat[0] - 2.0*quat[1]*quat[1] );
}
*/
//-----------------------------------------------------------
//-----------------------------------------------------------
 
const float Matrix33::operator () (const int &row, const int &col) const
{
	return mat[row + col*3];
}

//-----------------------------------------------------------
//-----------------------------------------------------------
 		
const Matrix33& Matrix33::operator += (const Matrix33 &m)
{
	mat[0]+=m.mat[0];
	mat[1]+=m.mat[1];
	mat[2]+=m.mat[2];
    
	mat[3]+=m.mat[3];
	mat[4]+=m.mat[4];
	mat[5]+=m.mat[5];
    
	mat[6]+=m.mat[6];
	mat[7]+=m.mat[7];
	mat[8]+=m.mat[8];
	
	return *this;
 
}

const Matrix33& Matrix33::operator -= (const Matrix33 &m)
{
	mat[0]-=m.mat[0];
	mat[1]-=m.mat[1];
	mat[2]-=m.mat[2];
    
	mat[3]-=m.mat[3];
	mat[4]-=m.mat[4];
	mat[5]-=m.mat[5];

	mat[6]-=m.mat[6];
	mat[7]-=m.mat[7];
	mat[8]-=m.mat[8];
	
	return *this;	
}

//-----------------------------------------------------------

const Matrix33& Matrix33::operator *= (const Matrix33 &m)
{
	(*this) = (*this) * m;
	
	
	return *this;
}

//-----------------------------------------------------------

const Matrix33& Matrix33::operator *= (const float &s)
{
	
	mat[0]*=s;
	mat[1]*=s;
	mat[2]*=s;
    
	mat[3]*=s;
	mat[4]*=s;
	mat[5]*=s;
    
	mat[6]*=s;
	mat[7]*=s;
	mat[8]*=s;
	
	return *this;
}
	
//-----------------------------------------------------------
//-----------------------------------------------------------
 
const Matrix33 Matrix33::operator + (const Matrix33 &m) const
{
	Matrix33 tmp;
	
	tmp.mat[0]=mat[0]+m.mat[0];
	tmp.mat[0]=mat[1]+m.mat[1];
	tmp.mat[0]=mat[2]+m.mat[2];
    
	tmp.mat[3]=mat[3]+m.mat[3];
	tmp.mat[4]=mat[4]+m.mat[4];
	tmp.mat[5]=mat[5]+m.mat[5];

	tmp.mat[6]=mat[6]+m.mat[6];
	tmp.mat[7]=mat[7]+m.mat[7];
	tmp.mat[8]=mat[8]+m.mat[8];
	
	return tmp;
}

//-----------------------------------------------------------

const Matrix33 Matrix33::operator - (const Matrix33 &m) const
{
	Matrix33 tmp;
	
	tmp.mat[0]=mat[0]-m.mat[0];
	tmp.mat[1]=mat[1]-m.mat[1];
	tmp.mat[2]=mat[2]-m.mat[2];
    
	tmp.mat[3]=mat[3]-m.mat[3];
	tmp.mat[4]=mat[4]-m.mat[4];
	tmp.mat[5]=mat[5]-m.mat[5];
    
	tmp.mat[6]=mat[6]-m.mat[6];
	tmp.mat[7]=mat[7]-m.mat[7];
	tmp.mat[8]=mat[8]-m.mat[8];
	
	return tmp;	
}

//-----------------------------------------------------------

const Matrix33 Matrix33::operator * (const Matrix33 &m) const
{
	Matrix33 tmp;
	
	tmp.mat[0] = (mat[0]* m.mat[0])+ (mat[3]* m.mat[1])+ (mat[6]* m.mat[2]);
	tmp.mat[3] = (mat[0]* m.mat[3])+ (mat[3]* m.mat[4])+ (mat[6]* m.mat[5]);
	tmp.mat[6] = (mat[0]* m.mat[6])+ (mat[3]* m.mat[7])+ (mat[6]* m.mat[8]);
	
	tmp.mat[1] = (mat[1]* m.mat[0])+ (mat[4]* m.mat[1])+ (mat[7]* m.mat[2]);
	tmp.mat[4] = (mat[1]* m.mat[3])+ (mat[4]* m.mat[4])+ (mat[7]* m.mat[5]);
	tmp.mat[7] = (mat[1]* m.mat[6])+ (mat[4]* m.mat[7])+ (mat[7]* m.mat[8]);
	
	tmp.mat[2] = (mat[2]* m.mat[0])+ (mat[5]* m.mat[1])+ (mat[8]* m.mat[2]);
	tmp.mat[5] = (mat[2]* m.mat[3])+ (mat[5]* m.mat[4])+ (mat[8]* m.mat[5]);
	tmp.mat[8] = (mat[2]* m.mat[6])+ (mat[5]* m.mat[7])+ (mat[8]* m.mat[8]);
	
	return tmp;
}

//-----------------------------------------------------------

const Matrix33 Matrix33::operator * (const float &s) const
{
	Matrix33 tmp;
		
	tmp.mat[0]=mat[0]*s;
	tmp.mat[1]=mat[1]*s;
	tmp.mat[2]=mat[2]*s;
    
	tmp.mat[3]=mat[3]*s;
	tmp.mat[4]=mat[4]*s;
	tmp.mat[5]=mat[5]*s;
    
	tmp.mat[6]=mat[6]*s;
	tmp.mat[7]=mat[7]*s;
	tmp.mat[8]=mat[8]*s;
	
	return tmp;
}

//-----------------------------------------------------------
		
const Vector3D  Matrix33::operator * (const Vector3D &v) const
{
  	Vector3D tmp;
  	
	//v'=m*v
	tmp.x= (mat[0]*v.x)+ (mat[3]*v.y)+ (mat[6]*v.z);	
	tmp.y= (mat[1]*v.x)+ (mat[4]*v.y)+ (mat[7]*v.z);
  	tmp.z= (mat[2]*v.x)+ (mat[5]*v.y)+ (mat[8]*v.z);

	return tmp;
}

//-----------------------------------------------------------
//-----------------------------------------------------------
    	
const bool Matrix33::operator == (const Matrix33 &m) const
{
	return (mat[0]==m.mat[0] && mat[3]==m.mat[3] && mat[6]==m.mat[6] &&
			mat[1]==m.mat[1] && mat[4]==m.mat[4] && mat[7]==m.mat[7] &&
			mat[2]==m.mat[2] && mat[5]==m.mat[5] && mat[8]==m.mat[8]); 
}
//-----------------------------------------------------------

const bool Matrix33::operator != (const Matrix33 &m) const
{
	return !(*this==m);
}
