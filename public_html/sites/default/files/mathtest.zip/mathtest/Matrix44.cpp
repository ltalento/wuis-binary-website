#include "Matrix44.h"
#include "Vector3D.h"
#include "Matrix33.h"

#include <math.h>
#include <memory.h>



Matrix44::Matrix44()
{
	Identify();		
}

//-----------------------------------------------------------

Matrix44::Matrix44(const float *m)
{
	memcpy(mat, m, sizeof(float)*16);
}

//-----------------------------------------------------------

Matrix44::Matrix44(const Matrix33 &m, const Vector3D &v)
{
	Identify();
	SetRotation(m);
	SetTranslate(v);

}

//-----------------------------------------------------------

Matrix44::Matrix44(const Matrix44 &other)
{
	memcpy(mat, other.mat, sizeof(float)*16);	
}

//-----------------------------------------------------------
	
Matrix44::~Matrix44()
{
	
}
	
//-----------------------------------------------------------
//-----------------------------------------------------------
	
const float* Matrix44::Get() const
{
	return mat;	
}

//-----------------------------------------------------------

const Matrix33 Matrix44::GetRotation() const
{
	Matrix33 tmp;
	tmp.mat[0]=mat[0];tmp.mat[3]=mat[4];tmp.mat[6]=mat[ 8];
	tmp.mat[1]=mat[1];tmp.mat[4]=mat[5];tmp.mat[7]=mat[ 9];
	tmp.mat[2]=mat[2];tmp.mat[5]=mat[6];tmp.mat[8]=mat[10];
	return tmp;
}

//-----------------------------------------------------------

const Vector3D Matrix44::GetScale() const
{
	Vector3D x, y, z;
	
	x.Set(mat[0],mat[1],mat[ 2]); 
	y.Set(mat[4],mat[5],mat[ 6]); 
	z.Set(mat[8],mat[9],mat[10]); 
	

	return Vector3D( x.Length(), y.Length(), z.Length());		
}

//-----------------------------------------------------------

const Vector3D Matrix44::GetTranslate() const
{
	return Vector3D( mat[12],mat[13],mat[14]);	
}
	
//-----------------------------------------------------------
//-----------------------------------------------------------
	
void Matrix44::Set(const int &row, const int &col, const float &v)
{
	mat[row+col*4]=v;
}

//-----------------------------------------------------------

void Matrix44::SetRotation(const Matrix33 &m)
{	
	mat[0]=m.mat[0]; mat[4]=m.mat[3]; mat[ 8]=m.mat[6];
	mat[1]=m.mat[1]; mat[5]=m.mat[4]; mat[ 9]=m.mat[7];
	mat[2]=m.mat[2]; mat[6]=m.mat[5]; mat[10]=m.mat[8];
}

//-----------------------------------------------------------

void Matrix44::SetScale(const Vector3D &v)
{
	mat[ 0] = v.x; mat[ 4] = 0.0; mat[ 8] = 0.0; //mat[12] = 0.0;
	mat[ 1] = 0.0; mat[ 5] = v.y; mat[ 9] =	0.0; //mat[13] = 0.0;
	mat[ 2] = 0.0; mat[ 6] = 0.0; mat[10] = v.z; //mat[14] = 0.0;
	//mat[ 3] = 0.0; mat[ 7] = 0.0; mat[11] = 0.0; mat[15] = 1.0;
}

//-----------------------------------------------------------

void Matrix44::Scale(const Vector3D &v)
{
	mat[ 0] *= v.x;	mat[ 4] *= v.y; mat[ 8] *= v.z;
	mat[ 1] *= v.x; mat[ 5] *= v.y; mat[ 9] *= v.z;
	mat[ 2] *= v.x;	mat[ 6] *= v.y;	mat[10] *= v.z;
	
}
//-----------------------------------------------------------

void Matrix44::SetTranslate(const Vector3D &v)
{	
	/*mat[ 0] = 1.0; mat[ 4] = 0.0; mat[ 8] = 0.0;*/ mat[12] = v.x;
	/*mat[ 1] = 0.0; mat[ 5] = 1.0; mat[ 9] = 0.0;*/ mat[13] = v.y;
	/*mat[ 2] = 0.0; mat[ 6] = 0.0; mat[10] = 1.0;*/ mat[14] = v.z;
	//mat[ 3] = 0.0; mat[ 7] = 0.0; mat[11] = 0.0; mat[15] = 1.0;
}

//-----------------------------------------------------------

void Matrix44::Translate(const Vector3D &v)
{
	mat[12]+= v.x;
	mat[13]+= v.y;
	mat[14]+= v.z;
}

//-----------------------------------------------------------
//-----------------------------------------------------------	
	
void Matrix44::Identify()
{
	mat[0]=1; mat[4]=0; mat[ 8]=0; mat[12]=0;
	mat[1]=0; mat[5]=1; mat[ 9]=0; mat[13]=0;
	mat[2]=0; mat[6]=0; mat[10]=1; mat[14]=0;
	mat[3]=0; mat[7]=0; mat[11]=0; mat[15]=1;	
}

//-----------------------------------------------------------

void Matrix44::Transpose()
{
	Matrix44 tmp(*this);
	
    	mat[ 0] = tmp.mat[ 0];
    	mat[ 1] = tmp.mat[ 4];
    	mat[ 2] = tmp.mat[ 8];
    	mat[ 3] = tmp.mat[12]; 	
    	
    	mat[ 4] = tmp.mat[ 1];
    	mat[ 5] = tmp.mat[ 5];
    	mat[ 6] = tmp.mat[ 9]; 	
    	mat[ 7] = tmp.mat[13]; 	
    	
    	mat[ 8] = tmp.mat[ 2];
    	mat[ 9] = tmp.mat[ 6];
    	mat[10] = tmp.mat[10];
    	mat[11] = tmp.mat[14];
    	
    	mat[12] = tmp.mat[ 3];
    	mat[13] = tmp.mat[ 7];
    	mat[14] = tmp.mat[11];
    	mat[15] = tmp.mat[15];
    	
 	
}

//-----------------------------------------------------------

inline float Matrix44::det2x2(float a1, float a2, float b1, float b2)
{
    return a1 * b2 - b1 * a2;
}

inline float Matrix44::det3x3(float a1, float a2, float a3, 
                    float b1, float b2, float b3, 
                    float c1, float c2, float c3)
{
    return a1 * det2x2(b2, b3, c2, c3) - b1 * det2x2(a2, a3, c2, c3) + c1 * det2x2(a2, a3, b2, b3);
}

void Matrix44::Invert()
{	
	Matrix44 tmp;
	float det,oodet;

	tmp.mat[ 0] =  det3x3(mat[5], mat[6], mat[7], mat[9], mat[10], mat[11], mat[13], mat[14], mat[15]);
    tmp.mat[ 1] = -det3x3(mat[1], mat[2], mat[3], mat[9], mat[10], mat[11], mat[13], mat[14], mat[15]);
    tmp.mat[ 2] =  det3x3(mat[1], mat[2], mat[3], mat[5], mat[ 6], mat[ 7], mat[13], mat[14], mat[15]);
    tmp.mat[ 3] = -det3x3(mat[1], mat[2], mat[3], mat[5], mat[ 6], mat[ 7], mat[ 9], mat[10], mat[11]);

    tmp.mat[ 4] = -det3x3(mat[4], mat[6], mat[7], mat[8], mat[10], mat[11], mat[12], mat[14], mat[15]);
    tmp.mat[ 5] =  det3x3(mat[0], mat[2], mat[3], mat[8], mat[10], mat[11], mat[12], mat[14], mat[15]);
    tmp.mat[ 6] = -det3x3(mat[0], mat[2], mat[3], mat[4], mat[ 6], mat[ 7], mat[12], mat[14], mat[15]);
    tmp.mat[ 7] =  det3x3(mat[0], mat[2], mat[3], mat[4], mat[ 6], mat[ 7], mat[ 8], mat[10], mat[11]);

    tmp.mat[ 8] =  det3x3(mat[4], mat[5], mat[7], mat[8], mat[ 9], mat[11], mat[12], mat[13], mat[15]);
    tmp.mat[ 9] = -det3x3(mat[0], mat[1], mat[3], mat[8], mat[ 9], mat[11], mat[12], mat[13], mat[15]);
    tmp.mat[10] =  det3x3(mat[0], mat[1], mat[3], mat[4], mat[ 5], mat[ 7], mat[12], mat[13], mat[15]);
    tmp.mat[11] = -det3x3(mat[0], mat[1], mat[3], mat[4], mat[ 5], mat[ 7], mat[ 8], mat[ 9], mat[11]);

    tmp.mat[12] = -det3x3(mat[4], mat[5], mat[6], mat[8], mat[ 9], mat[10], mat[12], mat[13], mat[14]);
    tmp.mat[13] =  det3x3(mat[0], mat[1], mat[2], mat[8], mat[ 9], mat[10], mat[12], mat[13], mat[14]);
    tmp.mat[14] = -det3x3(mat[0], mat[1], mat[2], mat[4], mat[ 5], mat[ 6], mat[12], mat[13], mat[14]);
    tmp.mat[15] =  det3x3(mat[0], mat[1], mat[2], mat[4], mat[ 5], mat[ 6], mat[ 8], mat[ 9], mat[10]);

	det = mat[0]*tmp.mat[0] + mat[4]*tmp.mat[1] + mat[8]*tmp.mat[2] + mat[12]*tmp.mat[3];

	oodet = 1 / det;

	tmp *= oodet;
	
	*this=tmp;
}

//-----------------------------------------------------------
//-----------------------------------------------------------	

const float Matrix44::operator () (const int &row, const int &col) const
{
	return mat[row+col*4];
}

//-----------------------------------------------------------			

const Matrix44& Matrix44::operator += (const Matrix44 &m)
{
	mat[ 0]+=m.mat[ 0];
	mat[ 1]+=m.mat[ 1];
	mat[ 2]+=m.mat[ 2];
    mat[ 3]+=m.mat[ 3];
	
	mat[ 4]+=m.mat[ 4];
	mat[ 5]+=m.mat[ 5];
	mat[ 6]+=m.mat[ 6];
	mat[ 7]+=m.mat[ 7];
	
	mat[ 8]+=m.mat[ 8];
	mat[ 9]+=m.mat[ 9];
	mat[10]+=m.mat[10];
	mat[11]+=m.mat[11];
	
	mat[12]+=m.mat[12];
	mat[13]+=m.mat[13];
	mat[14]+=m.mat[14];
	mat[15]+=m.mat[15];
	
	return *this;
}

//-----------------------------------------------------------

const Matrix44& Matrix44::operator -= (const Matrix44 &m)
{
	mat[ 0]-=m.mat[ 0];
	mat[ 1]-=m.mat[ 1];
	mat[ 2]-=m.mat[ 2];
	mat[ 3]-=m.mat[ 3];
	
	mat[ 4]-=m.mat[ 4];
	mat[ 5]-=m.mat[ 5];
	mat[ 6]-=m.mat[ 6];
	mat[ 7]-=m.mat[ 7];
	
	mat[ 8]-=m.mat[ 8];
	mat[ 9]-=m.mat[ 9];
	mat[10]-=m.mat[10];
	mat[11]-=m.mat[11];
	
	mat[12]-=m.mat[12];
	mat[13]-=m.mat[13];
	mat[14]-=m.mat[14];
	mat[15]-=m.mat[15];
	
	return *this;	
}

//-----------------------------------------------------------

const Matrix44& Matrix44::operator *= (const Matrix44 &m)
{
	(*this) = (*this) * m;
	
	
	return *this;
}

//-----------------------------------------------------------

const Matrix44& Matrix44::operator *= (const float &s)
{
	mat[ 0]*=s;
	mat[ 1]*=s;
	mat[ 2]*=s;
	mat[ 3]*=s;
	
	mat[ 4]*=s;
	mat[ 5]*=s;
	mat[ 6]*=s;
	mat[ 7]*=s;
	
	mat[ 8]*=s;
	mat[ 9]*=s;
	mat[10]*=s;
	mat[11]*=s;
	
	mat[12]*=s;
	mat[13]*=s;
	mat[14]*=s;
	mat[15]*=s;
	
	return *this;	
}
	
//-----------------------------------------------------------
//-----------------------------------------------------------
		
const Matrix44 Matrix44::operator + (const Matrix44 &m) const
{
	Matrix44 tmp;
	
	tmp.mat[0]=mat[0]+m.mat[0];
	tmp.mat[1]=mat[1]+m.mat[1];
	tmp.mat[2]=mat[2]+m.mat[2];
	tmp.mat[3]=mat[3]+m.mat[3];
	
	tmp.mat[4]=mat[4]+m.mat[4];
	tmp.mat[5]=mat[5]+m.mat[5];
	tmp.mat[6]=mat[6]+m.mat[6];
	tmp.mat[7]=mat[7]+m.mat[7];
	
	tmp.mat[ 8]=mat[ 8]+m.mat[ 8];
	tmp.mat[ 9]=mat[ 9]+m.mat[ 9];
	tmp.mat[10]=mat[10]+m.mat[10];
	tmp.mat[11]=mat[11]+m.mat[11];
	
	tmp.mat[12]=mat[12]+m.mat[12];
	tmp.mat[13]=mat[13]+m.mat[13];
	tmp.mat[14]=mat[14]+m.mat[14];
	tmp.mat[15]=mat[15]+m.mat[15];
	
	return tmp;		
}

//-----------------------------------------------------------

const Matrix44 Matrix44::operator - (const Matrix44 &m) const
{
	Matrix44 tmp;
	
	tmp.mat[0]=mat[0]-m.mat[0];
	tmp.mat[1]=mat[1]-m.mat[1];
	tmp.mat[2]=mat[2]-m.mat[2];
	tmp.mat[3]=mat[3]-m.mat[3];
	
	tmp.mat[4]=mat[4]-m.mat[4];
	tmp.mat[5]=mat[5]-m.mat[5];
	tmp.mat[6]=mat[6]-m.mat[6];
	tmp.mat[7]=mat[7]-m.mat[7];
	
	tmp.mat[ 8]=mat[ 8]-m.mat[ 8];
	tmp.mat[ 9]=mat[ 9]-m.mat[ 9];
	tmp.mat[10]=mat[10]-m.mat[10];
	tmp.mat[11]=mat[11]-m.mat[11];
	
	tmp.mat[12]=mat[12]-m.mat[12];
	tmp.mat[13]=mat[13]-m.mat[13];
	tmp.mat[14]=mat[14]-m.mat[14];
	tmp.mat[15]=mat[15]-m.mat[15];
	
	return tmp;			
}

//-----------------------------------------------------------

const Matrix44 Matrix44::operator * (const Matrix44 &m) const
{
	Matrix44 tmp;
	
	tmp.mat[ 0] = mat[0]*m.mat[ 0]+mat[4]*m.mat[ 1]+mat[ 8]*m.mat[ 2]+mat[12]*m.mat[ 3];
	tmp.mat[ 4] = mat[0]*m.mat[ 4]+mat[4]*m.mat[ 5]+mat[ 8]*m.mat[ 6]+mat[12]*m.mat[ 7];
	tmp.mat[ 8] = mat[0]*m.mat[ 8]+mat[4]*m.mat[ 9]+mat[ 8]*m.mat[10]+mat[12]*m.mat[11];
	tmp.mat[12] = mat[0]*m.mat[12]+mat[4]*m.mat[13]+mat[ 8]*m.mat[14]+mat[12]*m.mat[15];
	
	tmp.mat[ 1] = mat[1]*m.mat[ 0]+mat[5]*m.mat[ 1]+mat[ 9]*m.mat[ 2]+mat[13]*m.mat[ 3];
	tmp.mat[ 5] = mat[1]*m.mat[ 4]+mat[5]*m.mat[ 5]+mat[ 9]*m.mat[ 6]+mat[13]*m.mat[ 7];
	tmp.mat[ 9] = mat[1]*m.mat[ 8]+mat[5]*m.mat[ 9]+mat[ 9]*m.mat[10]+mat[13]*m.mat[11];
	tmp.mat[13] = mat[1]*m.mat[12]+mat[5]*m.mat[13]+mat[ 9]*m.mat[14]+mat[13]*m.mat[15];
	
	tmp.mat[ 2] = mat[2]*m.mat[ 0]+mat[6]*m.mat[ 1]+mat[10]*m.mat[ 2]+mat[14]*m.mat[ 3];
	tmp.mat[ 6] = mat[2]*m.mat[ 4]+mat[6]*m.mat[ 5]+mat[10]*m.mat[ 6]+mat[14]*m.mat[ 7];
	tmp.mat[10] = mat[2]*m.mat[ 8]+mat[6]*m.mat[ 9]+mat[10]*m.mat[10]+mat[14]*m.mat[11];
	tmp.mat[14] = mat[2]*m.mat[12]+mat[6]*m.mat[13]+mat[10]*m.mat[14]+mat[14]*m.mat[15];
			
	tmp.mat[ 3] = mat[3]*m.mat[ 0]+mat[7]*m.mat[ 1]+mat[11]*m.mat[ 2]+mat[15]*m.mat[ 3];
	tmp.mat[ 7] = mat[3]*m.mat[ 4]+mat[7]*m.mat[ 5]+mat[11]*m.mat[ 6]+mat[15]*m.mat[ 7];
	tmp.mat[11] = mat[3]*m.mat[ 8]+mat[7]*m.mat[ 9]+mat[11]*m.mat[10]+mat[15]*m.mat[11];
	tmp.mat[15] = mat[3]*m.mat[12]+mat[7]*m.mat[13]+mat[11]*m.mat[14]+mat[15]*m.mat[15];
	
	return tmp;
}

//-----------------------------------------------------------	

const Matrix44 Matrix44::operator * (const float &s) const
{
	Matrix44 tmp;
		
	tmp.mat[0]=mat[0]*s;
	tmp.mat[1]=mat[1]*s;
	tmp.mat[2]=mat[2]*s;
    
	tmp.mat[3]=mat[3]*s;
	tmp.mat[4]=mat[4]*s;
	tmp.mat[5]=mat[5]*s;
    
	tmp.mat[6]=mat[6]*s;
	tmp.mat[7]=mat[7]*s;
	tmp.mat[8]=mat[8]*s;
	
	return tmp;
}

//-----------------------------------------------------------	

const Vector3D Matrix44::operator * (const Vector3D &v) const
{
	Vector3D tmp;
  	
	//v'=m*v
	tmp.x= mat[0]*v.x + mat[4]*v.y + mat[ 8]*v.z + mat[12];	
	tmp.y= mat[1]*v.x + mat[5]*v.y + mat[ 9]*v.z + mat[13];
  	tmp.z= mat[2]*v.x + mat[6]*v.y + mat[10]*v.z + mat[14];
	
    	
	return tmp;
}

//-----------------------------------------------------------
//-----------------------------------------------------------
    	
const bool Matrix44::operator == (const Matrix44 &m) const
{
	
	return (mat[0]==m.mat[0] && mat[ 8]==m.mat[ 8] &&
	 	mat[1]==m.mat[1] && mat[ 9]==m.mat[ 9] && 
		mat[2]==m.mat[2] && mat[10]==m.mat[10] &&
		mat[3]==m.mat[3] && mat[11]==m.mat[11] && 
		mat[4]==m.mat[4] && mat[12]==m.mat[12] &&
		mat[5]==m.mat[5] && mat[13]==m.mat[13] && 
		mat[6]==m.mat[6] && mat[14]==m.mat[14] &&
		mat[7]==m.mat[7] && mat[15]==m.mat[15]);	
}

//-----------------------------------------------------------

const bool Matrix44::operator != (const Matrix44 &m) const
{
	return !((*this)==m);
}
