#include <windows.h>
#include <math.h>

#include "glut.h"
#include <gl\glaux.H>

#include <iostream.H>

#include "Vector3D.h"
#include "Matrix33.h"
#include "Matrix44.h"

#pragma comment(lib, "GLAUX.LIB")


//void APIENTRY auxWireCone(GLdouble, GLdouble);
//void APIENTRY auxSolidCone(GLdouble, GLdouble);

void vector(const Vector3D &v,const Vector3D &p, const Vector3D &color)
{

	glColor3f( color[0] , color.GetY(), color.GetZ() );			
	glPushMatrix();
			
			glTranslatef( p.GetX() , p.GetY(), p.GetZ() );


			glBegin(GL_LINES);
				glVertex3f(0,0,0);
				glVertex3f( v.GetX() , v.GetY(), v.GetZ() );
			glEnd();
			glTranslatef( v.GetX() , v.GetY(), v.GetZ() );
		

	glPopMatrix();



}

void PrintM33(Matrix33 m)
{
	cout << m(0,0) << " " << m(0,1) << " " << m(0,2) << endl; 
	cout << m(1,0) << " " << m(1,1) << " " << m(1,2) << endl; 
	cout << m(2,0) << " " << m(2,1) << " " << m(2,2) << endl; 

	
}
void PrintM44(Matrix44 m)
{
	cout << m(0,0) << " " << m(0,1) << " " << m(0,2) << " " << m(0,3)<< endl; 
	cout << m(1,0) << " " << m(1,1) << " " << m(1,2) << " " << m(1,3)<< endl; 
	cout << m(2,0) << " " << m(2,1) << " " << m(2,2) << " " << m(2,3)<< endl;
	cout << m(3,0) << " " << m(3,1) << " " << m(3,2) << " " << m(3,3) << endl;

}


void vector2(const Vector3D &v,const Vector3D &p, const Vector3D &color)
{



	glColor3f( color.GetX() , color.GetY(), color.GetZ() );			
	glPushMatrix();
			
			glTranslatef( p.GetX() , p.GetY(), p.GetZ() );

			glBegin(GL_LINES);
				glVertex3f(0,0,0);
				glVertex3f( v.GetX() , v.GetY(), v.GetZ() );
			glEnd();
					

			Vector3D x, y(v), z;
			y.Normalize();
			x.Set( y[1], -y[0], y[2] ); 
			z=x.Cross(y); 

			 //y[0]=x[1]*z[2] - x[2]*z[1];
			 //y[1]=x[2]*z[0] - x[0]*z[2];
			 //y[2]=x[0]*z[1] - x[1]*z[0];

			Matrix33 m1;

			m1.SetCol(0,x);
			m1.SetCol(1,y);
			m1.SetCol(2,z);

			Matrix44 mt(m1,v);
			
			glMultMatrixf(mt.Get());




			glPushMatrix();
				glRotatef(-90,1,0,0);
				auxSolidCone(0.1, 0.2);
				//auxWireCone(0.1, 0.2);
			glPopMatrix();
	glPopMatrix();


 



}

		

void init(void) 
{    
	glClearColor (0.0, 0.0, 0.0, 1.0);
    
	
	glEnable ( GL_DEPTH_TEST );
	//glEnable ( GL_LIGHT0 );
	
	glEnable(GL_COLOR_MATERIAL);
}
float i=0;
void display(void)
{
	
	glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
	glLoadIdentity ();


	glTranslatef ( 0.0, 0.0, -5.0 );
	
	i+=0.5;
	glRotatef(i,0,1,0);


	
/*	
	glDisable ( GL_LIGHTING );			 
				

			glTranslatef ( -2.0, 1.0, 0.0 );
			glMultMatrixf((float *)m4x4);
			glBegin(GL_LINES);
				glColor3f(1,0,0);
				glVertex3f(0,0,0);
				glVertex3f(vAxisX[0],vAxisX[1],vAxisX[2]);
				
				glColor3f(0,1,0);
				glVertex3f(0,0,0);
				glVertex3f(vAxisY[0],vAxisY[1],vAxisY[2]);
				
				glColor3f(0,0,1);
				glVertex3f(0,0,0);
				glVertex3f(vAxisZ[0],vAxisZ[1],vAxisZ[2]);
			glEnd();

		glPopMatrix();

		glEnable ( GL_LIGHTING );			
		glPushMatrix();
			//glTranslatef ( -1.0, 0.0, 0.0 );
			glMultMatrixf((float *)m4x4);
			glColor3f(1,1,1);			
			glPushMatrix();
				glRotatef(180,0,1,0);
				glmDraw(pmodel, GLM_FLAT);
			glPopMatrix();
		glPopMatrix();*/


	Vector3D l(1,1,0);
	Vector3D n(0,1,0);

	vector2(l,Vector3D(),Vector3D(1,0,0));
	vector2(n,Vector3D(),Vector3D(0,0,1));

	vector2(l.Reflect(n),Vector3D(),Vector3D(1,1,1));

	   
	glFlush ();
	glutSwapBuffers();

}

void reshape (int w, int h)
{
   glViewport (0, 0, (GLsizei) w, (GLsizei) h); 
   glMatrixMode (GL_PROJECTION);
   glLoadIdentity ();
   glFrustum (-1.0, 1.0, -1.0, 1.0, 1.5, 20.0);
   glMatrixMode (GL_MODELVIEW);
}

int main(int argc, char** argv)
{

   glutInit(&argc, argv);
   glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB | GLUT_DOUBLE);
   glutInitWindowSize (500, 500); 
   glutInitWindowPosition (100, 100);
   glutCreateWindow (argv[0]);
   
   init ();
   
   glutDisplayFunc(display); 
   glutReshapeFunc(reshape);
   glutIdleFunc(display);
   //glutKeyboardFunc ( keyboard  );

   glutMainLoop();
   
   
   return 0;
}