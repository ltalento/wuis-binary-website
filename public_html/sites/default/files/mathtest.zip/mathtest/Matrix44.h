#ifndef MATRIX44_H
#define MATRIX44_H
/*
The first thing that must be said about OpenGL matrices is that they are stored 
in column-major format. Normally, in C, you use row-major format.
So what does this mean? Let's say you have stored your matrix in an 
array as follows: float M[]={m1,m2,m3,...,m15,m16};
The two different interpretations are like this:

  |m1  m2  m3  m4 |     |m1  m5  m9  m13|    
M=|m5  m6  m7  m8 |   M=|m2  m6  m10 m14|
  |m9  m10 m11 m12|     |m3  m7  m11 m15|
  |m13 m14 m15 m16|     |m4  m8  m12 m16|

  Row-major format      Column-major format
*/
//|Xx Yx Zx Tx|
//|Xy Yy Zy Ty| 
//|Xz Yz Zz Tz|
//| 0  0  0  1|

class Vector3D;
class Matrix33;

class Matrix44
{

private:

 	float mat[16];

	static float Matrix44::det2x2(float a1, float a2, float b1, float b2);
	static float Matrix44::det3x3(float a1, float a2, float a3, 
					                float b1, float b2, float b3, 
							        float c1, float c2, float c3);
public:
	
	Matrix44();
	Matrix44(const float *m);
	Matrix44(const Matrix33 &m, const Vector3D &v);
	Matrix44(const Matrix44 &other);
	
	~Matrix44();
	
	
	const float* Get() const;
	const Matrix33 GetRotation() const;
	const Vector3D GetScale() const;
	const Vector3D GetTranslate() const;
	
	
	void Set(const int &row, const int &col, const float &v);
	void SetRotation(const Matrix33 &m);
	void SetScale(const Vector3D &v);
	void Scale(const Vector3D &v);
	void SetTranslate(const Vector3D &v);
	void Translate(const Vector3D &v);

	
	void Identify();
	void Transpose();
	void Invert();
	

	const float operator () (const int &row, const int &col) const;
			
  	const Matrix44& operator += (const Matrix44 &m);
  	const Matrix44& operator -= (const Matrix44 &m);
  	const Matrix44& operator *= (const Matrix44 &m);
	const Matrix44& operator *= (const float &s);

	const Matrix44 operator + (const Matrix44 &m) const;
	const Matrix44 operator - (const Matrix44 &m) const;
	const Matrix44 operator * (const Matrix44 &m) const;
	
	const Matrix44 operator * (const float &s) const; 	
	const Vector3D  operator * (const Vector3D &v) const;
    	
    const bool operator == (const Matrix44 &m) const;
    const bool operator != (const Matrix44 &m) const;	
};

#endif