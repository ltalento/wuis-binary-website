#ifndef MATRIX33_H
#define MATRIX33_H
/*
The first thing that must be said about OpenGL matrices is that they are stored 
in column-major format. Normally, in C, you use row-major format.
So what does this mean? Let's say you have stored your matrix in an 
array as follows: float M[]={m1,m2,m3,...,m15,m16};
The two different interpretations are like this:

  |m1  m2  m3  m4 |     |m1  m5  m9  m13|    
M=|m5  m6  m7  m8 |   M=|m2  m6  m10 m14|
  |m9  m10 m11 m12|     |m3  m7  m11 m15|
  |m13 m14 m15 m16|     |m4  m8  m12 m16|

  Row-major format      Column-major format
*/
//|Xx Yx Zx|
//|Xy Yy Zy|
//|Xz Yz Zz|

class Vector3D;
class Quaternion;

class Matrix33
{

private:

    float mat[9];

	friend class Matrix44;

public:	
	
	Matrix33();
	Matrix33(const float *m);
	Matrix33(const Matrix33 &other);
	
	~Matrix33();
	
	void SetRow(const int &row, const Vector3D &v);
	void SetCol(const int &col, const Vector3D &v);
	void Set(const int &row, const int &col, const float &v);
	
	const float* Get() const;
	const Vector3D GetRow(const int &row) const;
	const Vector3D GetCol(const int &col) const;
	
	void Identify();
	
	void Transpose();
	
	void Invert();
	
	void RotationX(const float &radians);
	void RotationY(const float &radians);
	void RotationZ(const float &radians);
	void RotationAxis(const float &radians, const Vector3D &axis);
	
	//Make a rotation matrix from Euler angles
	void Rotation(const Vector3D &angles_rad);

	//Make a rotation matrix from a quaternion.
	void RotationQuaternion(const Quaternion& quat);//????

	const float operator () (const int &row, const int &col) const;
			
  	const Matrix33& operator += (const Matrix33 &m);
  	const Matrix33& operator -= (const Matrix33 &m);
  	const Matrix33& operator *= (const Matrix33 &m);
	const Matrix33& operator *= (const float &s);
	  		
	const Matrix33 operator + (const Matrix33 &m) const;
	const Matrix33 operator - (const Matrix33 &m) const;
	const Matrix33 operator * (const Matrix33 &m) const;
	
	const Matrix33 operator * (const float &s) const; 	
	const Vector3D operator * (const Vector3D &v) const;
    	
    const bool operator == (const Matrix33 &m) const;
    const bool operator != (const Matrix33 &m) const;	
};

#endif