/*
 * CellManager.java
 *
 * Created on 5 de Janeiro de 2004, 20:57
 */

/**
 *
 * @author  Luis
 */
package Game;

import java.awt.*;
import java.awt.image.*;
import java.awt.Graphics;
import java.util.Random;

public class CellManager extends Sprite implements Runnable{
    
    private int rows, columns;
    private Cell grid[][];
    
    /** Creates a new instance of CellManager */
    public CellManager(Image frames[], int nrFrames, int rows, int columns) {
        super(frames, nrFrames);
        
        this.grid = new Cell [rows][columns];
        for (int j = 0; j < rows; j++)
            for (int i = 0; i < columns; i++)
                this.grid[j][i] = new Cell();
        this.rows = rows;
        this.columns = columns;
        
        new Thread(this).start();
    }
    
    
    public CellManager(CellManager other) {
        
        super(other.frames, other.nrFrames);
        
        this.rows =  other.rows;
        this.columns =  other.columns;
        
        this.grid = new Cell[this.rows][this.columns];
        for (int j = 0; j < this.rows; j++)
            for (int i = 0; i < this.columns; i++) {
                this.grid[j][i] = new Cell();
                if (other.getCell(j,i).isAlive())
                    (this.grid[j][i]).Born();
                else
                    (this.grid[j][i]).Die();
            }
    }
    
    
    public void Draw(Graphics2D g ){
        int inc=GG.SPRITE_SIZE;
        for (int j = 0; j < rows; j++)
            for (int i = 0; i < columns; i++)
                if(this.grid[j][i].isAlive()){
                    
                    int tmpwx = j * inc;
                    int tmpwy = i * inc;
                    
                    if (tmpwx < (GG.pPlayerShip.getWordlX() - (GG.SCREEN_W/2)) )
                        tmpwx+=GG.UNIVERSE_MAX_X;
                    else if (tmpwx > (GG.pPlayerShip.getWordlX() + (GG.SCREEN_W/2)) )
                        tmpwx-=GG.UNIVERSE_MAX_X;
                    
                    if (tmpwy < (GG.pPlayerShip.getWordlY() - (GG.SCREEN_H/2)) )
                        tmpwy+=GG.UNIVERSE_MAX_Y;
                    else if (tmpwy > (GG.pPlayerShip.getWordlY() + (GG.SCREEN_H/2)) )
                        tmpwy-=GG.UNIVERSE_MAX_Y;
                    
                    int tmpx = tmpwx - GG.pPlayerShip.getWordlX() + (GG.SCREEN_W/2);
                    int tmpy = tmpwy - GG.pPlayerShip.getWordlY() + (GG.SCREEN_H/2);
                    
                    if(tmpx>=0 && tmpy>=0 && tmpx<=GG.SCREEN_W && tmpy<=GG.SCREEN_H){
                        super.setXY(tmpx,tmpy);
                        super.Draw(g);
                    }
                }
    }
    
    public Cell getCell(int y, int x) {
        return this.grid[(y+this.rows)%this.rows][(x+this.columns)%this.columns];
    }
    
    public int nrAliveCells(){
        int nr=0;
        for (int j = 0; j < rows; j++)
            for (int i = 0; i < columns; i++)
                if ( this.grid[j][i].isAlive() ) nr++;
        return nr;
    }
    
    public boolean ScreenCollideCell(Sprite sprite) {
        int inc=GG.SPRITE_SIZE;
        for (int j = 0; j < rows; j++)
            for (int i = 0; i < columns; i++)
                if(this.grid[j][i].isAlive()){
                    
                    int tmpwx = j * inc;
                    int tmpwy = i * inc;
                    
                    if (tmpwx < (GG.pPlayerShip.getWordlX() - (GG.SCREEN_W/2)) )
                        tmpwx+=GG.UNIVERSE_MAX_X;
                    else if (tmpwx > (GG.pPlayerShip.getWordlX() + (GG.SCREEN_W/2)) )
                        tmpwx-=GG.UNIVERSE_MAX_X;
                    
                    if (tmpwy < (GG.pPlayerShip.getWordlY() - (GG.SCREEN_H/2)) )
                        tmpwy+=GG.UNIVERSE_MAX_Y;
                    else if (tmpwy > (GG.pPlayerShip.getWordlY() + (GG.SCREEN_H/2)) )
                        tmpwy-=GG.UNIVERSE_MAX_Y;
                    
                    int tmpx = tmpwx - GG.pPlayerShip.getWordlX() + (GG.SCREEN_W/2);
                    int tmpy = tmpwy - GG.pPlayerShip.getWordlY() + (GG.SCREEN_H/2);
                    
                    if(tmpx>=0 && tmpy>=0 && tmpx<=GG.SCREEN_W && tmpy<=GG.SCREEN_H){
                        if(sprite.getX()==tmpx && sprite.getY()==tmpy)
                            return true;
                    }
                }
        
        return false;
    }
    
    
    public int nrNeighbors(int y, int x) {
        int ret = 0;
        if (this.getCell(y-1,x-1).isAlive()) ret++;
        if (this.getCell(y-1,x).isAlive()) ret++;
        if (this.getCell(y-1,x+1).isAlive()) ret++;
        if (this.getCell(y,x+1).isAlive()) ret++;
        if (this.getCell(y+1,x+1).isAlive()) ret++;
        if (this.getCell(y+1,x).isAlive()) ret++;
        if (this.getCell(y+1,x-1).isAlive()) ret++;
        if (this.getCell(y,x-1).isAlive()) ret++;
        return ret;
    }
    
    public void Populate(int k) {
        Random r = new Random();
        for (int i = 0; i < k;) {
            int column = (Math.abs(r.nextInt()))%this.columns;
            for (int j = 0; j < 10; j++)
                r.nextInt();
            int row = (Math.abs(r.nextInt()))%this.rows;
            
            if (!grid[row][column].isAlive()){
                grid[row][column].Born();
                i++;
            }
        }
    }
    
    public void nextGeneration(){
        CellManager prev = new CellManager(this);
        
        for (int j = 0; j < this.rows; j++)
            for (int i = 0; i < this.columns; i++) {
                Cell c;
                switch (prev.nrNeighbors(j,i)) {
                    /* 0 ou 1 vizinhos: morre de solidao */
                    /*                : permanece vazio  */
                    case 0:
                    case 1:
                        this.getCell(j,i).Die();
                        break;
                        /* 2 vizinhos: continua do mesmo modo */
                    case 2:
                        break;
                        /* 3 vizinhos: se vazio, nasce  */
                        /*             senao, permanece */
                    case 3:
                        this.getCell(j,i).Born();
                        break;
                        /* 4+ vizinhos: morre de superpopulacao */
                    case 4:
                    case 5:
                    case 6:
                    case 7:
                    case 8:
                        this.getCell(j,i).Die();
                        break;
                }
            }
        
        
        
    }
    
    public int nrRows() {
        return this.rows;
    }
    
    public int nrColumns() {
        return this.columns;
    }
    
    
    public void run() {
        while(true){
            //   Draw((Graphics2D)g);
            nextFrame();
            try{ Thread.sleep(250); }
            catch(InterruptedException ie){}
        }
    }
    
    
}
