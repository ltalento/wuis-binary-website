/*
 * GameGlobals.java
 *
 * Created on 8 de Janeiro de 2004, 22:10
 */

/**
 *
 * @author  Luis
 */
package Game;

public class GG {
    
    /** Creates a new instance of GameGlobals */
    public GG() {
    }
    
    public static int DELAY=1000;
    
    public static int UNIVERSE_MAX_X;
    public static int UNIVERSE_MIN_X=0;
    public static int UNIVERSE_MAX_Y;
    public static int UNIVERSE_MIN_Y=0;
    public static int SCREEN_W;
    public static int SCREEN_H;
    public static int SPRITE_SIZE=16;    
    
    public static Ship pPlayerShip;
    public static ExplosionManager pE_M;
}
