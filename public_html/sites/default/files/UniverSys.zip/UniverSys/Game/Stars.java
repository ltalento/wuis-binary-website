/*
 * Stars.java
 *
 * Created on 7 de Janeiro de 2004, 22:55
 */

/**
 *
 * @author  Luis
 */
package Game;

import java.awt.Graphics;
import java.awt.Color;
import java.awt.*;

import java.util.Random;

public class Stars {
    
    private int nrStars;
    private Star stars[];
    private int screen_w;
    private int screen_h;
    
    private int v_x;
    private int v_y;
    
    /** Creates a new instance of Stars */
    public Stars(int nrStars) {
        this.nrStars = nrStars;
        
        this.stars = new Star[nrStars];
        for(int i=0; i<nrStars; i++ )
            this.stars[i]= new Star();                    
    
        this.initStars();
    }
    
    public void initStars(){
       /*  Random r = new Random();
        for (int i = 0; i < 200;) {
            int x = (Math.abs(r.nextInt()))%1024;
            for (int j = 0; j < 10; j++)
                r.nextInt();
            int y = (Math.abs(r.nextInt()))%768;
                g.setColor(Color.WHITE);
     */
        Random r = new Random();
        for (int i=0; i<this.nrStars; i++) {
            
            switch((Math.abs(r.nextInt()))%3) {
                case 0: {
                    stars[i].c = Color.WHITE;
                    stars[i].z = 1;
                } break;
                
                case 1: {
                    stars[i].c = Color.LIGHT_GRAY;
                    stars[i].z = 2;
                } break;
                
                case 2: {
                    stars[i].c = Color.DARK_GRAY;
                    stars[i].z = 3;
                } break;
                
                default:break;               
            }
            
            stars[i].x = (Math.abs(r.nextInt()))%GG.SCREEN_W;
            stars[i].y = (Math.abs(r.nextInt()))%GG.SCREEN_H;
        }
    }
    

    public void undoMove(){
        Move(v_x*-1 , v_y*-1);
    }
    
    public void Move(int x, int y){
        v_x=x;
        v_y=y;
        for (int i=0; i < nrStars; i++) {
            
            
            switch(stars[i].z) {
                case 1: {
                    stars[i].x+= x;
                    stars[i].y+= y;
                } break;
                
                case 2: {
                    stars[i].x+= x/2;
                    stars[i].y+= y/2;
                } break;
                
                case 3: {
                    stars[i].x+= x/4;
                    stars[i].y+= y/4;
                    
                } break;
                
            }
            
            
            if (stars[i].x >= GG.SCREEN_W)
                stars[i].x = stars[i].x-GG.SCREEN_W;
            else
                if (stars[i].x < 0)
                    stars[i].x = GG.SCREEN_W + stars[i].x;
            
            if (stars[i].y >= GG.SCREEN_H)
                stars[i].y = stars[i].y-GG.SCREEN_H;
            else
                if (stars[i].y < 0)
                    stars[i].y = GG.SCREEN_H+stars[i].y;
            
        }
                
    }
    
    public void Draw(Graphics g){
        for(int i=0;i<this.nrStars;i++){
            g.setColor(stars[i].c);
            g.drawLine(stars[i].x, stars[i].y, stars[i].x, stars[i].y);
        }
    }
    
    
}

class Star {
    public int x,y,z;
    public Color c;
}