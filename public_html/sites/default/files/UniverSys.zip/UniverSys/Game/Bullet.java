/*
 * Bullet.java
 *
 * Created on 9 de Janeiro de 2004, 3:09
 */

/**
 *
 * @author  Luis
 */
package Game;

import java.awt.*;
import java.awt.image.*;
import java.awt.Graphics;

public class Bullet  extends GameEntity implements Runnable {
    
    private boolean inGame=false;
    private int v_x, v_y;
    private int autonomia=10;
    private int tmp=0;
    
    /** Creates a new instance of Bullet */
    public Bullet(Image frames[], int nrFrames) {
        super(frames, nrFrames);
        new Thread(this).start();
    }
    public void setAutonomia(int a){
        this.autonomia=a;
    }
    
    public int getAutonomia(){
        return autonomia;
    }
    
    public void Launch(int dir, int inc){
        
        switch(dir){
            case Sprite.TRANS_NONE:
                this.v_x=0;
                this.v_y=-inc;
                break;
            case Sprite.TRANS_ROT90:
                this.v_x=-inc;
                this.v_y=0;
                break;
            case Sprite.TRANS_ROT180:
                this.v_x=0;
                this.v_y=inc;
                break;
            case Sprite.TRANS_ROT270:
                this.v_x=inc;
                this.v_y=0;
                break;
        }
        this.setTransform(dir);
        this.inGame=true;
        
        super.setXY(GG.pPlayerShip.getX()+v_x, GG.pPlayerShip.getY()+v_y);//
        
        super.setWorldXY( GG.pPlayerShip.getWordlX()+v_x,  GG.pPlayerShip.getWordlY()+v_y);
        tmp=0;
    }
    
    public boolean isInGame(){
        return inGame;
    }
    
    public void Move(){
        super.Move(v_x, v_y);
    }
    
    public void Draw(Graphics2D g ){
        if(inGame){
            int tmpx = world_x - GG.pPlayerShip.getWordlX() + (GG.SCREEN_W/2);
            int tmpy = world_y - GG.pPlayerShip.getWordlY() + (GG.SCREEN_H/2);
            super.setXY(tmpx,tmpy);
            super.Draw(g);
        }
    }
    
    public void Explode(int exp){
        GG.pE_M.startExplosion(this.world_x ,this.world_y , exp);
        inGame=false;
        tmp=0; 
    }
    
    public void run() {
        while(true){
            
            if(inGame){
                Move();
                nextFrame();
                tmp++;
                if(tmp>=autonomia){
                    Explode(ExplosionManager.EXPL01);
                }
            }
            
            
            try{ Thread.sleep(125); }
            catch(InterruptedException ie){}
        }
    }
    
}
