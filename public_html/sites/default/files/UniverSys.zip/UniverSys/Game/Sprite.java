/*
 * Sprite.java
 *
 * Created on 19 de Dezembro de 2003, 16:35
 */

/**
 *
 * @author  aluno
 */
package Game;

import java.awt.*;
import java.awt.image.*;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;

public class Sprite{    
    
    public static final int TRANS_NONE = 0;
    public static final int TRANS_ROT90 = 1;
    public static final int TRANS_ROT180 = 2;
    public static final int TRANS_ROT270 = 3;    
    
    protected Image frames[];
    protected int nrFrames;
    private int currFrame = 0;    
    private int x, y;
    private AffineTransform xform;//matrix de tranforma�ao
    private int currTransf = TRANS_NONE;
    
    //Graphics g;        
    //boolean visible;
    
    /** Creates a new instance of Sprite */
    public Sprite(Image frames[], int nrFrames) {
        //this.g=g;
        this.nrFrames=nrFrames;
        this.frames = frames;
        xform = new AffineTransform();

    }
    
    public Sprite(Sprite other){
        frames=other.frames;
        nrFrames=other.nrFrames;
        currFrame=other.currFrame;
        x=other.x;
        y=other.y;
        xform=other.xform;
        currTransf=other.currTransf;
    }
    
    public int getCurrFrame(){
        return currFrame;
    }
   
    public void setFrame(int i){
        currFrame = i % nrFrames;
    }
    
    public void nextFrame(){
        currFrame = (currFrame + 1) % nrFrames;
    }

    public void prevFrame(){
        if(currFrame == 0)
            currFrame = nrFrames - 1;
        else
            currFrame--;
    }
    
    public int getCurrTransform(){
        return currTransf;
    }
    
    public void setTransform(int i){
        currTransf=i;
    }
    
    public void Transform(int i){
        switch(i){        
            case TRANS_ROT90:
                xform.setTransform(0, 1, 1, 0, x,y);
                break;
            case TRANS_ROT180:
                xform.setTransform(1, 0, 0, -1, x, (y + frames[0].getHeight(null)) );
                break;
            case TRANS_ROT270:
                xform.setTransform(0, -1, -1, 0, (x+frames[0].getHeight(null)),
                                                    (y+frames[0].getWidth(null)) );
                break;
            case TRANS_NONE:                
            default:
                xform.setTransform(1, 0, 0, 1, x,y);
                break;
        }
        currTransf=i;
    }
    
    public void Translate(int x, int y){    
        this.x+=x;
        this.y+=y;
        Transform(currTransf);
    }
    
    public void setXY(int x, int y){    
        this.x=x;
        this.y=y;
        Transform(currTransf);
    }
    
    public void setX(int x){    
        this.x=x;        
        Transform(currTransf);
    }
    
    public void setY(int y){    
        this.y=y;        
        Transform(currTransf);
    }
    
    public int getX(){                
        return this.x;
    }
    
    public int getY(){                
        return this.y;
    }
    
    public void Draw(Graphics2D g){  
        //g.clearRect(0,0, 200,200);
        g.drawImage(this.frames[currFrame], xform ,null);        
    }
    
    public boolean Collides(Sprite other){
        if(other.x==this.x && other.y==this.y)
            return true;
        else
            return false;
    }
    
    
}
