/*
 * GameEntity.java
 *
 * Created on 8 de Janeiro de 2004, 21:12
 */

/**
 *
 * @author  Luis
 */
package Game;

import java.awt.Image;

public class GameEntity extends Sprite {
    
    protected int world_x;
    protected int world_y;
    //private int old_x;
    //private int old_y;
    private int v_x;
    private int v_y;
    
    /** Creates a new instance of GameEntity */
    public GameEntity(Image frames[], int nrFrames){
        super(frames, nrFrames);
    }
    
    
    public int getWordlX(){
        return this.world_x;
    }
    
    public int getWordlY(){
        return this.world_y;
    }
    
    public void setWorldX(int x){
        //this.old_x=x;
        this.world_x=x;
        //CheckUniLimits();
    }
    
    public void setWorldY(int y){
        //this.old_y=y;
        this.world_y=y;
       // CheckUniLimits();
    }
    
    public void setWorldXY(int x, int y){
        //this.old_x=x;
        //this.old_y=y;
        this.world_x=x;
        this.world_y=y;
      //  CheckUniLimits();
    }
    
    public void Move(int x, int y){
        
        //this.old_x=this.world_x;
        //this.old_y=this.world_y;
        v_x=x;
        v_y=y;
        
        this.world_x+=x;
        this.world_y+=y;
       // CheckUniLimits();
    }
    
    public void undoMove(){
        //this.world_x = this.old_x;
        //this.world_y = this.old_y;
        this.world_x+=(v_x*-1);
        this.world_y+=(v_y*-1);
        //CheckUniLimits();
    }
    
    public String toString(){
        return new String("world_x: "+String.valueOf(world_x)+" world_y: "+String.valueOf(world_y));
    }
    
    public void CheckUniLimits(){
        if (world_x > GG.UNIVERSE_MAX_X-16)
            world_x=GG.UNIVERSE_MIN_X;
        else if (world_x < GG.UNIVERSE_MIN_X)
            world_x=GG.UNIVERSE_MAX_X-16;
        
        if (world_y > GG.UNIVERSE_MAX_Y-16)
            world_y=GG.UNIVERSE_MIN_Y;
        else if (world_y < GG.UNIVERSE_MIN_Y)
            world_y=GG.UNIVERSE_MAX_Y-16;
        
    }
    
}
