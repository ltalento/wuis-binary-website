/*
 * BigInteger.java
 *
 * Created on 27 de Janeiro de 2004, 6:00
 */

package Game;

/**
 *
 * @author  Luis
 */
public class BigInteger {
    
    /** Creates a new instance of BigInteger */
    private String s = new String();
    
    public BigInteger() {
    }
    
    public BigInteger(String s) {
        this.s=s;
    }
    
    public String toString(){
        return this.s;
    }
    
    public BigInteger Add(BigInteger other){
        
        int max=Math.max( this.s.length() , other.s.length() );
        int carry=0, res=0;
        BigInteger tmp = new BigInteger();
        
        this.Reverse();        
        other.Reverse();
        
        for(int i=0; i<max; i++) {
            int dig1=0,dig2=0;
            
            if(i<s.length())
                dig1= this.s.charAt(i)-48;
            
            if(i<other.s.length())
                dig2 = other.s.charAt(i)-48;
            
            res =(dig1+dig2+carry)%10;
            carry = (dig1+dig2+carry)/10;
            
            tmp.s+=(char)(res+48);            
        }
        if(carry!=0)
            tmp.s+=(char)(carry+48);            
        
        this.s = tmp.s;
        
        other.Reverse();
        this.Reverse();
        return this;
    }
    
    public void Reverse(){
        String tmp = new String();
        for(int i=(s.length()-1);i>=0;i--)
            tmp += s.charAt(i); 
        s=tmp;
    }
    
}
