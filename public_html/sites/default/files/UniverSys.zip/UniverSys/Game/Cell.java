/*
 * Cell.java
 *
 * Created on 5 de Janeiro de 2004, 20:46
 */

/**
 *
 * @author  Luis
 */
package Game;

public class Cell{

    private boolean alive;
        
    /** Creates a new instance of Cell */
    public Cell(){        
        this.Die();
    }  

    public void Born() {
        this.alive = true;
    }

    public void Die() {
        this.alive = false;
    }
    
    public boolean isAlive() {
        return this.alive;
    }
}
