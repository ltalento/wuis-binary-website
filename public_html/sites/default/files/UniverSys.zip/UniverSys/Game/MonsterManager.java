/*
 * MonsterManager.java
 *
 * Created on 17 de Janeiro de 2004, 18:03
 */

/**
 *
 * @author  Luis
 */
package Game;

import java.awt.*;
import java.awt.image.*;
import java.awt.Graphics;
import java.util.Random;

public class MonsterManager extends Sprite implements Runnable{
    
    
    
    private int nrMonsters=0;
    private Monster monsters[];
    private Random r = new Random();
    private int xmonster;
    
    /** Creates a new instance of MonsterManager */
    public MonsterManager(Image frames[], int nrFrames) {
        super(frames, nrFrames);
        
        new Thread(this).start();
    }
    
    public Monster getMonster(int i){
        return monsters[i];
    }
    
    public int nrMonsters(){
        return nrMonsters;
    }
    
    public void addMonster(int x, int y){
        
        Monster tmps[] = new Monster[nrMonsters];
        for(int i=0;i<nrMonsters;i++)
            tmps[i]=monsters[i];
        
        nrMonsters++;
        monsters = new Monster[nrMonsters];
        for(int i=0;i<(nrMonsters-1);i++)
            monsters[i]=tmps[i];
        
        Monster tmp= new Monster();
        tmp.setWorldXY( x , y);
        tmp.setRandVel();
        monsters[nrMonsters-1]= tmp;//new Monster(tmp);
        
    }
    
    public void Populate(int k, CellManager c_m){
        nrMonsters=k;
        monsters = new Monster[nrMonsters];
        for(int i=0; i<nrMonsters;i++){
            int tmpx, tmpy;
            do{
                tmpx = (Math.abs(r.nextInt()))%c_m.nrColumns();
                for (int j = 0; j < 10; j++)
                    r.nextInt();
                tmpy = (Math.abs(r.nextInt()))%c_m.nrRows();
            }while(c_m.getCell(tmpx,tmpy).isAlive());
            
            tmpx*=GG.SPRITE_SIZE;
            tmpy*=GG.SPRITE_SIZE;
            
            Monster tmp= new Monster();
            tmp.setWorldXY(tmpx,tmpy);
            tmp.setRandVel();
            monsters[i]=tmp;
        }
    }
    public void Teleport(CellManager c_m){
        int tmpx, tmpy;
        do{
            tmpx = (Math.abs(r.nextInt()))%c_m.nrColumns();
            for (int j = 0; j < 10; j++)
                r.nextInt();
            tmpy = (Math.abs(r.nextInt()))%c_m.nrRows();
        }while(c_m.getCell(tmpx,tmpy).isAlive());
        
        tmpx*=GG.SPRITE_SIZE;
        tmpy*=GG.SPRITE_SIZE;
        
        monsters[xmonster].setWorldXY(tmpx,tmpy);
        
    }
    
    
    public boolean ScreenCollideCell(Sprite sprite) {
        int inc=GG.SPRITE_SIZE;
        for (int i = 0; i < nrMonsters; i++){
            
            int tmpwx=monsters[i].getWordlX();
            int tmpwy=monsters[i].getWordlY();
            
            if (tmpwx < (GG.pPlayerShip.getWordlX() - (GG.SCREEN_W/2)) )
                tmpwx+=GG.UNIVERSE_MAX_X;
            else if (tmpwx > (GG.pPlayerShip.getWordlX() + (GG.SCREEN_W/2)) )
                tmpwx-=GG.UNIVERSE_MAX_X;
            
            if (tmpwy < (GG.pPlayerShip.getWordlY() - (GG.SCREEN_H/2)) )
                tmpwy+=GG.UNIVERSE_MAX_Y;
            else if (tmpwy > (GG.pPlayerShip.getWordlY() + (GG.SCREEN_H/2)) )
                tmpwy-=GG.UNIVERSE_MAX_Y;
            
            int tmpx = tmpwx - GG.pPlayerShip.getWordlX() + (GG.SCREEN_W/2);
            int tmpy = tmpwy - GG.pPlayerShip.getWordlY() + (GG.SCREEN_H/2);
            
            if(tmpx>=0 && tmpy>=0 && tmpx<=GG.SCREEN_W && tmpy<=GG.SCREEN_H){
                xmonster = i;
                if(sprite.getX()==tmpx && sprite.getY()==tmpy)
                    return true;
            }
        }
        return false;
    }
    
    public void Move(){
        for(int i=0; i<nrMonsters; i++){
            monsters[i].Move();
        }
    }
    
    public void Draw(Graphics2D g ){
        for (int i = 0; i < nrMonsters; i++){
            
            int tmpwx=monsters[i].getWordlX();
            int tmpwy=monsters[i].getWordlY();
            
            if (tmpwx < (GG.pPlayerShip.getWordlX() - (GG.SCREEN_W/2)) )
                tmpwx+=GG.UNIVERSE_MAX_X;
            else if (tmpwx > (GG.pPlayerShip.getWordlX() + (GG.SCREEN_W/2)) )
                tmpwx-=GG.UNIVERSE_MAX_X;
            
            if (tmpwy < (GG.pPlayerShip.getWordlY() - (GG.SCREEN_H/2)) )
                tmpwy+=GG.UNIVERSE_MAX_Y;
            else if (tmpwy > (GG.pPlayerShip.getWordlY() + (GG.SCREEN_H/2)) )
                tmpwy-=GG.UNIVERSE_MAX_Y;
            
            int tmpx = tmpwx - GG.pPlayerShip.getWordlX() + (GG.SCREEN_W/2);
            int tmpy = tmpwy - GG.pPlayerShip.getWordlY() + (GG.SCREEN_H/2);
            
            if(tmpx>=0 && tmpy>=0 && tmpx<=GG.SCREEN_W && tmpy<=GG.SCREEN_H){
                super.setXY(tmpx,tmpy);
                super.Draw(g);
            }
        }
    }
    
    
    public void run() {
        while(true){
            nextFrame();
            
            
            try{ Thread.sleep(250); }
            catch(InterruptedException ie){}
        }
    }
    
}

class Monster{
    
    private int world_x;
    private int world_y;
    private int v_x=0;
    private int v_y=0;
    private Random r = new Random();
    /** Creates a new instance of Monster */
    public Monster() {
    }
    
    public Monster(Monster o) {
        this.world_x= o.world_x;
        this.world_y=o.world_y;
        this.v_x=o.v_x;
        this.v_y=o.v_y;  
    }
    
    public int getWordlX(){
        return this.world_x;
    }
    
    public int getWordlY(){
        return this.world_y;
    }
    
    public void setWorldX(int x){
        this.world_x=x;
    }
    
    public void setWorldY(int y){
        this.world_y=y;
    }
    
    public void setWorldXY(int x, int y){
        this.world_x=x;
        this.world_y=y;
    }
    
    void setRandVel(){
        switch((Math.abs(r.nextInt()))%4) {
            case 0:
                this.setVel(GG.SPRITE_SIZE,0);
                break;
            case 1:
                this.setVel(-GG.SPRITE_SIZE,0);
                break;
            case 2:
                this.setVel(0,GG.SPRITE_SIZE);
                break;
            case 3:
                this.setVel(0,-GG.SPRITE_SIZE);
                break;
        }
    }
    
    void setVel(int x, int y){
        v_x=x;
        v_y=y;
    }
    
    public void Move(){
        this.world_x+=v_x;
        this.world_y+=v_y;
        CheckUniLimits();
    }
    
    public void undoMove(){
        this.world_x+=(v_x*-1);
        this.world_y+=(v_y*-1);
    }
    
    public void CheckUniLimits(){
        if (world_x > GG.UNIVERSE_MAX_X-16)
            world_x=GG.UNIVERSE_MIN_X;
        else if (world_x < GG.UNIVERSE_MIN_X)
            world_x=GG.UNIVERSE_MAX_X-16;
        
        if (world_y > GG.UNIVERSE_MAX_Y-16)
            world_y=GG.UNIVERSE_MIN_Y;
        else if (world_y < GG.UNIVERSE_MIN_Y)
            world_y=GG.UNIVERSE_MAX_Y-16;
    }
}

