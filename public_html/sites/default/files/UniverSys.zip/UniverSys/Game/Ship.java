/*
 * Nave.java
 *
 * Created on 31 de Dezembro de 2003, 18:49
 */

/**
 *
 * @author  Luis
 */
package Game;

import java.awt.*;
import java.awt.image.*;
import java.awt.Graphics;

public class Ship extends GameEntity implements Runnable{
    
    /** Creates a new instance of Nave */
    public Ship(Image[] frames, int nrFrames) {
        super(frames, nrFrames);
        new Thread(this).start();
    }
    
    public void Forward(int i){
        super.Move(0,-i);
        super.CheckUniLimits();
        super.Transform(super.TRANS_NONE);
    }
    
    public void Backward(int i){
        super.Move(0,i);
        super.CheckUniLimits();
        super.Transform(super.TRANS_ROT180);
    }
    
    public void Left(int i){
        super.Move(-i,0);
        super.CheckUniLimits();
        super.Transform(super.TRANS_ROT90);
    }
    
    public void Right(int i){
        super.Move(i,0);
        super.CheckUniLimits();
        super.Transform(super.TRANS_ROT270);
    }
      
    public int Distance(int x, int y){
        return (int)Math.sqrt((x-super.getX())*(x-super.getX()) + (y-super.getY())*(x-super.getY()));
    }
    
    public void run() {
        while(true){
            //   Draw((Graphics2D)g);
            nextFrame();
            try{ Thread.sleep(250); }
            catch(InterruptedException ie){}
        }
        
    }
    
    
}
