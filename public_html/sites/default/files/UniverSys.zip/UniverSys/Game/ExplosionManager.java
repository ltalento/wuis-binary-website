/*
 * Explosion1.java
 *
 * Created on 16 de Janeiro de 2004, 14:26
 */

/**
 *
 * @author  aluno
 */
package Game;

import java.awt.*;
import java.awt.image.*;
import java.awt.Graphics;
import java.util.Vector;

public class ExplosionManager implements Runnable{
    
    public static final int EXPL01 = 0;
    public static final int EXPL02 = 1;
    public static final int EXPL03 = 2;
    
    //Exposion expl[];
    //int nrExpl;
    Vector expl;
    
    Sprite sprites[];
    
    /** Creates a new instance of Explosion1 */
    public ExplosionManager(Image[][] frames, int[] nrFrames, int nrTypes) {
        
        sprites = new Sprite[nrTypes];


        for(int i=0; i<nrTypes;i++)
            sprites[i] = new Sprite(frames[i], nrFrames[i]);

        
        expl = new Vector();
        
        new Thread(this).start();
    }
    
    public void startExplosion(int w_x, int w_y, int type){
       /* Exposion tmp[];
        tmp = new Exposion[nrExpl];
        for(int i=0; i<nrExpl; i++)
            tmp[i]=expl[i];
        
        nrExpl++;
        expl = new Exposion[nrExpl];
        for(int i=0; i<(nrExpl-1); i++)
            expl[i]=tmp[i];
        expl[(nrExpl-1)] = new Exposion();
        
        expl[(nrExpl-1)].w_x =  w_x;
        expl[(nrExpl-1)].w_y =  w_y;
        expl[(nrExpl-1)].sprite = new Sprite(sprites[type]);*/
        Exposion tmp= new Exposion();
        tmp.w_x =  w_x;
        tmp.w_y =  w_y;
        tmp.sprite = new Sprite(sprites[type]);
        
        expl.add(tmp);
        
    }
    
    private void delExplosion(int index){
        /*Exposion tmp[];
        tmp = new Exposion[nrExpl];
        for(int i=0; i<nrExpl; i++)
            tmp[i]=expl[i];
         
        nrExpl--;
        expl = new Exposion[nrExpl];
        for(int i=0, j=0; i<(nrExpl+1);i++,j++)
            if(i!=index) expl[i]=tmp[j];
            else j--;*/
        expl.remove(index);
    }
    
    public void Draw(Graphics2D g){
        /*for(int i=0; i<nrExpl; i++){
            int tmpx = expl[i].w_x - GG.player_x + (GG.SCREEN_W/2);
            int tmpy = expl[i].w_y - GG.player_y + (GG.SCREEN_H/2);
            expl[i].sprite.setXY(tmpx,tmpy);
            expl[i].sprite.Draw(g);
        }*/
        for(int i=0; i<expl.size(); i++){
            Exposion tmp=(Exposion)expl.get(i);
            int tmpx = tmp.w_x - GG.pPlayerShip.getWordlX() + (GG.SCREEN_W/2);
            int tmpy = tmp.w_y - GG.pPlayerShip.getWordlY() + (GG.SCREEN_H/2);
            tmp.sprite.setXY(tmpx,tmpy);
            tmp.sprite.Draw(g);
        }
        
    }
    
    public void run() {
        while(true){
            /*for(int i=0; i<nrExpl; i++){
                expl[i].sprite.nextFrame();
                if(expl[i].sprite.getCurrFrame()==0)
                    delExplosion(i);
            }*/
            for(int i=0; i<expl.size(); i++){
                Exposion tmp=(Exposion)expl.get(i);
                tmp.sprite.nextFrame();
                if(tmp.sprite.getCurrFrame()==0)
                    delExplosion(i);
            }
            try{ Thread.sleep(125); }
            catch(InterruptedException ie){}
        }
    }
    
}

class Exposion{
    public int w_x, w_y;
    public Sprite sprite;
}
