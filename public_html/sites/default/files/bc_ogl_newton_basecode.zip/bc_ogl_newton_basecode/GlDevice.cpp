//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "GlDevice.h"

//---------------------------------------------------------------------------

#pragma package(smart_init)

bool GlDevice::Create(void *handle)
{
        gl_HDC = GetDC(handle);

        PIXELFORMATDESCRIPTOR pfd, *ppfd;
        int pixelformat;
        ppfd = &pfd;
        ppfd->nSize = sizeof(PIXELFORMATDESCRIPTOR);
        ppfd->nVersion = 1;
        ppfd->dwFlags = PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL |
                        PFD_DOUBLEBUFFER;
        ppfd->dwLayerMask = PFD_MAIN_PLANE;
        ppfd->iPixelType = PFD_TYPE_RGBA;
        ppfd->cColorBits = 16;
        ppfd->cDepthBits = 8;
        ppfd->cAccumBits = 0;
        ppfd->cStencilBits = 0;

        if ( (pixelformat = ChoosePixelFormat(gl_HDC, ppfd)) == 0 )
            return false;//MessageBox(NULL, "ChoosePixelFormat failed", "Error", MB_OK);

        if (SetPixelFormat(gl_HDC, pixelformat, ppfd) == FALSE)
            return false;//MessageBox(NULL, "SetPixelFormat failed", "Error", MB_OK);

        gl_HRC = wglCreateContext(gl_HDC);
        if(gl_HRC==NULL)
                return false;
        if(wglMakeCurrent(gl_HDC, gl_HRC)== false)
                return false;
                
        return true;
}

void GlDevice::Init(float w, float h)
{
        glViewport( 0, 0, w, h);
        glMatrixMode( GL_PROJECTION );
        glLoadIdentity();
        gluPerspective( 45.0, w/h, 1.0, 250.0 );
       // glOrtho(-HALFGLSCENE_W,HALFGLSCENE_W,-HALFGLSCENE_H,HALFGLSCENE_H,-1,2);
        //glOrtho(0 ,w , h, 0,-1,2);
        glMatrixMode( GL_MODELVIEW );

        glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
        glClearDepth( 1.0 );
        glEnable(GL_DEPTH_TEST);
        glEnable(GL_LIGHT0);
        glEnable(GL_LIGHTING);
        glEnable(GL_COLOR_MATERIAL);

        //glEnable(GL_TEXTURE_2D);
}

void GlDevice::ShutDwn(void *handle)
{
        if (gl_HRC) wglDeleteContext(gl_HRC);
        if (gl_HDC) ReleaseDC(handle, gl_HDC);
        wglMakeCurrent(NULL, NULL);
}

void GlDevice::Show()
{
        SwapBuffers(gl_HDC);
}

bool GlDevice::LoadTexture(const char *filename, GLuint *texture)
{
        Graphics::TBitmap* bitmap;
        bitmap = new Graphics::TBitmap;

        bitmap->LoadFromFile(filename);

        if(bitmap->Empty){
               delete bitmap;
               return false;
        }

        int w  = bitmap->Width;
        int h  = bitmap->Height;
        GLubyte *bits;
        bits = new GLubyte[w*h*4];

        //int m1[Z][Y][X];
        //int m2[X*Y*Z];
        //m1[z][y][x]=m2[z*(Y*X)+y*X+x];

        for(int i = 0; i < w; i++)
        {
            for(int j = 0; j < h; j++)
            {
                bits[i*(h*4)+j*4+0]= (GLbyte)GetRValue(bitmap->Canvas->Pixels[i][j]);
                bits[i*(h*4)+j*4+1]= (GLbyte)GetGValue(bitmap->Canvas->Pixels[i][j]);
                bits[i*(h*4)+j*4+2]= (GLbyte)GetBValue(bitmap->Canvas->Pixels[i][j]);
                bits[i*(h*4)+j*4+3]= (GLbyte)255;

            }
        }
        glPixelStorei(GL_UNPACK_ALIGNMENT, 4);
        glGenTextures(1, texture);
        glBindTexture(GL_TEXTURE_2D, *texture);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, bits);
        delete bits;
        bitmap->FreeImage();
        delete bitmap;

        return true;
}

void GlDevice::UnLoadTexture(GLuint *texture)   //not tested
{
        glDeleteTextures(1,texture);
}


void GlDevice::FontSys_Init()
{
	// create bitmaps for the device context's font's first 256 glyphs
	wglUseFontBitmaps(gl_HDC, 0, 256, 1000);

}

void GlDevice::FontSys_Print(const char *text)
{

	if(text==NULL)
		return;
	
	//glPushMatrix();				

	//glLoadIdentity();
	// move bottom left, southwest of the red triangle

	//glRasterPos2f(x ,y);
	// set up for a string-drawing display list call
	glListBase(1000);
    // draw a string using font display lists

	glCallLists( strlen(text) , GL_UNSIGNED_BYTE, text );

	//get all those commands to execute
//	glPopMatrix();
}

void GlDevice::FontSys_ShutDwn()
{
	//delete our 256 glyphic display lists
	glDeleteLists(1000, 256) ; 
}

float GlDevice::ProcessFps()
{
	// Keep track of the time lapse and frame count
	time = GetTickCount()*0.001f; // Get current time in seconds
	++frames;
	
	// Update the frame rate once per second
	if(time-last_time>1.0f)
	{
	 fps      = frames/(time-last_time);
	 last_time= time;
	 frames   = 0L;
	}
	return fps;
}

//Let L be the position of the light
//P the position of a vertex of the object we want to shadow
//E a point of the plane (not seen in the figure)
//n the normal vector of the plane

void glShadowProjection(float * l, float * e, float * n)
{
  float c, d;
  float mat[16];
  
  // These are the variables for easier calculations 
  // (see my tutorial)
  
  d = l[0]*n[0] + l[1]*n[1] + l[2]*n[2];
  c = (e[0]*n[0] + e[1]*n[1] + e[2]*n[2]) - d;

  // Create the matrix. OpenGL uses column by column
  // ordering

  mat[0]  = l[0]*n[0]+c;
  mat[4]  = 0.0;
  mat[8]  = 0.0;
  mat[12] = -l[0]*d - l[0]*c;

  mat[1]  = 0.0;
  mat[5]  = l[1]*n[1]+c;
  mat[9]  = 0.0;
  mat[13] = -l[1]*d - l[1]*c;

  mat[2]  = 0.0;
  mat[6]  = 0.0;
  mat[10] = l[2]*n[2]+c;
  mat[14] = -l[2]*d - l[2]*c;

  mat[3]  = n[0];
  mat[7]  = n[1];
  mat[11] = n[2];
  mat[15] = -d;

  // Finally multiply the matrices together *plonk*
  glMultMatrixf(mat);
}
/*
void shadowMatrix(GLfloat shadowMat[4][4], GLfloat groundplane[4], GLfloat lightpos[4]) 
{ 
GLfloat dot;   */
/* Find dot product between light position vector and ground plane normal. */
/*
dot = groundplane[X] * lightpos[X] + 
groundplane[Y] * lightpos[Y] + 
groundplane[Z] * lightpos[Z] + 
groundplane[W] * lightpos[W]; 
shadowMat[0][0] = dot - lightpos[X] * groundplane[X]; 
shadowMat[1][0] = 0.f - lightpos[X] * groundplane[Y]; 
shadowMat[2][0] = 0.f - lightpos[X] * groundplane[Z]; 
shadowMat[3][0] = 0.f - lightpos[X] * groundplane[W]; 
shadowMat[X][1] = 0.f - lightpos[Y] * groundplane[X]; 
shadowMat[1][1] = dot - lightpos[Y] * groundplane[Y]; 
shadowMat[2][1] = 0.f - lightpos[Y] * groundplane[Z]; 
shadowMat[3][1] = 0.f - lightpos[Y] * groundplane[W]; 
shadowMat[X][2] = 0.f - lightpos[Z] * groundplane[X]; 
shadowMat[1][2] = 0.f - lightpos[Z] * groundplane[Y]; 
shadowMat[2][2] = dot - lightpos[Z] * groundplane[Z]; 
shadowMat[3][2] = 0.f - lightpos[Z] * groundplane[W]; 
shadowMat[X][3] = 0.f - lightpos[W] * groundplane[X]; 
shadowMat[1][3] = 0.f - lightpos[W] * groundplane[Y]; 
shadowMat[2][3] = 0.f - lightpos[W] * groundplane[Z]; 
shadowMat[3][3] = dot - lightpos[W] * groundplane[W]; 
}
*/
