//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "main.h"
#include "GlDevice.h"
#include "Newton.h"
#include <gl\glaux.H>

#pragma comment(lib, "GLAUX.LIB")
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"

bool sim = false;

TMemo *Memo2;

TForm1 *Form1;

GlDevice gl;

static NewtonWorld* nWorld;
static NewtonBody* ribidBodyBox;

NewtonBody *phyGround;
NewtonBody *phyBall;


// this callback is called when the two aabb boxes of the collision object overlap
int  GenericContactBegin (const NewtonMaterial* material, const NewtonBody* body0, const NewtonBody* body1)
{
    //NewtonMaterialSetContactNormalAcceleration(material,100);
    float v[3] = {0,10,0};
    float p[3] = {0,1,0};
    //NewtonAddBodyImpulse(body0, v, p);

   //NewtonMaterialSetContactTangentAcceleration(material,10000,0);
   // NewtonMaterialSetContactTangentAcceleration(material,10,1);
    return 1;
}

// this callback is called for every contact between the two bodies
int  GenericContactProcess (const NewtonMaterial* material, const NewtonContact* contact)
{
    NewtonMaterialSetContactNormalAcceleration(material,10000);
    //NewtonMaterialSetContactTangentAcceleration(material,10000,0);
    //NewtonMaterialSetContactTangentAcceleration(material,10000,1);
    Memo2->Lines->Add( NewtonMaterialGetContactNormalSpeed(material,contact));
    return 1;
}
// this function is call after all contacts for this pairs is processed
void  GenericContactEnd (const NewtonMaterial* material)
{
       //NewtonMaterialSetContactNormalAcceleration(material,10000);

        //MB_OK                 0
        //MB_ICONHAND           16
        //MB_ICONQUESTION       32
        //MB_ICONEXCLAMATION    48
        //MB_ICONASTERISK       64
       MessageBeep(MB_ICONEXCLAMATION);
}

void ApplyForceAndTorqueEvent(const NewtonBody* body){

    float f[3]={0,-10,0};
    NewtonBodyAddForce(body,f);
}

int defaultMaterial;
//int grounfMaterial;

void initPhysics()
{

	// Set up default material properties for newton

	int defaultMaterial = NewtonMaterialGetDefaultGroupID(nWorld);
	NewtonMaterialSetDefaultFriction   (nWorld, defaultMaterial, defaultMaterial, 0.8f, 0.4f);
	NewtonMaterialSetDefaultElasticity (nWorld, defaultMaterial, defaultMaterial, 0.3f);
	NewtonMaterialSetDefaultSoftness   (nWorld, defaultMaterial, defaultMaterial, 0.05f);
	NewtonMaterialSetCollisionCallback (nWorld, defaultMaterial, defaultMaterial, NULL, GenericContactBegin, GenericContactProcess, GenericContactEnd);

	NewtonCollision* bodyGEO;//pointer to the collision object(a box primitive)
    //init   phyGround
    bodyGEO = NewtonCreateBox(nWorld, 10, 1, 10, 0);
	phyGround = NewtonCreateBody(nWorld,bodyGEO);
	NewtonReleaseCollision(nWorld, bodyGEO);
    NewtonBodySetMassMatrix(phyGround, 0, 0, 0, 0);
    NewtonBodySetAutoFreeze(phyGround,0);

//    grounfMaterial = NewtonMaterialCreateGroupID(nWorld);

    //init   phyBall
    bodyGEO = NewtonCreateSphere(nWorld, 1, 1, 1, 0);
	phyBall = NewtonCreateBody(nWorld,bodyGEO);
	NewtonReleaseCollision(nWorld, bodyGEO);
    NewtonBodySetMassMatrix(phyBall, 1, 0.4f, 0.4f, 0.4f);

    float m[16]={1,0,0,0,
                0,1,0,0,
                0,0,1,0,
                0,10,0,1};
    NewtonBodySetMatrix(phyBall, m);

    NewtonBodySetForceAndTorqueCallback(phyBall, ApplyForceAndTorqueEvent);

    NewtonBodySetAutoFreeze(phyBall,0);

   //NewtonAddBodyImpulse

   	// create all materials ID
	//woodID = NewtonMaterialCreateGroupID(nWorld);
}

void cleanPhysics()
{
    NewtonDestroyBody(nWorld, phyBall);
    NewtonDestroyBody(nWorld, phyGround);
}

void drawGround()
{
    glPushMatrix();
        float m[16];
		NewtonBodyGetMatrix( phyGround , m);
        glMultMatrixf( m );
		auxSolidBox(10 , 1, 10);
        //auxWireBox(10 , 10, 10);
	glPopMatrix();
}

void drawBall()
{
     glPushMatrix();
        float m[16];
		NewtonBodyGetMatrix( phyBall , m);
        glMultMatrixf( m );
        //glScalef(rb->GetSize().GetX(),rb->GetSize().GetY(),rb->GetSize().GetZ());
        auxSolidSphere(1);
     glPopMatrix();
}
void drawBallShadow()
{
    glDisable(GL_LIGHTING);
    glPushMatrix();
        float planeNormal[3]={0,-1,0};
        float planePoint[3]={0,0.6,0};
        float lightPos[3]={50,50,-50};

        glShadowProjection(lightPos, planePoint,planeNormal);
        float m[16];
		NewtonBodyGetMatrix( phyBall , m);
        glMultMatrixf( m );
        //glScalef(rb->GetSize().GetX(),rb->GetSize().GetY(),rb->GetSize().GetZ());
        auxSolidSphere(1);
     glPopMatrix();
     glEnable(GL_LIGHTING);
}
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
    Application->OnIdle = IdleLoop;
    Memo2 = Memo1;
    gl.Create(Panel1->Handle);
    gl.Init(Panel1->Width ,Panel1->Height );
    gl.FontSys_Init();
    Memo1->Clear();

    // create the newton world
	nWorld = NewtonCreate (NULL, NULL);
    initPhysics();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::IdleLoop(TObject*, bool& done)
{
    done = false;
    glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
    glLoadIdentity();
                 /*
    glColor3f(1,1,1);
    glRasterPos2f(0 ,15);
    gl.FontSys_Print("Hello");
                */
    gluLookAt(0,5,15, 0,0,0, 0,1,0);


    glColor3f(1,1,1);
    //glTranslatef(0,0,0);
    drawGround();

    glColor3f(0.2,0.2,0.2);
    drawBallShadow();

    glColor3f(1,0,0);
    drawBall();
    
    if(sim)
    NewtonUpdate(nWorld, 0.001);

    gl.Show();

    Label1->Caption = "fps = " + AnsiString(gl.ProcessFps());
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormDestroy(TObject *Sender)
{
    cleanPhysics();
    NewtonDestroy (nWorld);
    gl.FontSys_ShutDwn();
    gl.ShutDwn(Panel1->Handle);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button1Click(TObject *Sender)
{
    //GL_VENDOR
    //GL_RENDERER
    //GL_VERSION
    //GL_EXTENSIONS

    const char* sVendor = glGetString(GL_VENDOR);
    const char* sRender = glGetString(GL_RENDERER);
    const char* sVersion = glGetString(GL_VERSION);
    const char* sExtensions = glGetString(GL_EXTENSIONS);

    Memo1->Clear();

    Memo1->Lines->Add("GL_VENDOR:");
    Memo1->Lines->Add(sVendor);

    Memo1->Lines->Add("");
    Memo1->Lines->Add("GL_RENDERER:");
    Memo1->Lines->Add(sRender);

    Memo1->Lines->Add("");
    Memo1->Lines->Add("GL_VERSION:");
    Memo1->Lines->Add(sVersion);

    Memo1->Lines->Add("");
    Memo1->Lines->Add("GL_EXTENSIONS:");
    Memo1->Lines->Add(sExtensions);

}
//---------------------------------------------------------------------------

/*
SHADING_LANGUAGE_VERSION_ARB		0x8B8C
   const char* sEx = glGetString(0x8B8C);
   Memo1->Lines->Add("");
   Memo1->Lines->Add(sEx);

= wglGetProcAddress();

// This is a define that we use for our function pointers
#define APIENTRYP APIENTRY *

*/

void __fastcall TForm1::Button2Click(TObject *Sender)
{

    sim = !sim;

    if(sim) Button2->Caption = "Stop Sim";
    else Button2->Caption = "Start Sim";

}
//---------------------------------------------------------------------------

