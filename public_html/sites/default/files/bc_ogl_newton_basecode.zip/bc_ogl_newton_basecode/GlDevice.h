//---------------------------------------------------------------------------

#ifndef GlDeviceH
#define GlDeviceH
//---------------------------------------------------------------------------
#include <gl/gl.h> 
#include <gl/glu.h>

class GlDevice
{
private:
	HDC   gl_HDC;
    HGLRC gl_HRC;

    //fps stuff
    float fps;
    float last_time;
    DWORD frames;

    float time;
    //----------

public:
    bool Create(void *handle);
    void Init(float w, float h);
    void ShutDwn(void *handle);
    void Show();

    bool LoadTexture(const char *filename, GLuint *texture);
    void UnLoadTexture(GLuint *texture);

	void FontSys_Init();
	void FontSys_Print(const char *text);
	void FontSys_ShutDwn();

    float ProcessFps();

};

void glShadowProjection(float * l, float * e, float * n);

#endif
 